from __future__ import annotations

import json
import logging
import os
import re
import threading
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from utils.io import read_json, save_image, write_json

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now().isoformat()


def _timestamp_compact() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


class TrajectoryManager:
    def __init__(self, base_save_path: Optional[str] = None):
        root = Path(base_save_path) if base_save_path else Path(__file__).resolve().parent.parent / "trajectories"
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._active: Dict[str, Dict[str, Any]] = {}
        logger.info(f"TrajectoryManager initialized at: {self.root}")

    @staticmethod
    def _slugify(txt: str, max_len: int = 80, hash_len: int = 8) -> str:
        txt = str(txt) if txt is not None else ""
        safe = re.sub(r"[^A-Za-z0-9_\-一-龥]+", "_", txt).strip("_")
        if len(safe) <= max_len:
            return safe or "task"
        prefix = safe[: max_len - hash_len - 1] or "task"
        suffix = uuid.uuid4().hex[:hash_len]
        return f"{prefix}_{suffix}"

    @staticmethod
    def _coerce_dict(payload: Any) -> Dict[str, Any]:
        if payload is None:
            return {}
        if isinstance(payload, dict):
            return payload
        return {}

    @staticmethod
    def _normalize_state(payload: Any) -> Dict[str, Any]:
        if payload is None:
            return {}
        if isinstance(payload, list):
            return {"items": payload}
        if not isinstance(payload, dict):
            return {}

        clean: Dict[str, Any] = {}
        for key, value in payload.items():
            if key in {"screenshot", "screenshot_b64", "raw_screenshot"}:
                continue
            clean[str(key)] = TrajectoryManager._to_text_or_scalar(value)
        return clean

    @staticmethod
    def _to_text_or_scalar(value: Any) -> Any:
        if isinstance(value, (dict, list, str, int, float, bool)) or value is None:
            return value
        return str(value)

    @staticmethod
    def _to_str(obj: Any) -> str:
        try:
            if isinstance(obj, (dict, list)):
                return json.dumps(obj, ensure_ascii=False)
            return str(obj)
        except Exception:
            logger.exception("Failed to serialize trajectory object, fallback to repr: %r", obj)
            return repr(obj)

    @staticmethod
    def _to_text(obj: Any) -> str:
        if isinstance(obj, str):
            return obj
        return TrajectoryManager._to_str(obj)

    def _append_jsonl(self, path: Path, payload: Dict[str, Any]) -> None:
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")

    def start_trajectory(
        self,
        agent_type: str,
        agent_id: str,
        vm_name: str,
        task_name: str,
        instruction: str = "",
        task_mode: str = "generation",
        config: Optional[Any] = None,
        node_ip: str = "",
        task_meta: Optional[Dict[str, Any]] = None,
        trajectory_meta: Optional[Dict[str, Any]] = None,
    ) -> str:
        with self._lock:
            cfg_list = config if isinstance(config, list) else []
            ip_suffix = f"_{node_ip}" if node_ip else ""
            dir_name = f"{self._slugify(vm_name)}{ip_suffix}_{self._slugify(task_name)}_{_timestamp_compact()}"
            traj_dir = self.root / dir_name
            if traj_dir.exists():
                traj_dir = self.root / f"{dir_name}_{uuid.uuid4().hex[:8]}"

            images_dir = traj_dir / "images"
            images_dir.mkdir(parents=True, exist_ok=True)
            raw_outputs_dir = traj_dir / "raw_outputs"
            raw_outputs_dir.mkdir(parents=True, exist_ok=True)
            json_path = traj_dir / "trajectory.json"
            jsonl_path = traj_dir / "trajectory.jsonl"

            start_time = _now_iso()
            task_meta = self._coerce_dict(task_meta)
            trajectory_meta = self._coerce_dict(trajectory_meta)
            data = {
                "agent": agent_type,
                "agent_id": agent_id,
                "vm": vm_name,
                "node_ip": node_ip,
                "task": task_name,
                "instruction": str(instruction or ""),
                "task_mode": task_mode,
                "config": cfg_list,
                "status": "running",
                "start_time": start_time,
                "end_time": None,
                "total_steps": 0,
                "last_updated": start_time,
                "schema_version": "2.0",
                "task_meta": task_meta,
                "trajectory_meta": trajectory_meta,
                "steps": [],
            }

            write_json(json_path, data)
            self._append_jsonl(
                jsonl_path,
                {
                    "event": "episode_start",
                    "ts": start_time,
                    "episode_agent": agent_type,
                    "episode_agent_id": agent_id,
                    "task_name": task_name,
                    "task_mode": task_mode,
                    "instruction": str(instruction or ""),
                    "task_meta": task_meta,
                    "instruction_id": task_meta.get("instruction_id") or task_meta.get("task_id"),
                    "trajectory_meta": trajectory_meta,
                    "config": cfg_list,
                },
            )

            trajectory_id = f"{agent_type}::{agent_id}::{vm_name}::{dir_name}"
            self._active[trajectory_id] = {
                "dir": traj_dir,
                "images": images_dir,
                "raw_outputs": raw_outputs_dir,
                "json": json_path,
                "jsonl": jsonl_path,
                "agent_type": agent_type,
                "agent_id": agent_id,
                "vm_name": vm_name,
                "node_ip": node_ip,
                "task_name": task_name,
                "task_mode": task_mode,
                "start_time": start_time,
                "task_meta": task_meta,
                "trajectory_meta": trajectory_meta,
                "steps": 0,
            }
            return trajectory_id

    def add_step(
        self,
        trajectory_id: str,
        observation: Any,
        screenshot: Optional[Any] = None,
        mouse: Optional[object] = None,
        timestamp: Optional[str] = None,
        raw_output: Optional[Any] = None,
        parsed_action_code: Optional[Any] = None,
        only_raw_output: bool = False,
        state_before: Optional[Dict[str, Any]] = None,
        state_after: Optional[Dict[str, Any]] = None,
        hook_trace: Optional[Dict[str, Any]] = None,
        reward: Optional[float] = None,
        done: Optional[bool] = None,
        info: Optional[Dict[str, Any]] = None,
    ) -> bool:
        with self._lock:
            info_record = self._active.get(trajectory_id)
            if not info_record:
                logger.error(f"Trajectory not found: {trajectory_id}")
                return False

            data = read_json(info_record["json"]) or {}
            steps = data.get("steps", [])
            step_index = len(steps)

            mpos = mouse
            if mpos is None and isinstance(observation, dict) and "mouse" in observation:
                mpos = observation.get("mouse")
            if isinstance(mpos, tuple):
                mpos = [mpos[0], mpos[1]]

            ss_name = None
            if screenshot is not None:
                ss_name = f"step_{step_index:03d}.png"
                try:
                    save_image(info_record["images"] / ss_name, screenshot)
                except Exception as e:
                    logger.warning(f"Failed to save screenshot for step {step_index}: {e}")
                    ss_name = None
            raw_text = self._to_text(raw_output)
            raw_name = None
            if raw_output is not None:
                raw_name = f"step_{step_index:03d}.txt"
                try:
                    with open(info_record["raw_outputs"] / raw_name, "w", encoding="utf-8") as f:
                        f.write(raw_text)
                except Exception as e:
                    logger.warning(f"Failed to save raw output for step {step_index}: {e}")
                    raw_name = None

            if only_raw_output:
                entry = {
                    "step_index": step_index,
                    "raw_output": raw_text,
                    "pyautogui_code": "",
                    "observation": "",
                    "timestamp": timestamp or _now_iso(),
                }
            else:
                entry = {
                    "step_index": step_index,
                    "raw_output": raw_text,
                    "pyautogui_code": self._to_str(parsed_action_code),
                    "observation": ss_name or self._to_str(observation),
                    "timestamp": timestamp or _now_iso(),
                }
            if raw_name:
                entry["raw_output_file"] = raw_name
            if mpos is not None:
                entry["mouse"] = mpos
            if state_before is not None:
                entry["state_before"] = self._normalize_state(state_before)
            if state_after is not None:
                entry["state_after"] = self._normalize_state(state_after)
            if hook_trace is not None:
                entry["hook_trace"] = self._coerce_dict(hook_trace)
            if reward is not None:
                entry["reward"] = float(reward)
            if done is not None:
                entry["done"] = bool(done)
            if info is not None:
                entry["info"] = self._coerce_dict(info)
            steps.append(entry)

            data["steps"] = steps
            data["total_steps"] = len(steps)
            data["last_updated"] = _now_iso()
            write_json(info_record["json"], data)
            self._append_jsonl(
                info_record["jsonl"],
                {
                    "event": "step",
                    "ts": entry["timestamp"],
                    "step_index": step_index,
                    "episode_agent": data.get("agent"),
                    "episode_agent_id": data.get("agent_id"),
                "task_name": data.get("task"),
                "task_mode": data.get("task_mode"),
                "instruction_id": data.get("task_meta", {}).get("instruction_id")
                or data.get("task_meta", {}).get("task_id"),
                "observation": entry.get("observation"),
                "raw_output": entry.get("raw_output"),
                "pyautogui_code": entry.get("pyautogui_code", ""),
                    "state_before": entry.get("state_before", {}),
                    "state_after": entry.get("state_after", {}),
                    "reward": entry.get("reward"),
                    "done": entry.get("done"),
                    "hook_trace": entry.get("hook_trace", {}),
                    "info": entry.get("info", {}),
                },
            )

            info_record["steps"] = len(steps)
            return True

    def finish_trajectory(
        self,
        trajectory_id: str,
        success: bool,
        final_screenshot: Optional[Any] = None,
        summary: Optional[Dict[str, Any]] = None,
    ) -> None:
        with self._lock:
            info_record = self._active.get(trajectory_id)
            if not info_record:
                logger.error(f"Trajectory not found: {trajectory_id}")
                return

            if final_screenshot is not None:
                try:
                    self.add_step(
                        trajectory_id,
                        observation="",
                        screenshot=final_screenshot,
                        raw_output="",
                        parsed_action_code="DONE" if success else "FAIL",
                    )
                except Exception as e:
                    logger.warning(f"Failed to append final screenshot: {e}")

            data = read_json(info_record["json"]) or {}
            end_time = _now_iso()
            data["status"] = "success" if success else "failed"
            data["end_time"] = end_time
            data["last_updated"] = end_time
            if summary:
                data["summary"] = self._coerce_dict(summary)
            write_json(info_record["json"], data)
            self._append_jsonl(
                info_record["jsonl"],
                {
                    "event": "episode_end",
                    "ts": end_time,
                    "episode_agent": info_record.get("agent_type"),
                    "episode_agent_id": info_record.get("agent_id"),
                    "task_name": info_record.get("task_name"),
                    "task_mode": info_record.get("task_mode"),
                "status": "success" if success else "failed",
                "summary": self._coerce_dict(summary),
                "total_steps": data.get("total_steps"),
                "instruction_id": data.get("task_meta", {}).get("instruction_id")
                or data.get("task_meta", {}).get("task_id"),
            },
        )

            del self._active[trajectory_id]

    def active_ids(self) -> List[str]:
        return list(self._active.keys())

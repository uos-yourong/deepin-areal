# Deepin-RLENV 项目说明

**项目目标**
- 提供统一的桌面环境强化学习执行平台，通过 REST 服务完成远程初始化与交互。
- 在各节点上批量创建虚拟机实例，每个实例运行 DesktopEnv 并暴露微服务接口，统一纳入资源池进行分配与回收。

**系统架构**
- 控制端服务：`start.py`（读取 `all_config.yaml`，提供 REST 接口）
- 节点管理：`manage/node_manager.py`（调用 Ansible 分发代码、探测容量、拉起 worker）
- 虚拟机实例：`desktop_env/desktop_env.py`（每 VM 一个 DesktopEnv）
- VM 内服务：`desktop_env/desktop_env.py`（虚机生命周期管理）与 `desktop_env/worker.py`/`desktop_env/env_worker.py`（桌面交互与步进服务）
- Worker 进程：`desktop_env/env_worker.py`（FastAPI，对外暴露 `/step`、`/observe` 等）
- 解析与包装：`rl_adapters/` 与 `gui_models/`（按配置选择）
- 轨迹存储：`trajectory_management/`（记录输入/输出与截图）

**初始化流程**
- 远程调用控制端的初始化接口，控制端按配置启动节点管理：
  - 分发代码到各节点
  - 探测每节点可承载的 VM 容量
  - 按目标总量或节点指定数量进行比例分配
  - 在各节点启动 worker（每虚机一个 env_worker 进程）
- worker 输出每个虚拟机实例的 `worker_host/worker_port` 与 `http_endpoint`，控制端汇总并写入资源池。

**运行流程（Action）**
- 前端进入交互阶段时，控制端从资源池分配一个虚拟机实例并建立会话。
- 按 `all_config.yaml` 中的 `rl_framework` 与 `gui_model`：
  - 先用对应的 RL 适配器在 `rl_adapters/` 中解析前端输出
  - 再由 `gui_models/` 的对应模型进行处理与记忆更新
  - 将处理后的动作下发到该实例的 `step` 方法
  - 等待约 1 秒后调用该实例的 `observe` 方法获取输出
  - 用对应 RL 框架的适配器进行包装，按前端调用长轮询返回数据
- 全过程使用 `trajectory_management` 将输入和输出保存成轨迹（含截图）。
- 会话结束时重置虚机状态并将实例回收到资源池。

**配置说明**
- 控制端配置：`all_config.yaml`
  - `gui_model`：如 `uitars`、`evocua`
  - `rl_framework`：如 `verl` 或 `areal`
  - `server.host`、`server.port`：控制端 REST 服务地址
  - `vm_manager.total`、`vm_manager.nodes`、`vm_manager.options.enforce_limits`：初始化与调度策略
- 节点侧合并配置：`ansible/group_vars/all.yaml` 与 `ansible/host_vars/*.yaml`
  - 路径、集群、libvirt 模板、调度、运行参数等由 YAML 统一管理

**服务接口（控制端）**
- `POST /init/provision`：初始化资源池
  - 方式一：传 `config_path`（Hydra 配置路径）
  - 方式二：传 `total`、`nodes`（字典）与 `enforce_limits`
- `POST /session/start`：分配一台虚机并重置，返回 `session_id` 与端点信息
- `POST /session/step`：解析前端输出→执行→等待→观测→包装并返回
  - `extras` 可透传给 `gui_models` 解析器（如 `evocua` 的坐标缩放参数：`coordinate_type`、`processed_width`、`processed_height`、`screen_width`、`screen_height`）
- `POST /session/finish`：结束并回收资源到池中
- `GET /health`：服务健康与资源池大小
- `POST /pool/destroy_all`：按筛选批量关闭并销毁可用虚机

**服务接口（env_worker）**
- `GET /info`：实例信息（VM 名称、IP、端口等）
- `POST /reset`：重置到初始或指定任务配置
- `POST /step`：执行一步动作（可设置 `pause`）
- `GET /observe`：拉取当前观测（截图/可访问性树/终端/指令等）
- `DELETE /close`：关闭实例进程

**资源池与会话**
- 资源池文件位于 `paths.controller_state_dir` 下（默认 `state/workers_pool.json`）。
- 实例分配会写入 `session_id`，结束后重置并置为 `available`，回收入池。

**依赖与环境**
- 系统：`ansible`, `rsync`, `virsh`, `qemu-img`, `virt-install`, `x11vnc`, `wmctrl`, `xdotool` 等按需安装。
- Python：控制端 `fastapi`、`uvicorn`、`ansible-runner`；桌面环境与服务端依赖（见各 `requirements.txt`）。

**快速启动**
- 启动控制端服务：`python start.py`
- 启动节点管理：`python manage/node_manager.py`
- 初始化（REST 调用）：`POST /init/provision`（传 `config_path` 或 `total/nodes`）

**目录结构**
- `manage/`：节点管理与资源池管理
- `desktop_env/`：虚机环境、worker 与 VM 内服务
- `rl_adapters/`、`gui_models/`：解析与包装
- `trajectory_management/`：轨迹记录
- `ansible/`：清单与 Playbooks

**安全与鉴权**
- 控制端与 worker 支持 `Bearer` 令牌：设置 `ENV_WORKER_TOKEN` 后，需在请求头携带 `Authorization: Bearer <token>`。

**轨迹管理**
- 每步将动作、原始输入、观测与截图写入运行轨迹；结束时按状态移动到 `success` 或 `failed` 分类目录，便于后续分析与回放。

**运维与清理**
- 批量销毁可用实例：调用控制端 `POST /pool/destroy_all`（可按主机与状态筛选）。
- 正常回收：通过 `POST /session/finish` 将实例重置并回收到资源池。

**故障排查**
- 查看 `state/workers_pool.json` 以确认资源池端点是否就绪。
- 检查各节点的 worker 日志与 ansible artifacts（容量与端点解析）。

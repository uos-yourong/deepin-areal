from __future__ import annotations

import logging
import os
import sys
from typing import Any, Callable, NoReturn, Optional, Tuple, TypeVar

logger = logging.getLogger(__name__)

try:
    import termios
except Exception:
    logger.exception("termios import failed; tty snapshot/restore will be disabled")
    termios = None


TTYState = Tuple[int, Any]
_T = TypeVar("_T")


def snapshot_tty(fd: Optional[int] = None) -> Optional[TTYState]:
    if termios is None:
        return None
    try:
        target_fd = sys.stdin.fileno() if fd is None else int(fd)
        if not os.isatty(target_fd):
            return None
        return (target_fd, termios.tcgetattr(target_fd))
    except Exception:
        logger.exception("Failed to snapshot tty state fd=%s", fd)
        return None


def restore_tty(state: Optional[TTYState]) -> None:
    if termios is None or state is None:
        return
    fd, attrs = state
    try:
        termios.tcsetattr(int(fd), termios.TCSADRAIN, attrs)
    except Exception:
        logger.exception("Failed to restore tty state fd=%s", fd)


class TTYStateGuard:
    def __init__(self, fd: Optional[int] = None) -> None:
        self._fd = fd
        self._snapshot: Optional[TTYState] = None

    def __enter__(self) -> "TTYStateGuard":
        self._snapshot = snapshot_tty(self._fd)
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        restore_tty(self._snapshot)
        return False


def _write_newline() -> None:
    try:
        sys.stdout.write("\n")
        sys.stdout.flush()
    except Exception:
        logger.exception("Failed to write newline to stdout")


def exit_sigint() -> NoReturn:
    _write_newline()
    raise SystemExit(130)


def run_or_exit_on_sigint(fn: Callable[[], _T]) -> _T:
    try:
        return fn()
    except KeyboardInterrupt:
        exit_sigint()

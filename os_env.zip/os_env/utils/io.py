from pathlib import Path
import logging
import yaml
import json
import os
from typing import Dict, Any, Optional

from hydra import initialize_config_dir, compose
from hydra.core.global_hydra import GlobalHydra
from omegaconf import OmegaConf

logger = logging.getLogger(__name__)


DEFAULT_CONFIG_PATH = Path(__file__).resolve().parent.parent / "all_config.yaml"


def read_yaml(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def write_yaml(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, allow_unicode=True)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(str(path) + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def read_json(path: Path) -> Optional[Any]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        logger.exception("Failed to read json: %s", path)
        return None


def save_image(path: Path, payload: Any) -> None:
    if hasattr(payload, "save"):
        payload.save(path)
    elif isinstance(payload, (bytes, bytearray)):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            f.write(payload)
    else:
        if isinstance(payload, str):
            src = Path(payload)
            with open(src, "rb") as fsrc, open(path, "wb") as fdst:
                fdst.write(fsrc.read())
        else:
            raise TypeError(f"Unsupported payload type: {type(payload)}")


def deep_merge_dict(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Any]:
    r = dict(a)
    for k, v in (b or {}).items():
        if isinstance(v, dict) and isinstance(r.get(k), dict):
            r[k] = deep_merge_dict(r[k], v)
        else:
            r[k] = v
    return r


def normalize_config(raw: Any) -> Dict[str, Any]:
    if not isinstance(raw, dict):
        cfg = OmegaConf.to_container(raw, resolve=True)
    else:
        cfg = dict(raw)
    return cfg


def load_all_config(path: Optional[str] = None) -> Dict[str, Any]:
    p = Path(path) if path else DEFAULT_CONFIG_PATH
    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p}")
    if GlobalHydra.instance().is_initialized():
        cfg_obj = OmegaConf.load(str(p))
    else:
        cfg_dir = str(p.parent.resolve())
        cfg_name = p.stem
        with initialize_config_dir(config_dir=cfg_dir):
            cfg_obj = compose(config_name=cfg_name)
    return normalize_config(cfg_obj)


def sync_ansible_from_config(ansible_dir: Path, cfg: Dict[str, Any]) -> None:
    ansible_cfg = (cfg.get("ansible") or {})
    group_vars = ansible_cfg.get("group_vars") or {}
    host_vars = ansible_cfg.get("host_vars") or {}
    inventory = ansible_cfg.get("inventory") or {}
    if group_vars:
        gv_dir = ansible_dir / "group_vars"
        write_yaml(gv_dir / "all.yaml", group_vars)
    if host_vars:
        hv_dir = ansible_dir / "host_vars"
        hv_dir.mkdir(parents=True, exist_ok=True)
        for host, data in host_vars.items():
            write_yaml(hv_dir / f"{host}.yaml", data)
        configured = {f"{host}.yaml" for host in host_vars.keys()}
        for p in hv_dir.glob("*.yaml"):
            if p.name not in configured:
                try:
                    p.unlink()
                except Exception:
                    logger.exception("Failed to remove stale host var file: %s", p)
    if inventory:
        write_yaml(ansible_dir / "inventory.yaml", inventory)

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Any, Optional

from hydra import initialize_config_dir, compose
from omegaconf import OmegaConf, MISSING


DEFAULT_CONFIG_PATH = Path(__file__).resolve().parent.parent / "all_config.yaml"


@dataclass
class ServerConfig:
    host: str = MISSING
    port: int = MISSING


@dataclass
class ControllerTimeoutsConfig:
    # <= 0 means wait forever.
    alloc_batch_timeout_s: float = 0.0
    worker_reset_timeout_s: float = 60.0
    # Timeout budget for worker /setup (downloads + environment setup).
    worker_setup_timeout_s: float = 1810.0
    # Timeout for lightweight liveness probe on env_worker /ping.
    worker_ping_timeout_s: float = 2.0
    # Consecutive liveness probe failures before demotion to unavailable.
    worker_probe_fail_threshold: int = 3
    # Guard against false worker timeout during long single-turn inference.
    worker_heartbeat_timeout_s: float = 1800.0
    # Max time allowed to stay in resetting before force demotion to unavailable.
    resetting_stuck_timeout_s: float = 300.0


@dataclass
class ControllerCleanupConfig:
    concurrency: int = 16
    timeout_s: float = 20.0


@dataclass
class ControllerConfig:
    gui_model: str = MISSING
    rl_framework: str = MISSING
    server: ServerConfig = field(default_factory=ServerConfig)
    timeouts: ControllerTimeoutsConfig = field(default_factory=ControllerTimeoutsConfig)
    cleanup: ControllerCleanupConfig = field(default_factory=ControllerCleanupConfig)


@dataclass
class VMManagerOptionsConfig:
    enforce_limits: bool = MISSING


@dataclass
class VMManagerConfig:
    total: int = MISSING
    nodes: Dict[str, int] = MISSING
    options: VMManagerOptionsConfig = field(default_factory=VMManagerOptionsConfig)


@dataclass
class RootConfig:
    controller: ControllerConfig = field(default_factory=ControllerConfig)
    vm_manager: VMManagerConfig = field(default_factory=VMManagerConfig)
    ansible: Dict[str, Any] = field(default_factory=dict)


def load_structured_config(path: Optional[str] = None) -> RootConfig:
    p = Path(path) if path else DEFAULT_CONFIG_PATH
    if not p.exists():
        raise FileNotFoundError(f"Config file not found: {p}")
    cfg_dir = str(p.parent.resolve())
    cfg_name = p.stem
    with initialize_config_dir(version_base=None, config_dir=cfg_dir):
        cfg_obj = compose(config_name=cfg_name)
    base = OmegaConf.structured(RootConfig)
    merged = OmegaConf.merge(base, cfg_obj)
    return OmegaConf.to_object(merged)

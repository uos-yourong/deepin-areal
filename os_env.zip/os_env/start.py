import asyncio
import os
import sys
import time
import uuid
import json
import yaml
import threading
import urllib.parse
import base64
import subprocess
from typing import Dict, Any, Optional, List, Union, Tuple
from pathlib import Path
import logging

from fastapi import FastAPI, HTTPException, Header
from fastapi.responses import FileResponse
from pydantic import BaseModel
import uvicorn
import requests
from hydra import main as hydra_main
from omegaconf import DictConfig, OmegaConf
from manage.node_manager import (
    load_pool,
    save_pool,
    allocate_one_from_pool,
    destroy_workers,
    cleanup_cluster_nodes,
    get_controller_state_dir,
    provision_with_config,
    clear_pools,
    move_worker_to_unavailable,
)
from utils.config_schema import RootConfig, load_structured_config
from utils.tty import TTYStateGuard, exit_sigint, run_or_exit_on_sigint
from trajectory_management import TrajectoryManager
from gui_models.registry import get_model_class
from rl_adapters.areal_adapter import ARealAdapter


APP_TOKEN_ENV = "ENV_WORKER_TOKEN"


def _run_sudo_command(cmd: List[str], sudo_password: str = "", timeout: int = 20) -> Tuple[bool, str]:
    try:
        password = str(sudo_password or "")
        if password:
            result = subprocess.run(
                ["sudo", "-S", *cmd],
                input=password + "\n",
                text=True,
                capture_output=True,
                timeout=timeout,
            )
        else:
            result = subprocess.run(
                ["sudo", "-n", *cmd],
                text=True,
                capture_output=True,
                timeout=timeout,
            )
            if result.returncode != 0 and os.geteuid() == 0:
                result = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
        output = (result.stderr or result.stdout or "").strip()
        if result.returncode != 0:
            return False, output
        if output.upper().startswith("ERROR:"):
            return False, output
        return True, (result.stdout or "").strip()
    except Exception as e:
        logging.exception("sudo command execution failed: %s", cmd)
        return False, str(e)


def _apply_controller_ufw_rules(
    *,
    worker_ips: List[str],
    port: int,
    sudo_password: str = "",
) -> List[str]:
    applied: List[str] = []
    if not worker_ips:
        return applied
    for ip in worker_ips:
        ip_s = str(ip or "").strip()
        if not ip_s:
            continue
        # Ensure idempotency.
        _run_sudo_command(
            [
                "ufw",
                "delete",
                "allow",
                "proto",
                "tcp",
                "from",
                ip_s,
                "to",
                "any",
                "port",
                str(port),
            ],
            sudo_password=sudo_password,
        )
        ok, err = _run_sudo_command(
            [
                "ufw",
                "allow",
                "proto",
                "tcp",
                "from",
                ip_s,
                "to",
                "any",
                "port",
                str(port),
            ],
            sudo_password=sudo_password,
        )
        if ok:
            applied.append(ip_s)
            logging.info("Controller UFW allow worker %s -> port %s", ip_s, port)
        else:
            logging.warning("Controller UFW allow failed for worker %s port %s: %s", ip_s, port, err)
    return applied


def _revoke_controller_ufw_rules(
    *,
    worker_ips: List[str],
    port: int,
    sudo_password: str = "",
) -> None:
    for ip in worker_ips:
        ip_s = str(ip or "").strip()
        if not ip_s:
            continue
        ok, err = _run_sudo_command(
            [
                "ufw",
                "delete",
                "allow",
                "proto",
                "tcp",
                "from",
                ip_s,
                "to",
                "any",
                "port",
                str(port),
            ],
            sudo_password=sudo_password,
        )
        if ok:
            logging.info("Controller UFW revoke worker %s -> port %s", ip_s, port)
        else:
            # best-effort cleanup, keep going.
            logging.warning("Controller UFW revoke failed for worker %s port %s: %s", ip_s, port, err)


def _ensure_controller_logging() -> None:
    log_file = (Path(__file__).resolve().parent / "logs" / "controller.log").resolve()
    try:
        log_file.parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        print(
            f"[controller-logging] failed to create log dir {log_file.parent}: {e}",
            file=sys.stderr,
        )
        return

    root = logging.getLogger()
    if root.level > logging.INFO:
        root.setLevel(logging.INFO)

    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    has_file = False
    has_stream = False
    file_handlers_to_remove: List[logging.Handler] = []
    for handler in root.handlers:
        if isinstance(handler, logging.FileHandler):
            try:
                handler_path = Path(handler.baseFilename).resolve()
                if handler_path == log_file:
                    has_file = True
                else:
                    file_handlers_to_remove.append(handler)
            except Exception:
                file_handlers_to_remove.append(handler)
        elif isinstance(handler, logging.StreamHandler):
            has_stream = True

    for handler in file_handlers_to_remove:
        try:
            root.removeHandler(handler)
            handler.close()
        except Exception:
            print(
                f"[controller-logging] failed to remove stale file handler: {handler!r}",
                file=sys.stderr,
            )

    if not has_file:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(formatter)
        root.addHandler(file_handler)
    if not has_stream:
        stream_handler = logging.StreamHandler(sys.stdout)
        stream_handler.setFormatter(formatter)
        root.addHandler(stream_handler)


def _controller_to_dict(cfg: RootConfig) -> Dict[str, Any]:
    server_cfg = cfg.controller.server
    timeouts_cfg = getattr(cfg.controller, "timeouts", None)
    cleanup_cfg = getattr(cfg.controller, "cleanup", None)
    worker_node_ips: List[str] = []
    manage_controller_ufw = True
    sudo_password = ""
    public_host = str(server_cfg.host)
    try:
        ansible_cfg = getattr(cfg, "ansible", None)
        hosts_meta = getattr(ansible_cfg, "hosts_meta", None) if ansible_cfg is not None else None
        controller_meta = getattr(hosts_meta, "controller", None) if hosts_meta is not None else None
        controller_ip = getattr(controller_meta, "ip", None) if controller_meta is not None else None
        if controller_ip:
            public_host = str(controller_ip)
        if hosts_meta is not None:
            for node_name in ("node2", "node4", "node5"):
                node_meta = getattr(hosts_meta, node_name, None)
                node_ip = getattr(node_meta, "ip", None) if node_meta is not None else None
                if node_ip:
                    worker_node_ips.append(str(node_ip))
        group_vars = getattr(ansible_cfg, "group_vars", None) if ansible_cfg is not None else None
        scheduler_cfg = getattr(group_vars, "scheduler", None) if group_vars is not None else None
        manage_flag = (
            getattr(scheduler_cfg, "manage_ufw_for_worker_port", None)
            if scheduler_cfg is not None
            else None
        )
        if manage_flag is not None:
            manage_controller_ufw = bool(manage_flag)
        libvirt_meta = getattr(ansible_cfg, "libvirt_meta", None) if ansible_cfg is not None else None
        sudo_password = str(getattr(libvirt_meta, "sudo_password", "") or "")
    except Exception as e:
        logging.error(f"Failed to resolve controller public host from ansible config: {e}")
    worker_node_ips = sorted({ip.strip() for ip in worker_node_ips if str(ip or "").strip()})
    return {
        "gui_model": cfg.controller.gui_model,
        "rl_framework": cfg.controller.rl_framework,
        "controller": {
            "gui_model": cfg.controller.gui_model,
            "rl_framework": cfg.controller.rl_framework,
            "server": {
                "host": server_cfg.host,
                "port": server_cfg.port,
            },
            "timeouts": {
                "alloc_batch_timeout_s": float(getattr(timeouts_cfg, "alloc_batch_timeout_s", 0.0)),
                "worker_reset_timeout_s": float(getattr(timeouts_cfg, "worker_reset_timeout_s", 60.0)),
                "worker_setup_timeout_s": float(getattr(timeouts_cfg, "worker_setup_timeout_s", 1810.0)),
                "worker_ping_timeout_s": float(getattr(timeouts_cfg, "worker_ping_timeout_s", 2.0)),
                "worker_probe_fail_threshold": int(getattr(timeouts_cfg, "worker_probe_fail_threshold", 3)),
                "worker_heartbeat_timeout_s": float(getattr(timeouts_cfg, "worker_heartbeat_timeout_s", 1800.0)),
                "resetting_stuck_timeout_s": float(getattr(timeouts_cfg, "resetting_stuck_timeout_s", 300.0)),
            },
            "cleanup": {
                "concurrency": int(getattr(cleanup_cfg, "concurrency", 16)),
                "timeout_s": float(getattr(cleanup_cfg, "timeout_s", 20.0)),
            },
        },
        "server": {
            "host": server_cfg.host,
            "port": server_cfg.port,
            "public_host": public_host,
        },
        "controller_firewall": {
            "manage_ufw": bool(manage_controller_ufw),
            "worker_ips": worker_node_ips,
            "sudo_password": sudo_password,
        },
    }


def create_app(cfg: Any) -> FastAPI:
    if isinstance(cfg, RootConfig):
        cfg = _controller_to_dict(cfg)
    controller_cfg = cfg.get("controller") or {}
    if controller_cfg:
        if "gui_model" not in cfg and controller_cfg.get("gui_model"):
            cfg["gui_model"] = controller_cfg.get("gui_model")
        if "rl_framework" not in cfg and controller_cfg.get("rl_framework"):
            cfg["rl_framework"] = controller_cfg.get("rl_framework")
        if "server" not in cfg and isinstance(controller_cfg.get("server"), dict):
            cfg["server"] = controller_cfg.get("server")
    os.environ["GUI_MODEL"] = str(cfg["gui_model"])
    os.environ["RL_FRAMEWORK"] = str(cfg["rl_framework"])

    timeouts_cfg: Dict[str, Any] = {}
    if isinstance(controller_cfg.get("timeouts"), dict):
        timeouts_cfg = controller_cfg.get("timeouts") or {}
    elif isinstance(cfg.get("timeouts"), dict):
        timeouts_cfg = cfg.get("timeouts") or {}

    alloc_batch_timeout_s_raw = timeouts_cfg.get("alloc_batch_timeout_s")
    alloc_batch_timeout_s = float(alloc_batch_timeout_s_raw) if alloc_batch_timeout_s_raw is not None else 0.0

    worker_reset_timeout_s_raw = timeouts_cfg.get("worker_reset_timeout_s")
    worker_reset_timeout_s = float(worker_reset_timeout_s_raw) if worker_reset_timeout_s_raw is not None else 60.0
    worker_setup_timeout_s_raw = timeouts_cfg.get("worker_setup_timeout_s")
    worker_setup_timeout_s = float(worker_setup_timeout_s_raw) if worker_setup_timeout_s_raw is not None else 1810.0
    worker_ping_timeout_s_raw = timeouts_cfg.get("worker_ping_timeout_s")
    worker_ping_timeout_s = float(worker_ping_timeout_s_raw) if worker_ping_timeout_s_raw is not None else 2.0
    worker_probe_fail_threshold_raw = timeouts_cfg.get("worker_probe_fail_threshold")
    worker_probe_fail_threshold = (
        int(worker_probe_fail_threshold_raw) if worker_probe_fail_threshold_raw is not None else 3
    )

    worker_heartbeat_timeout_s_raw = timeouts_cfg.get("worker_heartbeat_timeout_s")
    worker_heartbeat_timeout_s = (
        float(worker_heartbeat_timeout_s_raw) if worker_heartbeat_timeout_s_raw is not None else 1800.0
    )
    resetting_stuck_timeout_s_raw = timeouts_cfg.get("resetting_stuck_timeout_s")
    resetting_stuck_timeout_s_cfg = (
        float(resetting_stuck_timeout_s_raw) if resetting_stuck_timeout_s_raw is not None else 300.0
    )

    cleanup_cfg: Dict[str, Any] = {}
    if isinstance(controller_cfg.get("cleanup"), dict):
        cleanup_cfg = controller_cfg.get("cleanup") or {}
    elif isinstance(cfg.get("cleanup"), dict):
        cleanup_cfg = cfg.get("cleanup") or {}
    cleanup_concurrency_raw = cleanup_cfg.get("concurrency")
    cleanup_concurrency = int(cleanup_concurrency_raw) if cleanup_concurrency_raw is not None else 16
    cleanup_timeout_raw = cleanup_cfg.get("timeout_s")
    cleanup_timeout_s = float(cleanup_timeout_raw) if cleanup_timeout_raw is not None else 20.0

    # Trajectories should live alongside the running code (controller.code_src).
    traj_root = Path(__file__).resolve().parent / "all_trajectorys"
    try:
        traj_root.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logging.error(f"Failed to create trajectory root {traj_root}: {e}")

    app = FastAPI()
    traj = TrajectoryManager(str(traj_root))
    pending_queue: List[Dict[str, Any]] = []
    pending_lock = threading.Lock()
    alloc_thread_started = False
    alloc_lock = threading.Lock()
    pool_lock = threading.Lock()
    background_stop = threading.Event()
    probe_fail_log_lock = threading.Lock()
    probe_fail_log_state: Dict[str, Dict[str, float]] = {}
    probe_fail_log_interval_s = max(5.0, float(os.environ.get("POOL_PROBE_FAIL_LOG_INTERVAL", "300")))
    probe_fail_count_lock = threading.Lock()
    probe_fail_counts: Dict[str, int] = {}
    probe_fail_threshold = max(
        1,
        int(os.environ.get("WORKER_PROBE_FAIL_THRESHOLD", str(worker_probe_fail_threshold))),
    )

    def _internal_request(method: str, url: str, **kwargs):
        # Internal control-plane calls must bypass env proxy, otherwise private
        # worker IPs may be routed to proxy and fail with false 5xx/timeout.
        with requests.Session() as s:
            s.trust_env = False
            return s.request(method=method, url=url, **kwargs)

    def _clear_probe_fail_state(host: str, port: int) -> None:
        key = f"{host}:{int(port)}"
        with probe_fail_log_lock:
            probe_fail_log_state.pop(key, None)

    def _log_probe_failure(host: str, port: int, err: Exception | str) -> None:
        key = f"{host}:{int(port)}"
        now = time.time()
        err_msg = str(err)
        with probe_fail_log_lock:
            state = probe_fail_log_state.get(key, {"last": 0.0, "suppressed": 0.0})
            last = float(state.get("last", 0.0))
            suppressed = int(state.get("suppressed", 0.0))
            if now - last >= probe_fail_log_interval_s:
                if suppressed > 0:
                    logging.warning(
                        "Worker health probe failed host=%s port=%s err=%s (suppressed=%s)",
                        host,
                        port,
                        err_msg,
                        suppressed,
                    )
                else:
                    logging.warning(
                        "Worker health probe failed host=%s port=%s err=%s",
                        host,
                        port,
                        err_msg,
                    )
                probe_fail_log_state[key] = {"last": now, "suppressed": 0.0}
            else:
                state["suppressed"] = float(suppressed + 1)
                probe_fail_log_state[key] = state

    def _probe_key(host: str, port: int) -> str:
        return f"{str(host)}:{int(port)}"

    def _record_probe_success(host: str, port: int) -> None:
        key = _probe_key(host, port)
        with probe_fail_count_lock:
            probe_fail_counts.pop(key, None)

    def _record_probe_failure(host: str, port: int) -> int:
        key = _probe_key(host, port)
        with probe_fail_count_lock:
            n = int(probe_fail_counts.get(key, 0)) + 1
            probe_fail_counts[key] = n
            return n

    def _parse_host_port(base: str) -> Tuple[str, int]:
        raw = base.replace("http://", "").replace("https://", "")
        host, port_s = raw.rsplit(":", 1)
        return host, int(port_s)

    def _check_worker_health(base: str, headers: Dict[str, str], retries: int = 3, delay_s: float = 10.0) -> Tuple[bool, str]:
        status_val = "unknown"
        host, port = _parse_host_port(base)
        for attempt in range(retries):
            try:
                hr = _internal_request(
                    "GET",
                    base + "/ping",
                    headers=headers,
                    timeout=max(0.5, worker_ping_timeout_s),
                )
                if hr.status_code == 200:
                    try:
                        hj = hr.json()
                        status_val = str(hj.get("status") or "ok")
                    except Exception:
                        status_val = "ok"
                    _record_probe_success(host, port)
                    return True, status_val
                status_val = f"http={hr.status_code}"
            except Exception as e:
                logging.warning(
                    "Ping probe attempt %s/%s failed for %s: %s",
                    attempt + 1,
                    retries,
                    base,
                    e,
                )
                status_val = "error"
            if attempt < retries - 1:
                time.sleep(delay_s)
        _log_probe_failure(host, port, status_val)
        return False, status_val

    def _worker_endpoint_key(worker: Dict[str, Any]) -> str:
        return f"{worker.get('worker_host')}:{worker.get('worker_port')}"

    def _probe_worker_health_quiet(
        host: str,
        port: int,
        timeout_s: float = 5.0,
        retries: int = 2,
        delay_s: float = 5.0,
    ) -> Tuple[bool, str]:
        headers: Dict[str, str] = {}
        token = os.environ.get(APP_TOKEN_ENV)
        if token:
            headers["Authorization"] = f"Bearer {token}"
        base = f"http://{host}:{int(port)}"
        last_status = "unknown"
        for attempt in range(max(1, int(retries))):
            try:
                hr = _internal_request(
                    "GET",
                    base + "/ping",
                    headers=headers,
                    timeout=max(0.5, timeout_s),
                )
                if hr.status_code == 200:
                    _clear_probe_fail_state(host, port)
                    _record_probe_success(host, port)
                    try:
                        hj = hr.json()
                        status_val = str(hj.get("status") or "ok")
                    except Exception:
                        status_val = "ok"
                    return True, status_val
                else:
                    last_status = f"http={hr.status_code}"
            except Exception as e:
                _log_probe_failure(host, port, e)
                last_status = f"error:{type(e).__name__}"
            if attempt < retries - 1:
                time.sleep(delay_s)
        _record_probe_failure(host, port)
        return False, last_status

    def _set_worker_unavailable(rec: Dict[str, Any], reason: str) -> None:
        rec["status"] = "unavailable"
        rec["reason"] = reason or "unknown"
        rec["moved_at"] = int(time.time())
        rec["allocated_at"] = None
        rec["allocated_by"] = None
        rec["session_id"] = None

    def _set_worker_resetting(rec: Dict[str, Any], reason: Optional[str] = None) -> None:
        rec["status"] = "resetting"
        rec["allocated_at"] = None
        rec["allocated_by"] = None
        rec["session_id"] = None
        rec["resetting_at"] = int(time.time())
        rec.pop("moved_at", None)
        if reason:
            rec["reason"] = reason
        else:
            rec.pop("reason", None)

    def _set_worker_available(rec: Dict[str, Any]) -> None:
        rec["status"] = "available"
        rec["allocated_at"] = None
        rec["allocated_by"] = None
        rec["session_id"] = None
        rec.pop("reason", None)
        rec.pop("moved_at", None)
        rec.pop("resetting_at", None)

    def _pool_reconcile_loop():
        interval_s = max(5.0, float(os.environ.get("POOL_RECONCILE_INTERVAL", "30")))
        resetting_check_interval_s = max(5.0, float(os.environ.get("POOL_RESETTING_CHECK_INTERVAL", "30")))
        resetting_stuck_timeout_s = max(
            30.0,
            float(os.environ.get("POOL_RESETTING_STUCK_TIMEOUT", str(resetting_stuck_timeout_s_cfg))),
        )
        probe_timeout_s = max(0.5, float(os.environ.get("POOL_RECONCILE_TIMEOUT", "5")))
        probe_retries = max(1, int(os.environ.get("POOL_RECONCILE_RETRIES", "2")))
        probe_retry_delay_s = max(0.1, float(os.environ.get("POOL_RECONCILE_RETRY_DELAY", "5")))
        while not background_stop.is_set():
            try:
                if background_stop.wait(interval_s):
                    break
                now_ts = time.time()
                with pool_lock:
                    snapshot = load_pool()
                    candidates = [
                        dict(rec)
                        for rec in (snapshot.get("workers") or [])
                        if rec.get("status") in {"available", "unavailable", "resetting"}
                    ]

                if not candidates:
                    continue

                desired: Dict[str, Tuple[str, str]] = {}
                for worker in candidates:
                    host = worker.get("worker_host")
                    port_raw = worker.get("worker_port")
                    key = _worker_endpoint_key(worker)
                    try:
                        port = int(port_raw)
                    except Exception:
                        logging.exception(
                            "Pool reconcile got invalid worker port key=%s raw_port=%r",
                            key,
                            port_raw,
                        )
                        desired[key] = ("unavailable", "invalid_endpoint")
                        continue

                    if not host or port <= 0:
                        desired[key] = ("unavailable", "invalid_endpoint")
                        continue

                    healthy, status_val = _probe_worker_health_quiet(
                        host,
                        port,
                        timeout_s=probe_timeout_s,
                        retries=probe_retries,
                        delay_s=probe_retry_delay_s,
                    )
                    current_status = worker.get("status")
                    if current_status == "available" and not healthy:
                        fail_n = _record_probe_failure(host, port)
                        if fail_n >= probe_fail_threshold:
                            desired[key] = ("unavailable", f"ping={status_val}")
                    elif current_status == "unavailable" and healthy:
                        _record_probe_success(host, port)
                        desired[key] = ("available", "recovered")
                    elif current_status == "resetting":
                        resetting_at = float(worker.get("resetting_at") or worker.get("moved_at") or 0.0)
                        if resetting_at <= 0:
                            logging.warning(
                                "Worker %s stuck in resetting without timestamp; marking unavailable",
                                key,
                            )
                            desired[key] = ("unavailable", "reset_stuck_missing_timestamp")
                            continue
                        resetting_age_s = now_ts - resetting_at
                        if resetting_age_s >= resetting_stuck_timeout_s:
                            logging.warning(
                                "Worker %s stuck in resetting for %.1fs (>= %.1fs); marking unavailable",
                                key,
                                resetting_age_s,
                                resetting_stuck_timeout_s,
                            )
                            desired[key] = (
                                "unavailable",
                                f"reset_stuck>{int(resetting_stuck_timeout_s)}s",
                            )
                            continue
                        if resetting_age_s < resetting_check_interval_s:
                            continue
                        if healthy:
                            desired[key] = ("available", "reset_recovered")

                if not desired:
                    continue

                changed = 0
                with pool_lock:
                    pool = load_pool()
                    for rec in pool.get("workers") or []:
                        key = _worker_endpoint_key(rec)
                        action = desired.get(key)
                        if not action:
                            continue
                        target_status, reason = action
                        current = rec.get("status")
                        if current not in {"available", "unavailable", "resetting"}:
                            continue
                        if target_status == "unavailable" and current != "unavailable":
                            _set_worker_unavailable(rec, reason)
                            changed += 1
                        elif target_status == "available" and current in {"unavailable", "resetting"}:
                            _set_worker_available(rec)
                            changed += 1
                    if changed:
                        save_pool(pool)
                        logging.info("Pool reconcile updated %s worker(s)", changed)
            except Exception as e:
                logging.error(f"Pool reconcile error: {e}")
                if background_stop.wait(5):
                    break

    def _allocator_loop():
        while not background_stop.is_set():
            try:
                with pending_lock:
                    items = list(pending_queue)
                if not items:
                    if background_stop.wait(0.5):
                        break
                    continue
                done_item_ids: set[int] = set()
                for item in items:
                    if item.get("canceled"):
                        done_item_ids.add(id(item))
                        continue
                    prefer_host = item.get("prefer_host")
                    # Allocate with proper locking to prevent race conditions
                    with pool_lock:
                        pool = load_pool()
                        # Find available worker that's not in resetting state
                        w = None
                        for rec in pool.get("workers") or []:
                            if rec.get("status") == "available":
                                if prefer_host and rec.get("worker_host") != prefer_host:
                                    continue
                                w = rec.copy()
                                # Atomically mark as allocated
                                rec["status"] = "allocated"
                                rec["allocated_at"] = int(time.time())
                                break
                        if not w:
                            continue
                        save_pool(pool)

                    host = w.get("worker_host")
                    port_raw = w.get("worker_port")
                    try:
                        port = int(port_raw)
                    except Exception:
                        logging.exception(
                            "Allocator got invalid worker endpoint worker=%s raw_port=%r",
                            w,
                            port_raw,
                        )
                        try:
                            with pool_lock:
                                pool = load_pool()
                                for rec in pool.get("workers") or []:
                                    if rec.get("worker_host") == w.get("worker_host") and rec.get("worker_port") == w.get("worker_port"):
                                        rec["status"] = "available"
                                        break
                                save_pool(pool)
                                move_worker_to_unavailable(w, reason="invalid_endpoint")
                        except Exception as e:
                            logging.error(f"Failed to move invalid worker to unavailable: {e}")
                        continue
                    if not host or port <= 0:
                        try:
                            with pool_lock:
                                pool = load_pool()
                                for rec in pool.get("workers") or []:
                                    if rec.get("worker_host") == w.get("worker_host") and rec.get("worker_port") == w.get("worker_port"):
                                        rec["status"] = "available"
                                        break
                                save_pool(pool)
                                move_worker_to_unavailable(w, reason="invalid_endpoint")
                        except Exception as e:
                            logging.error(f"Failed to move invalid worker to unavailable: {e}")
                        continue
                    headers = _auth_headers()
                    base = f"http://{host}:{port}"
                    healthy, status_val = _check_worker_health(base, headers)
                    if healthy:
                        session_id = str(uuid.uuid4())
                        with pool_lock:
                            pool = load_pool()
                            for rec in pool.get("workers") or []:
                                if rec.get("worker_host") == w.get("worker_host") and rec.get("worker_port") == w.get("worker_port"):
                                    rec["session_id"] = session_id
                                    break
                            save_pool(pool)
                        # Update heartbeat
                        worker_key = f"{host}:{port}"
                        with worker_heartbeat_lock:
                            worker_heartbeats[worker_key] = time.time()
                        alloc = {
                            "session_id": session_id,
                            "vm_name": w.get("vm_name"),
                            "http_endpoint": w.get("http_endpoint"),
                            "worker_host": w.get("worker_host"),
                            "worker_port": w.get("worker_port"),
                        }
                        item["result"] = alloc
                        done_item_ids.add(id(item))
                    else:
                        # Rollback status on probe failure.
                        try:
                            with pool_lock:
                                pool = load_pool()
                                for rec in pool.get("workers") or []:
                                    if rec.get("worker_host") == w.get("worker_host") and rec.get("worker_port") == w.get("worker_port"):
                                        rec["status"] = "available"
                                        rec["allocated_at"] = None
                                        break
                                save_pool(pool)
                                fail_n = _record_probe_failure(host, port)
                                if fail_n >= probe_fail_threshold:
                                    move_worker_to_unavailable(w, reason=f"ping={status_val}")
                        except Exception as e:
                            logging.error(f"Failed to move worker {base} to unavailable: {e}")
                if done_item_ids:
                    with pending_lock:
                        pending_queue[:] = [it for it in pending_queue if id(it) not in done_item_ids]
                else:
                    if background_stop.wait(0.5):
                        break
            except Exception as e:
                logging.error(f"Allocator loop error: {e}")
                if background_stop.wait(0.5):
                    break

    def _ensure_allocator():
        nonlocal alloc_thread_started
        if alloc_thread_started:
            return
        with alloc_lock:
            if alloc_thread_started:
                return
            t = threading.Thread(target=_allocator_loop, daemon=True)
            t.start()
            alloc_thread_started = True

    sessions: Dict[str, Dict[str, Any]] = {}
    # Track worker heartbeats and last activity time
    worker_heartbeats: Dict[str, float] = {}  # (worker_host, worker_port) -> timestamp
    worker_heartbeat_lock = threading.Lock()
    rl_framework = str(cfg["rl_framework"]).lower()
    gui_model_name = str(cfg["gui_model"]).lower()
    server_cfg = cfg.get("server") or {}
    controller_port = int(server_cfg.get("port"))
    firewall_cfg = cfg.get("controller_firewall") or {}
    manage_controller_ufw = bool(firewall_cfg.get("manage_ufw", True))
    controller_firewall_worker_ips = [
        str(ip).strip()
        for ip in (firewall_cfg.get("worker_ips") or [])
        if str(ip or "").strip()
    ]
    controller_firewall_sudo_password = str(firewall_cfg.get("sudo_password") or "")
    controller_ufw_applied_ips: List[str] = []
    if manage_controller_ufw and controller_firewall_worker_ips:
        controller_ufw_applied_ips = _apply_controller_ufw_rules(
            worker_ips=controller_firewall_worker_ips,
            port=controller_port,
            sudo_password=controller_firewall_sudo_password,
        )
    elif manage_controller_ufw:
        logging.warning("Controller UFW setup skipped: no worker IPs configured")
    else:
        logging.info("Controller UFW setup disabled by config")
    controller_base = str(os.environ.get("CONTROLLER_BASE_URL") or "").strip()
    if not controller_base:
        controller_host = str(server_cfg.get("public_host") or server_cfg.get("host"))
        controller_base = f"http://{controller_host}:{controller_port}"
    cache_root = Path(__file__).resolve().parent / "total_downcache"
    try:
        cache_root.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logging.error(f"Failed to create cache root {cache_root}: {e}")
    parser_cls = get_model_class(gui_model_name)
    if not parser_cls:
        raise RuntimeError(f"gui model '{gui_model_name}' not registered")
    parser = parser_cls()
    adapter = ARealAdapter() if rl_framework == "areal" else None

    # Worker disconnect timeout (seconds). Keep this above long single-turn inference latency.
    WORKER_HEARTBEAT_TIMEOUT = float(
        os.environ.get("WORKER_HEARTBEAT_TIMEOUT", str(worker_heartbeat_timeout_s))
    )

    def _coerce_task_meta(raw_config: Optional[Any]) -> Dict[str, Any]:
        if not isinstance(raw_config, dict):
            return {"source": "legacy_task_config"}

        if "vibe_config" in raw_config and isinstance(raw_config.get("vibe_config"), dict):
            vibe_cfg = raw_config.get("vibe_config") or {}
            app_type = str(
                vibe_cfg.get("active_app")
                or vibe_cfg.get("app_type")
                or raw_config.get("app_type")
                or raw_config.get("application")
                or "wechat"
            )
            task: Dict[str, Any] = {}
            apps = vibe_cfg.get("apps")
            if isinstance(apps, list) and apps:
                first = apps[0]
                if isinstance(first, dict):
                    app_type = str(first.get("app_type") or first.get("application") or app_type)
                    if isinstance(first.get("task"), dict):
                        task = dict(first["task"])
            if not task:
                if isinstance(vibe_cfg.get("task"), dict):
                    task = dict(vibe_cfg.get("task") or {})
            task_type = str(task.get("task_type") or task.get("type") or "default")
            difficulty_raw = task.get("difficulty", task.get("level", 1))
            try:
                difficulty = int(difficulty_raw)
            except (TypeError, ValueError):
                difficulty = 1
            return {
                "source": "vibe_config",
                "app_type": app_type,
                "task_type": task_type,
                "task_id": task.get("instruction_id"),
                "instruction_id": task.get("instruction_id"),
                "difficulty": difficulty,
                "instruction": str(
                    task.get("instruction")
                    or task.get("instruction_text")
                    or f"{app_type}:{task_type}:{difficulty}"
                ),
            }

        return {
            "source": "legacy_task_config",
            "app_type": str(
                raw_config.get("app_type")
                or raw_config.get("application")
                or "wechat"
            ),
            "task_type": str(raw_config.get("task_type") or raw_config.get("type") or "default"),
            "task_id": str(raw_config.get("instruction_id") or raw_config.get("id") or raw_config.get("task_id") or ""),
            "instruction_id": raw_config.get("instruction_id"),
            "instruction": str(raw_config.get("instruction") or ""),
            "difficulty": (
                int(raw_config.get("difficulty"))
                if str(raw_config.get("difficulty", "")).strip().isdigit()
                else 1
            ),
        }

    def _coerce_trajectory_meta(req: BatchSessionStartRequest, raw_config: Optional[Any]) -> Dict[str, Any]:
        req_instruction = str(req.instruction or "").strip()
        req_task_id = str(req.task_id or "").strip()
        return {
            "request": {
                "instruction": req_instruction,
                "task_id": req_task_id,
            },
            "has_vibe_config": bool(
                isinstance(raw_config, dict)
                and isinstance(raw_config.get("vibe_config"), dict)
            ),
            "config_present": raw_config is not None,
        }

    def _coerce_summary_payload(
        session_id: str,
        *,
        success: bool,
        session: Optional[Dict[str, Any]] = None,
        terminal_error: Optional[str] = None,
    ) -> Dict[str, Any]:
        sess = session or sessions.get(session_id) or {}
        payload = {
            "session_id": session_id,
            "success": bool(success),
            "task_id": sess.get("task_id", ""),
            "instruction_id": sess.get("task_meta", {}).get("instruction_id"),
            "task_name": sess.get("task_name", ""),
            "instruction": sess.get("instruction", ""),
            "total_steps": sess.get("traj_steps", 0),
            "last_reward": sess.get("last_reward", 0.0),
            "done": sess.get("done", False),
            "task_meta": sess.get("task_meta", {}),
            "trajectory_meta": sess.get("trajectory_meta", {}),
        }
        if terminal_error:
            payload["terminal_error"] = terminal_error
        return payload

    def _finish_session_trajectory(
        session_id: str,
        success: bool,
        summary: Optional[Dict[str, Any]] = None,
    ) -> None:
        sess = sessions.get(session_id)
        if not isinstance(sess, dict):
            return
        traj_id = sess.get("traj_id")
        if not traj_id:
            return
        payload = _coerce_summary_payload(
            session_id,
            success=bool(success),
            session=sess,
        )
        if summary:
            payload.update(summary)
        try:
            traj.finish_trajectory(
                traj_id,
                success=bool(success),
                final_screenshot=None,
                summary=payload,
            )
        except Exception as e:
            logging.error(f"Finish trajectory failed for session {session_id}: {e}")

    def _session_cleanup_loop():
        while not background_stop.is_set():
            try:
                if background_stop.wait(60):  # Check every minute
                    break
                pool = load_pool()
                now = time.time()
                timeout_threshold = 3600  # 1 hour timeout for sessions

                # Check for session timeouts
                for rec in pool.get("workers") or []:
                    if rec.get("status") == "allocated" and rec.get("session_id"):
                        allocated_at = rec.get("allocated_at", 0)
                        if now - allocated_at > timeout_threshold:
                            logging.warning(f"Session {rec['session_id']} timeout, releasing")
                            try:
                                _release_worker(session_id=rec["session_id"], do_reset=False)
                            except Exception as e:
                                logging.error(f"Failed to release timeout session: {e}")

                # Check for worker heartbeats and cleanup disconnected workers
                with worker_heartbeat_lock:
                    dead_workers = []
                    for worker_key, last_heartbeat in list(worker_heartbeats.items()):
                        if now - last_heartbeat > WORKER_HEARTBEAT_TIMEOUT:
                            dead_workers.append((worker_key, last_heartbeat))

                    for worker_key, last_heartbeat in dead_workers:
                        host, port = worker_key.split(":")
                        try:
                            port_int = int(port)
                        except Exception:
                            logging.warning(f"Invalid worker port in heartbeat key: {worker_key}")
                            continue
                        logging.warning(f"Worker {host}:{port} heartbeat timeout (> {WORKER_HEARTBEAT_TIMEOUT}s), resetting and releasing back to pool")
                        del worker_heartbeats[worker_key]

                        # Find and cleanup the worker
                        with pool_lock:
                            pool = load_pool()
                            target_rec = None
                            for rec in pool.get("workers") or []:
                                if rec.get("worker_host") == host and int(rec.get("worker_port", 0)) == port_int:
                                    target_rec = rec
                                    break

                            if not target_rec:
                                continue

                            # Clean up session if exists
                            if target_rec.get("session_id"):
                                try:
                                    sess_id = target_rec["session_id"]
                                    _finish_session_trajectory(
                                        sess_id,
                                        success=False,
                                        summary={
                                            "terminal_error": "worker_heartbeat_timeout",
                                        },
                                    )
                                    sessions.pop(sess_id, None)
                                    logging.info(f"Cleaned up session {sess_id} for dead worker {host}:{port}")
                                except Exception as e:
                                    logging.error(f"Failed to cleanup session for dead worker: {e}")

                            # Mark as resetting (will be reset in background thread)
                            _set_worker_resetting(target_rec)
                            save_pool(pool)

                            # Reset VM in background thread and mark available after successful reset
                            reset_host = host
                            reset_port = port_int

                            def _reset_and_release_worker(host_arg: str = reset_host, port_arg: int = reset_port):
                                success = _reset_worker_with_health_check(
                                    host_arg,
                                    port_arg,
                                    mark_available_on_success=True
                                )
                                if not success:
                                    with pool_lock:
                                        move_worker_to_unavailable(
                                            {"worker_host": host_arg, "worker_port": port_arg},
                                            reason="reset_health_failed",
                                        )

                            threading.Thread(target=_reset_and_release_worker, daemon=True).start()

            except Exception as e:
                logging.error(f"Session cleanup error: {e}")
                if background_stop.wait(5):
                    break

    cleanup_thread = threading.Thread(target=_session_cleanup_loop, daemon=True)
    cleanup_thread.start()
    reconcile_thread = threading.Thread(target=_pool_reconcile_loop, daemon=True)
    reconcile_thread.start()

    cleanup_once = threading.Event()

    async def _cleanup_all_resources(reason: str) -> None:
        if cleanup_once.is_set():
            return
        cleanup_once.set()
        background_stop.set()
        # Uvicorn may not propagate INFO logs from the root logger; use WARNING for visibility.
        logging.warning(f"Controller shutdown cleanup started (reason={reason})")

        try:
            for sid, s in list(sessions.items()):
                try:
                    if s.get("traj_id"):
                        traj.finish_trajectory(s["traj_id"], success=False, final_screenshot=None)
                except Exception as e:
                    logging.error(f"Shutdown finish trajectory failed for {sid}: {e}")
                finally:
                    sessions.pop(sid, None)
        except Exception as e:
            logging.error(f"Shutdown cleanup session loop failed: {e}")

        try:
            destroy_summary = await asyncio.to_thread(
                destroy_workers,
                prefer_host=None,
                status_filter="",
                concurrency=cleanup_concurrency,
                timeout=cleanup_timeout_s,
                remove_from_pool=True,
            )
            logging.warning(f"Shutdown destroy_workers summary: {destroy_summary}")
        except Exception as e:
            logging.error(f"Shutdown destroy_workers failed: {e}")

        try:
            fallback_summary = await asyncio.to_thread(cleanup_cluster_nodes)
            logging.warning(f"Shutdown ansible fallback cleanup summary: {fallback_summary}")
            clear_pools()
        except Exception as e:
            logging.error(f"Shutdown ansible fallback cleanup failed: {e}")
        finally:
            if manage_controller_ufw:
                _revoke_controller_ufw_rules(
                    worker_ips=(controller_ufw_applied_ips or controller_firewall_worker_ips),
                    port=controller_port,
                    sudo_password=controller_firewall_sudo_password,
                )

    @app.on_event("shutdown")
    async def _on_shutdown():
        await _cleanup_all_resources("uvicorn_shutdown")

    def _cancel_pending(items: List[Dict[str, Any]]) -> None:
        if not items:
            return
        for item in items:
            item["canceled"] = True
        remove_ids = {id(it) for it in items}
        with pending_lock:
            pending_queue[:] = [it for it in pending_queue if id(it) not in remove_ids]

    class BatchSessionStartRequest(BaseModel):
        # NOTE: `task_config` may be either a structured dict (task metadata + config)
        # or a plain list of setup steps (env worker expects this under the `config` field).
        task_config: Optional[Union[Dict[str, Any], List[Dict[str, Any]]]] = None
        # Backward-compatible alias for older clients that send `config`.
        config: Optional[Union[Dict[str, Any], List[Dict[str, Any]]]] = None
        # Optional task metadata from caller for trace naming/recording.
        instruction: Optional[str] = None
        task_id: Optional[str] = None
        count: int = 1

    class ControllerStepRequest(BaseModel):
        session_id: str
        output: str = ""
        extras: Dict[str, Any] = {}
        pause: int = 1

    class SessionFinishRequest(BaseModel):
        session_id: str
        success: bool = True

    def _auth_headers() -> Dict[str, str]:
        token = os.environ.get(APP_TOKEN_ENV)
        return {"Authorization": f"Bearer {token}"} if token else {}

    def _reset_worker_with_health_check(host: str, port: int, mark_available_on_success: bool = True) -> bool:
        """Reset a worker and verify health status.

        Args:
            host: Worker host address
            port: Worker port
            mark_available_on_success: If True, mark worker as available when health check passes

        Returns:
            bool: True if reset and health check succeeded, False otherwise
        """
        try:
            headers = _auth_headers()
            base = f"http://{host}:{int(port)}"
            _internal_request(
                "POST",
                base + "/reset",
                headers=headers,
                json={"task_config": None},
                timeout=(5, max(5.0, worker_reset_timeout_s)),
            )

            # After reset, verify health
            healthy, _ = _check_worker_health(base, headers, retries=3, delay_s=2.0)
            if healthy:
                if mark_available_on_success:
                    with pool_lock:
                        pool = load_pool()
                        for rec in pool.get("workers") or []:
                            if rec.get("worker_host") == host and rec.get("worker_port") == int(port):
                                _set_worker_available(rec)
                                break
                        save_pool(pool)
                logging.info(f"Worker {host}:{port} reset and health check passed")
                return True
            else:
                logging.error(f"Worker {host}:{port} reset but health check failed")
                return False
        except Exception as e:
            logging.error(f"Failed to reset worker {host}:{port}: {e}")
            return False

    def _require_auth(authorization: Optional[str]):
        expected = os.environ.get(APP_TOKEN_ENV)
        if not expected:
            return True
        if not authorization:
            raise HTTPException(status_code=401, detail="missing bearer token")
        if not authorization.lower().startswith("bearer "):
            raise HTTPException(status_code=401, detail="invalid auth header")
        token = authorization.split(" ", 1)[1].strip()
        if token != expected:
            raise HTTPException(status_code=403, detail="forbidden")
        return True

    @app.get("/cache/fetch")
    def cache_fetch(url: str, authorization: Optional[str] = Header(None)):
        _require_auth(authorization)
        if not url:
            raise HTTPException(status_code=400, detail="missing url")
        try:
            parsed = urllib.parse.urlparse(url)
            url_path = parsed.path or ""
            ext = os.path.splitext(url_path)[1]
        except Exception:
            logging.exception("Failed to parse cache url extension: %s", url)
            ext = ""
        cache_name = f"{uuid.uuid5(uuid.NAMESPACE_URL, url).hex}{ext}"
        cache_path = cache_root / cache_name
        if not cache_path.exists():
            tmp = cache_root / f"{cache_name}.part.{os.getpid()}"
            last_err = None
            try:
                r = requests.get(url, stream=True, timeout=(10, 600))
                r.raise_for_status()
                with open(tmp, "wb") as fp:
                    for chunk in r.iter_content(chunk_size=1024*1024):
                        if chunk:
                            fp.write(chunk)
                if cache_path.exists():
                    try:
                        os.remove(tmp)
                    except Exception as e:
                        logging.error(f"remove tmp cache failed {tmp}: {e}")
                else:
                    os.replace(tmp, cache_path)
            except Exception as e:
                last_err = str(e)
                try:
                    if tmp.exists():
                        os.remove(tmp)
                except Exception as e:
                    logging.error(f"cleanup tmp cache failed {tmp}: {e}")
                raise HTTPException(status_code=502, detail=f"download failed: {last_err}")
        return FileResponse(str(cache_path))

    @app.get("/health")
    def health():
        try:
            pool = load_pool()
            workers = pool.get("workers") or []
            status_counts: Dict[str, int] = {}
            for rec in workers:
                status = str(rec.get("status") or "unknown")
                status_counts[status] = status_counts.get(status, 0) + 1
            with pending_lock:
                pending_count = len(pending_queue)
            return {
                "status": "ok",
                "pool_size": len(workers),
                "status_counts": status_counts,
                "pending_requests": pending_count,
                "timestamp": time.time(),
            }
        except Exception as e:
            logging.error(f"health check failed: {e}")
            raise HTTPException(status_code=500, detail="health check failed")

    def _release_worker(session_id: str = "", do_reset: bool = True):
        # Update pool first under lock; do not hold lock during any network calls.
        reset_host = None
        reset_port = None
        with pool_lock:
            pool = load_pool()
            target = None
            for rec in pool.get("workers") or []:
                if rec.get("session_id") == session_id:
                    target = rec
                    break
            if not target:
                raise HTTPException(status_code=404, detail="session not found")
            # Mark as resetting (not available yet)
            if do_reset:
                _set_worker_resetting(target)
            else:
                _set_worker_available(target)
            reset_host = target.get("worker_host")
            reset_port = target.get("worker_port")
            save_pool(pool)

        # Clear heartbeat tracking for released sessions to avoid stale-heartbeat resets.
        if reset_host and reset_port is not None:
            try:
                worker_key = f"{str(reset_host)}:{int(reset_port)}"
                with worker_heartbeat_lock:
                    worker_heartbeats.pop(worker_key, None)
            except Exception:
                logging.exception(
                    "Failed to clear worker heartbeat on release session_id=%s host=%s port=%r",
                    session_id,
                    reset_host,
                    reset_port,
                )

        # Perform reset asynchronously with health check
        if do_reset and reset_host and reset_port is not None:
            try:
                reset_port_int = int(reset_port)
            except Exception:
                logging.exception(
                    "Invalid reset worker port session_id=%s host=%s raw_port=%r",
                    session_id,
                    reset_host,
                    reset_port,
                )
                reset_port_int = None
                with pool_lock:
                    move_worker_to_unavailable(
                        {"worker_host": reset_host, "worker_port": reset_port},
                        reason="invalid_endpoint",
                    )
            if reset_port_int is not None:
                def _reset_and_verify(host_arg: str = str(reset_host), port_arg: int = int(reset_port_int)):
                    endpoint = {"worker_host": host_arg, "worker_port": port_arg}
                    success = _reset_worker_with_health_check(
                        host_arg,
                        port_arg,
                        mark_available_on_success=True
                    )
                    if not success:
                        with pool_lock:
                            move_worker_to_unavailable(endpoint, reason="reset_health_failed")

                threading.Thread(target=_reset_and_verify, daemon=True).start()

        sess = sessions.get(session_id)
        if sess:
            _finish_session_trajectory(
                session_id=session_id,
                success=bool(sess.get("success", True)),
                summary=_coerce_summary_payload(
                    session_id,
                    success=bool(sess.get("success", True)),
                    session=sess,
                    terminal_error="release_called",
                ),
            )
        sessions.pop(session_id, None)
        return {"released": True}

    @app.post("/session/start_batch")
    async def session_start_batch(req: BatchSessionStartRequest, authorization: Optional[str] = Header(None)):
        _require_auth(authorization)

        count = req.count
        if count <= 0:
            raise HTTPException(status_code=400, detail="count must be positive")
        deadline = (time.time() + alloc_batch_timeout_s) if alloc_batch_timeout_s > 0 else None
        initial_reset_retries = max(1, int(os.environ.get("START_BATCH_INITIAL_RESET_RETRIES", "3")))
        initial_reset_retry_delay_s = max(
            0.0,
            float(os.environ.get("START_BATCH_INITIAL_RESET_RETRY_DELAY_S", "2.0")),
        )

        async def _allocate_workers(required_count: int) -> List[Dict[str, Any]]:
            if required_count <= 0:
                return []
            pend_items = [{"prefer_host": None, "result": None, "canceled": False} for _ in range(required_count)]
            # Enqueue atomically so concurrent start_batch calls don't interleave pending items.
            with pending_lock:
                pending_queue.extend(pend_items)
            _ensure_allocator()

            try:
                while True:
                    current_alloc = [p["result"] for p in pend_items if p.get("result")]
                    if len(current_alloc) >= required_count:
                        break
                    if deadline is not None and time.time() >= deadline:
                        break
                    await asyncio.sleep(0.05)
            except asyncio.CancelledError:
                current_alloc = [p["result"] for p in pend_items if p.get("result")]
                for alloc in current_alloc:
                    try:
                        _release_worker(session_id=alloc["session_id"], do_reset=False)
                    except Exception:
                        logging.exception("Failed to release worker during start_batch cancellation: %s", alloc)
                _cancel_pending(pend_items)
                raise

            with pending_lock:
                queued_ids = {id(it) for it in pending_queue}
            still_pending = [p for p in pend_items if id(p) in queued_ids]
            _cancel_pending(still_pending)
            return [p["result"] for p in pend_items if p.get("result")]

        allocated = await _allocate_workers(count)
        if len(allocated) != count:
            for alloc in allocated:
                try:
                    _release_worker(session_id=alloc["session_id"], do_reset=False)
                except Exception as e:
                    logging.error(f"Failed to release worker: {e}")
            raise HTTPException(status_code=503, detail=f"Only {len(allocated)}/{count} workers available")

        headers = _auth_headers()
        raw_config = req.task_config if req.task_config is not None else req.config

        async def _reset_one(alloc: Dict[str, Any]) -> Tuple[str, Optional[str]]:
            base = f"http://{alloc['worker_host']}:{int(alloc['worker_port'])}"
            sid = str(alloc["session_id"])
            last_reason: Optional[str] = None
            for attempt in range(1, initial_reset_retries + 1):
                started = time.time()
                try:
                    resp = await asyncio.to_thread(
                        _internal_request,
                        "POST",
                        base + "/reset",
                        headers=headers,
                        json={},
                        timeout=worker_reset_timeout_s,
                    )
                    if resp.status_code != 200:
                        last_reason = f"http={resp.status_code}"
                        logging.error(
                            "Initial reset failed for %s (attempt %s/%s): %s elapsed=%.2fs",
                            base,
                            attempt,
                            initial_reset_retries,
                            last_reason,
                            time.time() - started,
                        )
                    else:
                        healthy, status_val = await asyncio.to_thread(_check_worker_health, base, headers)
                        if healthy:
                            return sid, None
                        last_reason = f"health={status_val}"
                        logging.error(
                            "Initial reset health check failed for %s (attempt %s/%s): %s elapsed=%.2fs",
                            base,
                            attempt,
                            initial_reset_retries,
                            last_reason,
                            time.time() - started,
                        )
                except Exception as e:
                    last_reason = f"error:{type(e).__name__}"
                    logging.error(
                        "Initial reset failed for %s (attempt %s/%s): %s elapsed=%.2fs",
                        base,
                        attempt,
                        initial_reset_retries,
                        e,
                        time.time() - started,
                    )

                if attempt < initial_reset_retries and initial_reset_retry_delay_s > 0:
                    await asyncio.sleep(initial_reset_retry_delay_s)

            return sid, (last_reason or "unknown")

        async def _setup_one(alloc: Dict[str, Any]) -> Tuple[str, Optional[str]]:
            if raw_config is None:
                return str(alloc["session_id"]), None
            base = f"http://{alloc['worker_host']}:{int(alloc['worker_port'])}"
            sid = str(alloc["session_id"])
            base_payload: Dict[str, Any] = {}
            if isinstance(raw_config, dict):
                base_payload["task_config"] = raw_config
            elif isinstance(raw_config, list):
                base_payload["config"] = raw_config
            else:
                return sid, None

            async def _setup_attempt(use_cache: bool) -> Tuple[Optional[str], float]:
                payload = dict(base_payload)
                if use_cache:
                    payload["cache_endpoint"] = controller_base
                started = time.time()
                try:
                    resp = await asyncio.to_thread(
                        _internal_request,
                        "POST",
                        base + "/setup",
                        headers=headers,
                        json=payload,
                        timeout=worker_setup_timeout_s,
                    )
                    if resp.status_code != 200:
                        reason = f"http={resp.status_code}"
                        logging.error(
                            "Initial setup failed for %s (use_cache=%s): %s elapsed=%.2fs",
                            base,
                            use_cache,
                            reason,
                            time.time() - started,
                        )
                        return reason, (time.time() - started)
                    healthy, status_val = await asyncio.to_thread(_check_worker_health, base, headers)
                    if not healthy:
                        reason = f"health={status_val}"
                        logging.error(
                            "Initial setup health check failed for %s (use_cache=%s): %s elapsed=%.2fs",
                            base,
                            use_cache,
                            reason,
                            time.time() - started,
                        )
                        return reason, (time.time() - started)
                    return None, (time.time() - started)
                except Exception as e:
                    reason = f"error:{type(e).__name__}"
                    logging.error(
                        "Initial setup failed for %s (use_cache=%s): %s elapsed=%.2fs",
                        base,
                        use_cache,
                        e,
                        time.time() - started,
                    )
                    return reason, (time.time() - started)

            reason1, elapsed1 = await _setup_attempt(use_cache=True)
            if reason1 is None:
                return sid, None

            logging.warning(
                "Retrying setup without cache for %s after cache-based failure: %s elapsed=%.2fs",
                base,
                reason1,
                elapsed1,
            )
            reason2, _ = await _setup_attempt(use_cache=False)
            if reason2 is None:
                return sid, None
            return sid, f"{reason1}|fallback_no_cache:{reason2}"

        ready_allocated: List[Dict[str, Any]] = []
        to_process = list(allocated)
        reset_fail_count = 0
        setup_fail_count = 0
        while to_process:
            try:
                reset_results = await asyncio.gather(*[_reset_one(alloc) for alloc in to_process])
            except asyncio.CancelledError:
                for alloc in ready_allocated + to_process:
                    try:
                        _release_worker(session_id=alloc["session_id"], do_reset=False)
                    except Exception:
                        logging.exception("Failed to release worker during reset cancellation: %s", alloc)
                raise

            reset_failures = {sid: reason for sid, reason in reset_results if reason}
            reset_fail_count += len(reset_failures)
            reset_ok_allocs: List[Dict[str, Any]] = []
            for alloc in to_process:
                sid = str(alloc["session_id"])
                if sid in reset_failures:
                    try:
                        with pool_lock:
                            move_worker_to_unavailable(
                                {"worker_host": alloc["worker_host"], "worker_port": alloc["worker_port"]},
                                reason=f"initial_reset_failed:{reset_failures[sid]}",
                            )
                    except Exception as e:
                        logging.error(f"Failed to move initial-reset failed worker to unavailable: {e}")
                else:
                    reset_ok_allocs.append(alloc)

            setup_ok_allocs: List[Dict[str, Any]] = []
            if reset_ok_allocs:
                try:
                    setup_results = await asyncio.gather(*[_setup_one(alloc) for alloc in reset_ok_allocs])
                except asyncio.CancelledError:
                    for alloc in ready_allocated + reset_ok_allocs:
                        try:
                            _release_worker(session_id=alloc["session_id"], do_reset=False)
                        except Exception:
                            logging.exception("Failed to release worker during setup cancellation: %s", alloc)
                    raise
                setup_failures = {sid: reason for sid, reason in setup_results if reason}
                setup_fail_count += len(setup_failures)
                for alloc in reset_ok_allocs:
                    sid = str(alloc["session_id"])
                    if sid in setup_failures:
                        try:
                            with pool_lock:
                                move_worker_to_unavailable(
                                    {"worker_host": alloc["worker_host"], "worker_port": alloc["worker_port"]},
                                    reason=f"initial_setup_failed:{setup_failures[sid]}",
                                )
                        except Exception as e:
                            logging.error(f"Failed to move initial-setup failed worker to unavailable: {e}")
                    else:
                        setup_ok_allocs.append(alloc)

            ready_allocated.extend(setup_ok_allocs)

            needed = count - len(ready_allocated)
            if needed <= 0:
                break
            replacement = await _allocate_workers(needed)
            if len(replacement) != needed:
                for alloc in ready_allocated + replacement:
                    try:
                        _release_worker(session_id=alloc["session_id"], do_reset=False)
                    except Exception as e:
                        logging.error(f"Failed to release worker after replacement allocation failure: {e}")
                raise HTTPException(
                    status_code=503,
                    detail=(
                        f"initial reset/setup failed (reset={reset_fail_count}, setup={setup_fail_count}); "
                        f"only {len(ready_allocated) + len(replacement)}/{count} workers recoverable"
                    ),
                )
            to_process = replacement

        allocated = ready_allocated
        if len(allocated) != count:
            for alloc in allocated:
                try:
                    _release_worker(session_id=alloc["session_id"], do_reset=False)
                except Exception as e:
                    logging.error(f"Failed to release worker after reset retries: {e}")
            raise HTTPException(
                status_code=503,
                detail=f"initial reset/setup failed (reset={reset_fail_count}, setup={setup_fail_count})",
            )

        agent_type = gui_model_name
        result_sessions = []
        task_meta = _coerce_task_meta(raw_config)
        trajectory_meta = _coerce_trajectory_meta(req, raw_config)
        req_instruction = str(req.instruction or "").strip()
        req_task_id = str(req.task_id or "").strip()
        task_name = (
            req_instruction
            or task_meta.get("instruction")
            or task_meta.get("instruct")
            or task_meta.get("task_name")
            or task_meta.get("task")
            or "task"
        )
        for alloc in allocated:
            cfg_for_traj = raw_config if isinstance(raw_config, list) else ([raw_config] if isinstance(raw_config, dict) else [])
            task_mode = "config" if cfg_for_traj else "no_config"
            traj_id = traj.start_trajectory(
                agent_type=agent_type,
                agent_id=str(agent_type),
                vm_name=alloc.get("vm_name") or "vm",
                task_name=task_name,
                instruction=req_instruction,
                task_mode=task_mode,
                config=cfg_for_traj,
                node_ip=str(alloc.get("worker_host") or ""),
                task_meta=task_meta,
                trajectory_meta=trajectory_meta,
            )
            sessions[alloc["session_id"]] = {
                "alloc": alloc,
                "traj_id": traj_id,
                "model_type": agent_type,
                "task_id": req_task_id,
                "instruction": req_instruction,
                "task_name": task_name,
                "config": raw_config,
                "success": True,
                "traj_steps": 0,
                "last_observation": {},
                "last_reward": 0.0,
                "done": False,
                "task_meta": task_meta,
                "trajectory_meta": trajectory_meta,
            }
            if hasattr(parser, "start_session"):
                try:
                    parser.start_session(alloc["session_id"], {"task_name": task_name, "vm_name": alloc.get("vm_name")})
                except Exception as e:
                    logging.error(f"parser.start_session failed: {e}")
            # Persist one initial screenshot right after successful reset so
            # trajectories are never empty when rollout fails before first step.
            try:
                worker_base = f"http://{alloc['worker_host']}:{int(alloc['worker_port'])}"
                ro = _internal_request(
                    "GET",
                    worker_base + "/observe",
                    headers=headers,
                    timeout=(10, 60),
                )
                if ro.status_code == 200:
                    init_obs = ro.json() or {}
                    ss = None
                    ss_b64 = init_obs.get("screenshot_b64") if isinstance(init_obs, dict) else None
                    if isinstance(ss_b64, str) and ss_b64:
                        try:
                            ss = base64.b64decode(ss_b64)
                        except Exception as e:
                            logging.error(f"Decode initial screenshot failed: {e}")
                            ss = None
                    init_state = init_obs if isinstance(init_obs, dict) else {}
                    traj_state = init_state
                    if traj_state:
                        # avoid raw screenshot bytes in trajectory JSON payload.
                        traj_state = dict(traj_state)
                        traj_state.pop("screenshot_b64", None)
                    traj.add_step(
                        traj_id,
                        observation=init_obs,
                        screenshot=ss,
                        raw_output="__session_started__",
                        parsed_action_code={"type": "INIT_OBSERVE"},
                        state_before=traj_state,
                        state_after=traj_state,
                    )
                    sess = sessions.get(alloc["session_id"])
                    if isinstance(sess, dict):
                        sess["last_observation"] = traj_state
                else:
                    logging.warning(
                        "Initial observe failed: worker=%s status=%s",
                        worker_base,
                        ro.status_code,
                    )
            except Exception as e:
                logging.error(f"Initial observe failed for session {alloc.get('session_id')}: {e}")
            result_sessions.append(alloc)

        return {"sessions": result_sessions, "count": len(result_sessions)}

    @app.post("/session/step")
    def session_step(req: ControllerStepRequest, authorization: Optional[str] = Header(None)):
        _require_auth(authorization)
        sess = sessions.get(req.session_id)
        alloc = sess.get("alloc") if isinstance(sess, dict) else None
        worker_host = alloc.get("worker_host") if isinstance(alloc, dict) else None
        worker_port = alloc.get("worker_port") if isinstance(alloc, dict) else None

        def _failure_response(
            *,
            error: str,
            done: bool = True,
            fail: bool = True,
            parse_failed: bool = False,
            results: Optional[List[Dict[str, Any]]] = None,
            observation: Optional[Dict[str, Any]] = None,
        ) -> Dict[str, Any]:
            safe_observation = dict(observation or {})
            safe_observation.setdefault("screenshot_b64", "")
            safe_observation["done"] = bool(done)
            safe_observation["fail"] = bool(fail)
            safe_observation.setdefault("obs_str", str(error or "session step failed"))
            if parse_failed:
                info = safe_observation.get("info")
                if not isinstance(info, dict):
                    info = {}
                info["parse_failed"] = True
                safe_observation["info"] = info
            wrapped = adapter.wrap_observation(safe_observation) if adapter else safe_observation
            wrapped["done"] = bool(done)
            wrapped["fail"] = bool(fail)
            info = wrapped.get("info")
            if not isinstance(info, dict):
                info = {}
            if parse_failed:
                info["parse_failed"] = True
            wrapped["info"] = info
            return {
                "results": list(results or []),
                "observation": wrapped,
            }

        try:
            # Update heartbeat on activity
            if worker_host and worker_port is not None:
                worker_key = f"{worker_host}:{worker_port}"
                with worker_heartbeat_lock:
                    worker_heartbeats[worker_key] = time.time()

            if not worker_host or worker_port is None:
                pool = load_pool()
                target = None
                for rec in pool.get("workers") or []:
                    if rec.get("session_id") == req.session_id:
                        target = rec
                        break
                if not target:
                    logging.warning(
                        "session_step session not found: session_id=%s (missing in sessions + pool)",
                        req.session_id,
                    )
                    raise HTTPException(status_code=404, detail="session not found")
                worker_host = target.get("worker_host")
                worker_port = target.get("worker_port")
                if worker_host and worker_port is not None:
                    worker_key = f"{worker_host}:{worker_port}"
                    with worker_heartbeat_lock:
                        worker_heartbeats[worker_key] = time.time()

            worker_base = (
                f"http://{worker_host}:{int(worker_port)}" if worker_host and worker_port is not None else None
            )
            if not worker_base:
                logging.error(
                    "session_step missing endpoints: session_id=%s worker_host=%s worker_port=%s",
                    req.session_id,
                    worker_host,
                    worker_port,
                )
                raise HTTPException(status_code=500, detail="missing endpoints")
            headers = _auth_headers()
            observe_connect_timeout_s = float(os.environ.get("ENV_OBSERVE_CONNECT_TIMEOUT_S", "10.0"))
            observe_timeout_s = float(os.environ.get("ENV_OBSERVE_TIMEOUT_S", "60.0"))
            observe_timeout = (
                (observe_connect_timeout_s, None)
                if observe_timeout_s <= 0
                else (observe_connect_timeout_s, observe_timeout_s)
            )
            results: List[Dict[str, Any]] = []
            last_observation: Dict[str, Any] = {}
            prior_observation: Dict[str, Any] = {}
            raw_output_recorded = False
            m = parser
            to_run: List[Any] = []
            parse_failed = False
            parse_error: str = ""
            parse_extras = dict(req.extras or {})
            if isinstance(sess, dict) and sess.get("model_type"):
                parse_extras.setdefault("model_type", sess.get("model_type"))
            if m:
                try:
                    _, to_run = m(req.output, parse_extras)
                except Exception as e:
                    logging.error(f"GUI model call failed: {e}")
                    to_run = []
                    parse_failed = True
                    parse_error = str(e)
            if not parse_failed and not to_run:
                output_preview = str(req.output or "").replace("\n", "\\n")[:240]
                logging.warning(
                    "session_step parsed 0 actions: session_id=%s output_preview=%s",
                    req.session_id,
                    output_preview,
                )
            if sess and isinstance(sess.get("last_observation"), dict):
                prior_observation = dict(sess["last_observation"])
            if parse_failed:
                last_observation = {
                    "done": True,
                    "fail": True,
                    "obs_str": f"action parse failed: {parse_error}" if parse_error else "action parse failed",
                }
                results.append(
                    {
                        "status": "error",
                        "error": parse_error or "parse_failed",
                        "info": {"done": True, "fail": True, "parse_failed": True},
                    }
                )
            parsed_for_memory: Optional[Dict[str, Any]] = None
            try:
                parsed_for_memory = adapter.parse(req.output, req.extras) if adapter else None
            except Exception as e:
                logging.error(f"Adapter parse failed: {e}")
                parsed_for_memory = None
            for a in to_run:
                if adapter and rl_framework == "areal" and isinstance(a, dict) and a.get("type") == "python":
                    code = (a.get("params") or {}).get("code") or ""
                    a = {"command": code}
                payload = json.dumps({"action": a, "pause": int(req.pause)})
                try:
                    r = _internal_request(
                        "POST",
                        worker_base + "/step",
                        headers={"Content-Type": "application/json", **headers},
                        data=payload,
                        timeout=90,
                    )
                except Exception as e:
                    logging.error(f"Step failed for {worker_base}: {e}")
                    results.append({"status": "error", "error": str(e)})
                    break
                if r.status_code != 200:
                    results.append({"status": "error", "code": r.status_code})
                    break
                jr = r.json()
                results.append({"status": "ok", "info": jr.get("info")})
                time.sleep(1)
                try:
                    ro = _internal_request(
                        "GET",
                        worker_base + "/observe",
                        headers=headers,
                        timeout=observe_timeout,
                    )
                    if ro.status_code == 200:
                        last_observation = ro.json() or {}
                    else:
                        last_observation = jr.get("observation") or {}
                except Exception as e:
                    logging.error(f"Observe failed for {worker_base}: {e}")
                    last_observation = jr.get("observation") or {}
                if sess and sess.get("traj_id"):
                    try:
                        ss_b64 = last_observation.get("screenshot_b64")
                        ss = None
                        if isinstance(ss_b64, str):
                            try:
                                ss = base64.b64decode(ss_b64)
                            except Exception as e:
                                logging.error(f"Decode screenshot failed: {e}")
                                ss = None
                        traj_info = jr.get("info") if isinstance(jr, dict) else {}
                        if not isinstance(traj_info, dict):
                            traj_info = {}
                        hook_trace = traj_info.get("hook_trace")
                        reward = jr.get("reward") if isinstance(jr, dict) else None
                        done = jr.get("done") if isinstance(jr, dict) else None
                        traj.add_step(
                            sess["traj_id"],
                            observation=last_observation,
                            screenshot=ss,
                            raw_output=req.output,
                            parsed_action_code=a,
                            state_before=prior_observation,
                            state_after=last_observation,
                            hook_trace=hook_trace if isinstance(hook_trace, dict) else None,
                            reward=reward if reward is not None else 0.0,
                            done=bool(done) if done is not None else None,
                            info=traj_info,
                        )
                        raw_output_recorded = True
                        if isinstance(sess, dict):
                            sess["traj_steps"] = sess.get("traj_steps", 0) + 1
                            sess["last_reward"] = float(reward or 0.0)
                            sess["done"] = bool(done)
                            if isinstance(last_observation, dict):
                                sess["last_observation"] = dict(last_observation)
                        prior_observation = dict(last_observation) if isinstance(last_observation, dict) else {}
                        if parsed_for_memory:
                            try:
                                if hasattr(parser, "add_observation"):
                                    parser.add_observation(req.session_id, last_observation)
                                if hasattr(parser, "add_history_image"):
                                    parser.add_history_image(req.session_id, ss)
                            except Exception as e:
                                logging.error(f"GUI history update failed: {e}")
                    except Exception as e:
                        logging.error(f"Trajectory add step failed: {e}")
            if sess and sess.get("traj_id") and not raw_output_recorded:
                fallback_observation: Dict[str, Any] = {}
                if isinstance(last_observation, dict):
                    fallback_observation = dict(last_observation)
                if not fallback_observation and results:
                    fallback_observation = {"step_results": results}
                fallback_action: Any = to_run[0] if to_run else {"type": "NO_ACTION"}
                fallback_info = {}
                if results and isinstance(results[0], dict):
                    fi = results[0].get("info", {})
                    if isinstance(fi, dict):
                        fallback_info = fi
                try:
                    traj.add_step(
                        sess["traj_id"],
                        observation=fallback_observation,
                        screenshot=None,
                        raw_output=req.output,
                        parsed_action_code="" if parse_failed else fallback_action,
                        state_before=prior_observation,
                        state_after=fallback_observation,
                        hook_trace=fallback_info.get("hook_trace"),
                        reward=0.0,
                        done=True,
                        info={"done": True, "parse_failed": bool(parse_failed)},
                            only_raw_output=bool(parse_failed),
                    )
                    if isinstance(sess, dict):
                        sess["traj_steps"] = sess.get("traj_steps", 0) + 1
                        sess["done"] = True
                        if isinstance(fallback_observation, dict):
                            sess["last_observation"] = dict(fallback_observation)
                except Exception as e:
                    logging.error(f"Trajectory fallback add step failed: {e}")
            if parse_failed:
                return _failure_response(
                    error=parse_error or "parse_failed",
                    parse_failed=True,
                    results=results,
                    observation=last_observation,
                )
            for item in results:
                if item.get("status") == "error":
                    return _failure_response(
                        error=str(item.get("error") or item.get("code") or "session step failed"),
                        results=results,
                        observation=last_observation,
                    )
            wrapped = adapter.wrap_observation(last_observation) if adapter else last_observation
            return {"results": results, "observation": wrapped}
        except HTTPException:
            raise
        except Exception as e:
            logging.exception("session_step unexpected error: session_id=%s", req.session_id)
            return _failure_response(
                error=f"internal session_step error: {type(e).__name__}: {e}",
                results=[{"status": "error", "error": str(e)}],
                observation={},
            )

    @app.post("/session/finish")
    def session_finish(
        req: Optional[SessionFinishRequest] = None,
        authorization: Optional[str] = Header(None),
        session_id: str = "",
        success: bool = True,
    ):
        _require_auth(authorization)
        sid = req.session_id if req else session_id
        succ = bool(req.success) if req else bool(success)
        if not sid:
            raise HTTPException(status_code=400, detail="missing session_id")
        sess = sessions.get(sid)
        if sess is not None:
            sess["success"] = succ
        try:
            # Task end does not reset; next task start enforces a strict reset.
            return _release_worker(session_id=sid, do_reset=False)
        except HTTPException as e:
            if e.status_code == 404:
                return {"released": False, "error": "session not found"}
            raise

    return app


_ensure_controller_logging()
app = create_app(load_structured_config())


@hydra_main(version_base=None, config_path=".", config_name="all_config")
def main(cfg: DictConfig) -> None:
    _ensure_controller_logging()
    base = OmegaConf.structured(RootConfig)
    merged = OmegaConf.merge(base, cfg)
    root_cfg: RootConfig = OmegaConf.to_object(merged)
    globals()["app"] = create_app(root_cfg)
    vm_cfg = getattr(root_cfg, "vm_manager", None)
    nodes = getattr(vm_cfg, "nodes", {}) if vm_cfg else {}
    enforce_limits = bool(getattr(getattr(vm_cfg, "options", None), "enforce_limits", True)) if vm_cfg else True
    total = int(getattr(vm_cfg, "total", 0) or 0) if vm_cfg else 0
    tmp_cfg = {
        "total": total,
        "nodes": nodes or {},
        "options": {"enforce_limits": enforce_limits},
    }
    clear_pools()
    state_dir = get_controller_state_dir()
    tmp_path = state_dir / "tmp_provision.yaml"
    with open(tmp_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(tmp_cfg, f, allow_unicode=True)
    provision_with_config(str(tmp_path))
    server_cfg = _controller_to_dict(root_cfg).get("server") or {}
    host = str(server_cfg.get("host"))
    port = int(server_cfg.get("port"))
    try:
        # Ensure Ctrl+C doesn't hang forever when there are in-flight requests (e.g. a long-polling
        # /session/start_batch). Uvicorn will cancel remaining tasks after this timeout and then
        # proceed to FastAPI shutdown events.
        uvicorn.run(app, host=host, port=port, timeout_graceful_shutdown=3)
    finally:
        # Safety net: if uvicorn is force-quit (2nd Ctrl+C), lifespan shutdown callbacks may be
        # skipped. Always try best-effort resource cleanup on exit.
        cleanup_cfg = getattr(getattr(root_cfg, "controller", None), "cleanup", None)
        cleanup_concurrency = int(getattr(cleanup_cfg, "concurrency", 16))
        cleanup_timeout_s = float(getattr(cleanup_cfg, "timeout_s", 20.0))
        try:
            destroy_summary = destroy_workers(
                prefer_host=None,
                status_filter="",
                concurrency=cleanup_concurrency,
                timeout=cleanup_timeout_s,
                remove_from_pool=True,
            )
            logging.warning(f"Controller-exit destroy_workers summary: {destroy_summary}")
        except Exception as e:
            logging.error(f"destroy_workers failed on controller exit: {e}")
        try:
            fallback_summary = cleanup_cluster_nodes()
            logging.warning(f"Controller-exit ansible fallback cleanup summary: {fallback_summary}")
            clear_pools()
        except Exception as e:
            logging.error(f"ansible fallback cleanup failed on controller exit: {e}")
        try:
            cfg_dict = _controller_to_dict(root_cfg)
            firewall_cfg = cfg_dict.get("controller_firewall") or {}
            if bool(firewall_cfg.get("manage_ufw", True)):
                _revoke_controller_ufw_rules(
                    worker_ips=[str(ip).strip() for ip in (firewall_cfg.get("worker_ips") or []) if str(ip or "").strip()],
                    port=int((cfg_dict.get("server") or {}).get("port") or 8081),
                    sudo_password=str(firewall_cfg.get("sudo_password") or ""),
                )
        except Exception as e:
            logging.error(f"controller UFW fallback revoke failed on controller exit: {e}")


if __name__ == "__main__":
    # Backward compatible CLI:
    #   python start.py --config all_config.yaml
    # Map to Hydra args:
    #   --config-path . --config-name all_config
    if "--config" in sys.argv:
        try:
            idx = sys.argv.index("--config")
            config_arg = sys.argv[idx + 1]
            config_path = Path(config_arg)
            config_dir = str(config_path.parent) if str(config_path.parent) not in ("", ".") else "."
            config_name = config_path.stem
            sys.argv = (
                sys.argv[:idx]
                + ["--config-path", config_dir, "--config-name", config_name]
                + sys.argv[idx + 2:]
            )
        except Exception as e:
            raise SystemExit(f"Invalid --config usage: {e}")
    with TTYStateGuard():
        run_or_exit_on_sigint(main)

# Vibe - 可控 GUI RL 仿真环境

Vibe 在 Linux 桌面中提供可控的应用级仿真，用于 GUI 强化学习训练。它能复现实用的桌面应用行为、状态机与任务轨迹，并通过 Hook 输出可复用的奖励信号。

## 概述

- 在 Linux 桌面前台显示，可被 pyautogui 类动作接口驱动（外部动作执行器）
- 支持多应用启动与状态重置（微信、QQ、QQ音乐、邮箱、企业微信、钉钉、飞书、Telegram、Slack、Discord、腾讯会议）
- 保留 UI 可见性，支持模型通过截图进行观察
- 通过 Hook/规则精确判断任务完成，提供可回放、可统计的 reward

## 架构（当前清晰版）

```
vibe/
├── apps/                         # 具体应用实现
├── core/                         # 动作、状态、任务、应用基类
├── runtime/                      # 会话、应用清单、Hook 引擎
├── integration/                  # 与 VM/Agent 的接入桥
└── ...
```

### 三层设计

1. **应用层（apps / core）**：应用实例、动作处理、状态转移与 UI 表达
2. **运行时层（runtime）**：应用注册、会话管理、VM 生命周期、Hook 评估
3. **接入层（integration）**：任务输入解析、动作分发、reward 聚合与对外接口

## 快速开始

```bash
# 安装前提
cd os_env

# 安装依赖
pip install -r requirements.txt
```

### 基础用法

```python
from vibe.core.shared_types import (
    TaskConfig,
    Action,
    ActionType,
    MouseAction,
    MouseActionType,
    Coordinate,
)
from vibe.apps.wechat_simulator import WeChatSimulator

app = WeChatSimulator(debug_mode=True)
app.initialize()

task = TaskConfig(
    task_type="open_conversation",
    difficulty=1,
    target={"conversation_id": "conv_contact_0"},
    max_steps=10,
)
state, info = app.reset(task_config=task, seed=42)

action = Action(
    type=ActionType.MOUSE,
    mouse_action=MouseAction(
        subtype=MouseActionType.CLICK,
        coordinate=Coordinate(x=0.15, y=0.15),
    ),
)
state, reward, done, truncated, info = app.step(action)
app.close()
```

### Provider 集成

```python
from integration.vibe_desktop_env import VibeDesktopEnv

env = VibeDesktopEnv(provider_name="vibe", vibe_app_type="wechat")
env.reset({"vibe_config": {"app_type": "wechat", "task": {"task_type": "open_conversation", "target": {"conversation_id": "conv_contact_0"}, "max_steps": 10}}})
obs, reward, done, truncated, info = env.step({"action_type": "mouse", "move_type": "click", "coordinate": [0.15, 0.15]})
```

## 项目结构（仓库）

- `desktop_env/`: 桌面环境与 worker 运行时
- `integration/`: 与上层控制端/服务端的接入桥（含 `vibe_env_provider` 与 smoke）
- `vibe/`: 仿真应用核心（apps/core/runtime）
- `manage/`: VM 资源池/节点管理
- `trajectory_management/`: 回放与奖励轨迹
- `tools/`: 运维与端口检测辅助工具
- `vibe/runtime/app_manifests.yaml`: 应用任务模板与 hook 规则

## 特性

- ✅ 多应用支持：微信、QQ、QQ音乐、邮箱、企业微信、钉钉、飞书、Telegram、Slack、Discord、腾讯会议
- ✅ Hook 驱动的任务完成检测（适合 RL 奖励闭环）
- ✅ 标准化动作：鼠标、键盘、组合键、拖拽、滚动
- ✅ 会话级别的可复位状态、任务参数化与随机化
- ✅ 与现有 Gym/OSWorld-style 环境接口兼容
- ✅ Hook 规则与任务模板集中到 YAML，支持规则级更新与可回溯管理
- ✅ 身份素材可控：默认使用内置真实中文名/群名库，支持配置 `include_remote_profiles=true` 时从随机用户 API 抓取补充姓名与头像（失败自动回退）

## 与 os_env 融合入口

- `integration/vibe_desktop_env.py`：`VibeDesktopEnv`，负责把 `os_env` 的 Gym/worker 接口映射到 `tauri-vibe`。
- `integration/os_env_bridge/session_adapter.py`：定义 `vibe_config` 到 os_env 任务负载的映射规则。
- `integration/vibe_env_provider.py`：HTTP provider，负责把 `app_type/task/action` 转成 `tauri-vibe` 的 `/reset`、`/step` 请求。
- `desktop_env/env_worker.py`：服务端入口，已支持 `--provider vibe`，`/setup`、`/reset`、`/step` 会回传 `task_meta / hook_trace / truncated`。

## 当前集成状态

- `tauri-vibe` 后端已与 `os_env/vibe` 对齐：`wechat / qq / qqmusic / mail / wework / dingtalk / feishu / telegram / slack / discord / tencentmeeting`
- `env_worker -> VibeDesktopEnv -> VibeTauriProvider -> tauri-vibe HTTP` 主链路已接通
- `env_worker.py` 现在可以直接按脚本运行，不再强依赖额外 `PYTHONPATH`
- `VibeDesktopEnv` 已补齐 `reset_only`、`setup_task`、任务元信息透传，不会再误回退到 VM snapshot 逻辑
- `hook_trace` 与 `task_meta` 已从 `tauri-vibe` provider 一路透传到 worker 响应

## 系统分层与职责边界（执行要求）

- **基础服务层（`vm_service` / tauri 进程）**：仅负责会话生命周期与底层执行；不做 RL 任务语义。
- **会话管理层（`vibe.runtime`）**：负责应用实例切换、任务注入、hook 规则执行、状态快照与 reward 片段聚合。
- **Hook 管理层（`vibe.runtime.hook_engine`）**：只读任务中的 `hook_rules`，根据动作事件与状态变化触发奖励；不改 UI。
- **应用层（`vibe.apps`）**：只负责状态机与可观测 UI 输出（微信界面不改动，仅修正能力与身份素材）。

> 你现在要求的“钩子管理统一、可扩展、可验证”由 `hook_rules` + `app_effect` 统一管理完成：新增能力时只需补充 YAML/清单，不改会话流程与 provider 代码。

## 跨应用动作与 Hook 规则

系统动作采用统一格式：

- 切换应用：`{"action_type":"system","action":"switch_app","target_app":"qqmusic","reset_task":true/false}`
- 任务目标可通过 `task_type: switch_app` + `target.target_app` 下发。
- 成功判断通过 hook：
  - `event: app_effect`
  - `event_name: active_app_changed`
  - `when: { field: active_app, op: eq, value: <target_app>, scope: state }`

会话层会在动作前后注入 `state.active_app`，确保 hook 规则可直接命中；规则一次性触发/多次触发由 `once` 字段控制。

## 指令/任务生成建议

- 单应用任务：`build_vibe_task_payload(app_type='wechat', task_type='send_text_message', ...)`
- 切应用任务：`build_switch_task_payload(source_app='wechat', target_app='qq')`
- 两段式指令序列（先执行源应用任务，再跨应用）：
  - `build_vibe_multi_app_sequence("wechat", "qqmusic", source_task_type="open_conversation", source_task_target={"target_position":0})`

### 基于 Hook 的指令反向设计

你后续要做的“按可回放奖励反推出指令”可以按固定模式生成：

1. 先读目标 hook（例如 `conversation_opened`、`search_complete`、`message_sent`）。
2. 在 `target` 中声明可判定字段（如 `target_position`、`keyword`、`content`）。
3. 在 `hook_rules` 中定义：
   - `event: app_effect`
   - `event_name: <对应事件>`
   - `when.field`: 状态字段（如 `selected_conversation_index`、`search_completed`、`last_sent_text`）
   - `reward`: 每条命中奖励
   - `done`: 是否终止
4. 由任务编排层（`task_catalog`）将这些规则和模板统一发下去，训练器只使用这类可验证能力，而不需要复杂视觉判定。

示例返回中的核心字段：
- `task.task_type = switch_app`
- `task.target.target_app`
- `task.hook_rules` 中带有 `active_app_changed` 检测

## 本机启动方式

先启动 `tauri-vibe` 的 HTTP 服务，然后再启动 `env_worker`：

```bash
cd /mnt/data1/xiao/vibe/os_env
VIBE_BASE_URL=http://127.0.0.1:8765 \
VIBE_APP_TYPE=wechat \
python desktop_env/env_worker.py --provider vibe --host 127.0.0.1 --port 8300
```

说明：

- `VIBE_BASE_URL` 必须指向一个已运行的 `tauri-vibe` HTTP 服务，且需要能响应 `GET /health`
- `VIBE_APP_TYPE` 可选 `wechat / qq / qqmusic / mail / wework / dingtalk / feishu / telegram / slack / discord / tencentmeeting`
- 当前状态可在本机直接完成 2~3 个并行实例 smoke 验证（例如开 2 个 `env_worker`），不要求真实分布式部署。

## 本地闭环验证（2-3 台本机实例）

1. 启动 tauri-vibe 服务（若你只做本机验证，1 个服务实例即可）
2. 启动两个 `env_worker`（端口如 `8300/8301`）并分别指定 app_type
3. 逐条执行：
   - 单应用动作任务（如 `send_text_message`）
   - 系统切应用任务（`switch_app`）
4. 观察 `step` 的 `hook_trace` 与 `reward` 是否按预期命中 `active_app_changed` 与 `message_sent`。

## 身份样式配置

- 默认（推荐）：关闭在线抓取，使用本地固定名称池，避免隐私和网络依赖波动。
- 可选增强：在 `vibe_config.options` 中设置 `identity_include_remote: true`（或 `include_remote_profiles: true`）时，尝试从公开随机用户接口补充名称与头像，失败后仍自动回退到内置池。

示例：

```json
{
  "vibe_config": {
    "options": {
      "identity_include_remote": true
    }
  }
}
```

## Manifest 与 Hook 校验

每次改完 `app_manifests.yaml` 后先跑一次静态检查，避免任务与 hook 的结构漂移：

```bash
cd /mnt/data1/xiao/vibe/os_env
python tools/check_vibe_manifest_and_hooks.py --manifest vibe/runtime/app_manifests.yaml
python tools/normalize_vibe_manifest.py --manifest vibe/runtime/app_manifests.yaml
```

严格模式（CI 建议）：

```bash
python tools/check_vibe_manifest_and_hooks.py --manifest vibe/runtime/app_manifests.yaml --strict
```

推荐配合输出为 JSON：

```bash
python tools/check_vibe_manifest_and_hooks.py --manifest vibe/runtime/app_manifests.yaml --json
```

脚本规则（与运行时对齐）：

- 每个应用必须有 `instructions` 或 `tasks`；
- 每个任务必须有 `task_type`、`target`、`initial_state_config`（推荐显式）、`hook_rules`；
- 每条 Hook 要有 `event`、`event_name`、`when`、`reward`、`done`、`once`；
- `switch_app` 的 `target.target_app` 必须是注册应用之一；
- `when` 推荐包含 `field/op/value`，`value` 用于 `op` 判定。

## 当前交付清单（按你的要求落盘）

- 配置对齐：`tauri-vibe` 与 `os_env/vibe` 的任务字段（含 `hook_rules`）已贯通；`vibe_env_provider` 不再丢失规则字段。
- Hook 管理：规则统一挂在 `task_config.hook_rules`，后端仅根据规则求值并返回 `hook_trace`；会话层不负责业务语义判断。
- 文件收口：`upstream` 兼容入口已移除，多应用场景以 `os_env/vibe` 为单一入口；`tauri-vibe` 与 `os_env` 对齐文档集中在当前目录。
- 身份/头像来源：默认使用真实中文名与群名内置池，`identity_profiles` 提供可选远程补充（失败自动回退）。
- 跨应用指令：`build_switch_task_payload` 与 `build_vibe_multi_app_sequence` 已输出可直接喂给控制器的任务链。

## 下一步本机验证（推荐）

1. 先启动一次 `tauri-vibe`（本机）；
2. 启动 2~3 个 `env_worker`（不同端口）；
3. 按 `send_text_message`、`search_music`、`open_mail`、`switch_app` 跑最小 Episode；
4. 校验 `hook_trace` 中 `active_app_changed`、`message_sent`、`mail_opened`/`search_complete` 是否命中；
5. 逐步固定 `task.catalog` 中的模板与 `hook_rules`，用于 rl_recipe 的 `areal` 任务采样。

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any

import requests


_DEFAULT_ROOT = Path(__file__).resolve().parents[1]
_DEFAULT_WORKERS_POOL = str(_DEFAULT_ROOT / "state" / "workers_pool.json")
_DEFAULT_PORT_CHECK_DIR = str(_DEFAULT_ROOT / "logs" / "port_check")


@dataclass
class ProbeResult:
    worker_host: str
    worker_port: int
    vm_name: str
    env_id: str
    pool_status: str
    tcp_ok: bool
    tcp_elapsed_s: float
    tcp_error: str
    http_ok: bool
    http_status: int | None
    http_elapsed_s: float
    http_error: str
    health_status: str


def tcp_probe(host: str, port: int, timeout_s: float) -> tuple[bool, float, str]:
    t0 = time.monotonic()
    try:
        with socket.create_connection((host, port), timeout=timeout_s):
            return True, time.monotonic() - t0, ""
    except Exception as e:
        return False, time.monotonic() - t0, f"{type(e).__name__}:{e}"


def http_health_probe(host: str, port: int, timeout_s: float, token: str) -> tuple[bool, int | None, float, str, str]:
    t0 = time.monotonic()
    url = f"http://{host}:{port}/health"
    headers: dict[str, str] = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        resp = requests.get(url, headers=headers, timeout=timeout_s)
        elapsed = time.monotonic() - t0
        if resp.status_code != 200:
            return False, resp.status_code, elapsed, (resp.text or "")[:200], ""
        try:
            body = resp.json() if resp.content else {}
        except Exception:
            body = {}
        health_status = str(body.get("status") or "") if isinstance(body, dict) else ""
        return True, resp.status_code, elapsed, "", health_status
    except Exception as e:
        return False, None, time.monotonic() - t0, f"{type(e).__name__}:{e}", ""


def load_workers(pool_path: Path) -> list[dict[str, Any]]:
    obj = json.loads(pool_path.read_text(encoding="utf-8"))
    workers = obj.get("workers") or []
    if not isinstance(workers, list):
        raise ValueError("workers_pool.json format error: workers must be a list")
    return workers


def probe_one(worker: dict[str, Any], tcp_timeout_s: float, http_timeout_s: float, token: str, with_http: bool) -> ProbeResult:
    host = str(worker.get("worker_host") or "")
    port = int(worker.get("worker_port"))
    vm_name = str(worker.get("vm_name") or "")
    env_id = str(worker.get("env_id") or "")
    pool_status = str(worker.get("status") or "")

    tcp_ok, tcp_elapsed, tcp_err = tcp_probe(host, port, tcp_timeout_s)

    http_ok = False
    http_status: int | None = None
    http_elapsed = 0.0
    http_err = ""
    health_status = ""
    if with_http and tcp_ok:
        http_ok, http_status, http_elapsed, http_err, health_status = http_health_probe(
            host=host,
            port=port,
            timeout_s=http_timeout_s,
            token=token,
        )

    return ProbeResult(
        worker_host=host,
        worker_port=port,
        vm_name=vm_name,
        env_id=env_id,
        pool_status=pool_status,
        tcp_ok=tcp_ok,
        tcp_elapsed_s=tcp_elapsed,
        tcp_error=tcp_err,
        http_ok=http_ok,
        http_status=http_status,
        http_elapsed_s=http_elapsed,
        http_error=http_err,
        health_status=health_status,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Check local reachability to workers in workers_pool.json")
    parser.add_argument(
        "--pool-path",
        default=_DEFAULT_WORKERS_POOL,
        help="Path to workers_pool.json",
    )
    parser.add_argument("--concurrency", type=int, default=64, help="Parallel probe workers")
    parser.add_argument("--tcp-timeout-s", type=float, default=2.0, help="TCP connect timeout")
    parser.add_argument("--http-timeout-s", type=float, default=3.0, help="HTTP /health timeout")
    parser.add_argument("--with-http", action="store_true", help="Also probe /health")
    parser.add_argument(
        "--token",
        default=os.environ.get("ENV_WORKER_TOKEN", ""),
        help="Bearer token for /health endpoint",
    )
    parser.add_argument(
        "--output",
        default="",
        help="Optional output json path. If empty, auto-create under os_env/logs/port_check",
    )
    args = parser.parse_args()

    pool_path = Path(args.pool_path).resolve()
    workers = load_workers(pool_path)

    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    if args.output.strip():
        out_path = Path(args.output).resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
    else:
        out_dir = Path(_DEFAULT_PORT_CHECK_DIR)
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"worker_port_check_{ts}.json"

    results: list[ProbeResult] = []
    with ThreadPoolExecutor(max_workers=max(1, int(args.concurrency))) as ex:
        futs = [
            ex.submit(
                probe_one,
                w,
                float(args.tcp_timeout_s),
                float(args.http_timeout_s),
                str(args.token or ""),
                bool(args.with_http),
            )
            for w in workers
        ]
        for fut in as_completed(futs):
            results.append(fut.result())

    results.sort(key=lambda x: (x.worker_host, x.worker_port))

    tcp_ok = sum(1 for r in results if r.tcp_ok)
    tcp_fail = len(results) - tcp_ok
    http_ok = sum(1 for r in results if r.http_ok) if args.with_http else 0
    http_fail = len(results) - http_ok if args.with_http else 0

    by_status: dict[str, int] = {}
    for r in results:
        by_status[r.pool_status] = by_status.get(r.pool_status, 0) + 1

    payload = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "pool_path": str(pool_path),
        "total_workers": len(results),
        "with_http": bool(args.with_http),
        "summary": {
            "tcp_ok": tcp_ok,
            "tcp_fail": tcp_fail,
            "http_ok": http_ok,
            "http_fail": http_fail,
            "pool_status_distribution": by_status,
        },
        "failures": [asdict(r) for r in results if (not r.tcp_ok) or (args.with_http and not r.http_ok)],
        "results": [asdict(r) for r in results],
    }
    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(f"workers={len(results)} tcp_ok={tcp_ok} tcp_fail={tcp_fail}")
    if args.with_http:
        print(f"http_ok={http_ok} http_fail={http_fail}")
    print(f"report={out_path}")


if __name__ == "__main__":
    main()

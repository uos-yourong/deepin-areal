#!/usr/bin/env python3
"""Validator for vibe manifest and hook rules.

Purpose:
- validate `app_manifests.yaml` schema
- verify each task has target + initial state + validation condition/hook condition
- check hook structure used by hook engine
- ensure task/app consistency with built-in app registry when available

Exit code:
- 0: validation passed (only warnings exist)
- 1: error found
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Set

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None


_OSENV_ROOT = Path(__file__).resolve().parent.parent
if str(_OSENV_ROOT) not in sys.path:
    sys.path.insert(0, str(_OSENV_ROOT))

REQUIRED_HOOK_KEYS = ("event", "event_name", "when", "reward", "done", "once")
ALLOWED_COMPARE_OPS = {"eq", "equals", "==", "ne", "not_equals", "!=", "contains", "in", "not_in"}


@dataclass
class ValidationIssue:
    """Single validation issue."""

    level: str
    scope: str
    code: str
    message: str

    def to_dict(self) -> Dict[str, str]:
        return {
            "level": self.level,
            "scope": self.scope,
            "code": self.code,
            "message": self.message,
        }


@dataclass
class ManifestCheckResult:
    """Validation summary."""

    manifest_path: str
    total_apps: int = 0
    total_tasks: int = 0
    errors: List[ValidationIssue] = field(default_factory=list)
    warnings: List[ValidationIssue] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0

    def add_error(self, scope: str, code: str, message: str) -> None:
        self.errors.append(ValidationIssue("error", scope, code, message))

    def add_warning(self, scope: str, code: str, message: str) -> None:
        self.warnings.append(ValidationIssue("warning", scope, code, message))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "manifest_path": self.manifest_path,
            "total_apps": self.total_apps,
            "total_tasks": self.total_tasks,
            "ok": self.ok,
            "errors": [item.to_dict() for item in self.errors],
            "warnings": [item.to_dict() for item in self.warnings],
        }


def _is_mapping(value: Any) -> bool:
    return isinstance(value, dict)


def _is_non_empty_str(value: Any) -> bool:
    return isinstance(value, str) and value.strip() != ""


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float))


def _is_bool(value: Any) -> bool:
    return isinstance(value, bool)


def _load_yaml(path: Path) -> Optional[Dict[str, Any]]:
    if yaml is None:
        raise RuntimeError("缺少 PyYAML，无法加载 manifest 文件")
    try:
        with path.open("r", encoding="utf-8") as f:
            payload = yaml.safe_load(f) or {}
    except Exception as exc:
        raise RuntimeError(f"解析 YAML 失败: {exc}") from exc
    if not isinstance(payload, dict):
        raise RuntimeError("manifest 根节点必须是 mapping")
    return payload


def _available_registry_apps() -> Set[str]:
    """尝试读取当前运行时可用应用清单，用于一致性校验。"""
    try:
        from vibe.runtime.app_registry import VibeAppRegistry
    except Exception:
        return set()

    try:
        registry = VibeAppRegistry()
        registry.bootstrap()
        return set(registry.list_app_types())
    except Exception:
        return set()


def _available_task_types() -> Set[str]:
    """从 `shared_types` 读取任务类型枚举（若可用）。"""
    try:
        from vibe.core.shared_types import TaskType

        return {item.value for item in TaskType}
    except Exception:
        return {
            "open_conversation",
            "search_and_open",
            "search_group",
            "search_music",
            "send_text_message",
            "send_file",
            "forward_message",
            "reply_to_message",
            "delete_message",
            "pin_conversation",
            "default",
            "custom",
            "switch_app",
            "search_mail",
            "mark_as_read",
            "reply_mail",
            "open_mail",
            "open_folder",
            "open_playlist",
            "pause_playback",
            "play_song",
        }


def _require_keys(
    issue: ManifestCheckResult,
    scope: str,
    data: Dict[str, Any],
    required: Sequence[str],
    code_prefix: str,
) -> None:
    for key in required:
        if key not in data:
            issue.add_error(scope, f"{code_prefix}_{key}_missing", f"缺少必填字段: {key}")


def _validate_hook(rule: Dict[str, Any], issue: ManifestCheckResult, scope: str, rule_index: int) -> None:
    hook_scope = f"{scope} -> hook_rules[{rule_index}]"
    if not _is_mapping(rule):
        issue.add_error(hook_scope, "hook_not_mapping", f"Hook 必须是对象结构: {rule}")
        return

    _require_keys(issue, hook_scope, rule, REQUIRED_HOOK_KEYS, "hook")

    event_name = str(rule.get("event") or "").strip()
    event = str(rule.get("event_name") or "").strip()
    when = rule.get("when")
    reward = rule.get("reward")
    done = rule.get("done")
    once = rule.get("once")

    if not _is_non_empty_str(event_name):
        issue.add_error(hook_scope, "hook_event_empty", "event 字段不能为空")
    if not _is_non_empty_str(event):
        issue.add_error(hook_scope, "hook_event_name_empty", "event_name 字段不能为空")
    if not _is_mapping(when):
        issue.add_error(hook_scope, "hook_when_invalid", "when 必须为 mapping")
    else:
        when_field = str(when.get("field") or "").strip()
        when_op = str(when.get("op") or "").strip()
        when_has_value = "value" in when
        if not when_field:
            issue.add_error(hook_scope, "hook_when_field_missing", "when.field 必须指定")
        if not when_op:
            issue.add_error(hook_scope, "hook_when_op_missing", "when.op 必须指定")
        elif when_op not in ALLOWED_COMPARE_OPS:
            issue.add_warning(
                hook_scope,
                "hook_when_op_unknown",
                f"未知的 op: {when_op}（建议使用 eq/equals/==/ne/not_equals/!=/contains/in/not_in）",
            )
        if not when_has_value:
            issue.add_warning(hook_scope, "hook_when_value_missing", "when.value 缺失，无法形成可验证条件")

    if not _is_number(reward):
        issue.add_error(hook_scope, "hook_reward_invalid", "reward 必须是数字")
    if not _is_bool(done):
        issue.add_error(hook_scope, "hook_done_invalid", "done 必须是布尔值")
    if not _is_bool(once):
        issue.add_error(hook_scope, "hook_once_invalid", "once 必须是布尔值")


def _check_task_entry(
    issue: ManifestCheckResult,
    app_type: str,
    task_type: str,
    task_cfg: Dict[str, Any],
    task_index: int,
    task_type_set: Set[str],
    known_apps: Set[str],
):
    scope = f"apps.{app_type}.tasks[{task_index}].{task_cfg.get('instruction_id', task_type)}"
    if not _is_non_empty_str(task_cfg.get("task_type") or ""):
        issue.add_error(scope, "task_type_empty", "task_type 不能为空")
    else:
        if task_cfg.get("task_type") not in task_type_set:
            issue.add_warning(
                scope,
                "task_type_unknown",
                f"task_type 不在已知集合中: {task_cfg.get('task_type')}",
            )
    if "target" not in task_cfg or not _is_mapping(task_cfg.get("target")):
        issue.add_error(scope, "task_target_invalid", "target 必须为 mapping")
    else:
        target = task_cfg.get("target") or {}
        if task_cfg.get("task_type") == "switch_app":
            target_app = str(target.get("target_app") or "").strip()
            if not target_app:
                issue.add_error(scope, "switch_task_target_app_missing", "switch_app 任务必须包含 target.target_app")
            elif known_apps and target_app not in known_apps:
                issue.add_warning(scope, "switch_task_target_unknown_app", f"target_app 不在已知应用中: {target_app}")

    if "initial_state_config" not in task_cfg:
        issue.add_warning(scope, "initial_state_missing", "建议显式设置 initial_state_config")
    elif not _is_mapping(task_cfg.get("initial_state_config")):
        issue.add_error(scope, "initial_state_not_mapping", "initial_state_config 必须为 mapping")

    if "success_conditions" not in task_cfg and "hook_rules" not in task_cfg:
        issue.add_error(scope, "validation_condition_missing", "success_conditions 与 hook_rules 缺失")
    elif "success_conditions" not in task_cfg:
        issue.add_warning(
            scope,
            "success_conditions_missing",
            "success_conditions 缺失，默认将从 hook_rules 推导",
        )
    else:
        if not isinstance(task_cfg.get("success_conditions"), list):
            issue.add_error(scope, "success_conditions_invalid", "success_conditions 必须为 list")
        elif not task_cfg.get("success_conditions"):
            issue.add_warning(scope, "success_conditions_empty", "success_conditions 为空")

    hook_rules = task_cfg.get("hook_rules")
    if not isinstance(hook_rules, list) or not hook_rules:
        issue.add_error(scope, "hook_rules_invalid", "hook_rules 必须为非空 list")
        return

    for idx, rule in enumerate(hook_rules):
        _validate_hook(rule=rule, issue=issue, scope=scope, rule_index=idx)


def _check_app_entry(
    issue: ManifestCheckResult,
    app_type: str,
    cfg: Dict[str, Any],
    known_apps: Set[str],
    known_task_types: Set[str],
) -> int:
    scope = f"apps.{app_type}"
    if not _is_non_empty_str(app_type):
        issue.add_error(scope, "app_type_empty", "app_type 不能为空")
    if not _is_non_empty_str(cfg.get("app_name")):
        issue.add_warning(scope, "app_name_missing", "app_name 为空，建议补充显示名称")
    if not _is_mapping(cfg.get("metadata")):
        issue.add_warning(scope, "metadata_missing", "metadata 推荐声明")

    if known_apps:
        if app_type not in known_apps:
            issue.add_warning(scope, "app_not_registered", f"manifest 中的 app_type 未在 registry 中注册: {app_type}")

    tasks_node = cfg.get("instructions", cfg.get("tasks"))
    if tasks_node is None:
        issue.add_error(scope, "tasks_missing", "缺少 instructions/tasks")
        return 0
    if not isinstance(tasks_node, list):
        issue.add_error(scope, "tasks_not_list", "instructions/tasks 必须为 list")
        return 0
    if len(tasks_node) == 0:
        issue.add_warning(scope, "tasks_empty", "无可用任务模板")

    app_task_types = cfg.get("task_types")
    if app_task_types is not None and not isinstance(app_task_types, list):
        issue.add_warning(scope, "task_types_invalid", "task_types 应为 list")
    if app_task_types is None:
        issue.add_warning(scope, "app_task_types_missing", "task_types 缺失")

    declared_task_types: Optional[Set[str]] = None
    if isinstance(app_task_types, list):
        declared_task_types = set(str(x) for x in app_task_types if _is_non_empty_str(x))
        unknown_declared = declared_task_types - known_task_types
        if unknown_declared:
            issue.add_warning(
                scope,
                "app_declared_task_types_unknown",
                f"task_types 包含未知 task_type: {sorted(unknown_declared)}",
            )

    ids_seen: Set[str] = set()
    for idx, task_cfg in enumerate(tasks_node):
        if not _is_mapping(task_cfg):
            issue.add_error(scope, "task_not_mapping", f"tasks[{idx}] 不是 mapping")
            continue
        task_type = str(task_cfg.get("task_type") or "")
        instruction_id = str(task_cfg.get("instruction_id") or f"{app_type}_{task_type}_{idx}")
        if instruction_id in ids_seen:
            issue.add_error(scope, "instruction_id_duplicate", f"instruction_id 重复: {instruction_id}")
        ids_seen.add(instruction_id)

        _check_task_entry(
            issue=issue,
            app_type=app_type,
            task_type=task_type,
            task_cfg=task_cfg,
            task_index=idx,
            task_type_set=known_task_types,
            known_apps=known_apps,
        )

        if declared_task_types is not None and task_type and task_type not in declared_task_types:
            issue.add_warning(
                scope,
                "task_type_not_declared",
                f"任务 task_type={task_type} 未在 app.task_types 中声明: {app_type}.task_types",
            )

    return len(tasks_node)


def validate_manifest(path: Path) -> ManifestCheckResult:
    """执行清单与 Hook 规则校验。"""
    issues = ManifestCheckResult(manifest_path=str(path))
    payload = _load_yaml(path)

    apps = payload.get("apps")
    if not isinstance(apps, dict):
        issues.add_error("root", "apps_invalid", "根节点缺少 apps 或 apps 非 mapping")
        return issues

    known_apps = _available_registry_apps()
    known_task_types = _available_task_types()
    issues.total_apps = len(apps)
    for app_type, cfg in apps.items():
        if not isinstance(cfg, dict):
            issues.add_error(f"apps.{app_type}", "app_not_mapping", "应用配置必须为 mapping")
            continue
        issues.total_tasks += _check_app_entry(
            issue=issues,
            app_type=str(app_type),
            cfg=cfg,
            known_apps=known_apps,
            known_task_types=known_task_types,
        )

    return issues


def _resolve_manifest_path(cli_path: str, repo_root: str) -> str:
    path = Path(cli_path)
    if not path.is_absolute():
        # 优先相对于当前工作目录解析，兼容以下两种调用方式：
        # - 在 os_env 目录执行: --manifest vibe/runtime/app_manifests.yaml
        # - 在仓库根执行:   --manifest os_env/vibe/runtime/app_manifests.yaml
        cwd_path = Path.cwd().joinpath(path)
        if cwd_path.exists():
            return str(cwd_path.resolve())
        path = Path(repo_root).joinpath(path)
    return str(path.resolve())


def main() -> None:
    parser = argparse.ArgumentParser(description="检查 vibe_app manifest 与 hook 规则")
    parser.add_argument(
        "--manifest",
        default="vibe/runtime/app_manifests.yaml",
        help="manifest YAML 路径（相对 os_env 根目录）",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="输出 JSON 格式结果",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="严格模式：将 warning 视为失败",
    )
    args = parser.parse_args()

    repo_root = Path(os.environ.get("OSENV_ROOT", Path(__file__).resolve().parent.parent))
    manifest_path = Path(_resolve_manifest_path(args.manifest, str(repo_root)))

    if not manifest_path.exists():
        raise SystemExit(f"manifest 文件不存在: {manifest_path}")

    result = validate_manifest(manifest_path)

    if args.json:
        print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
    else:
        print(f"manifest: {result.manifest_path}")
        print(f"apps: {result.total_apps} tasks: {result.total_tasks}")
        print(f"errors: {len(result.errors)} warnings: {len(result.warnings)}")

        for item in result.errors:
            print(f"[ERROR] {item.scope} {item.code}: {item.message}")
        for item in result.warnings:
            print(f"[WARN]  {item.scope} {item.code}: {item.message}")

    if not result.ok or (args.strict and result.warnings):
        raise SystemExit(1)


if __name__ == "__main__":
    main()

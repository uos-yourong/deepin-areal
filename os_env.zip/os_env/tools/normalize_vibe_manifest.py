#!/usr/bin/env python3
"""Normalize vibe manifest contracts.

This utility makes each task schema explicit for CI and training traceability:
- ensure `initial_state_config` exists for every task
- ensure `success_conditions` exists; if missing, derive it from hook `when` clause

The script only adds missing fields and keeps existing explicit fields untouched.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Dict, List

try:
    import yaml
except Exception as exc:  # pragma: no cover
    raise SystemExit("缺少 PyYAML，请先安装 pyyaml") from exc


def _normalize_manifest_target_value(raw: Any) -> Any:
    if isinstance(raw, str):
        stripped = raw.strip()
        if stripped.isdigit():
            return int(stripped)
        return stripped
    return raw


def _derive_success_conditions_from_hooks(hook_rules: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    conditions: List[Dict[str, Any]] = []
    for rule in hook_rules or []:
        if not isinstance(rule, dict):
            continue

        when = rule.get("when")
        if not isinstance(when, dict):
            continue

        field = when.get("field")
        if not field:
            continue

        conditions.append(
            {
                "type": "state",
                "field": str(field),
                "operator": when.get("op", "eq"),
                "op": when.get("op", "eq"),
                "value": _normalize_manifest_target_value(when.get("value")),
                "scope": when.get("scope", "state"),
            }
        )
    return conditions


def _normalize_task(task: Dict[str, Any]) -> Dict[str, Any]:
    if "initial_state_config" not in task:
        task["initial_state_config"] = {}

    success_conditions = task.get("success_conditions")
    hook_rules = task.get("hook_rules", [])

    if not isinstance(success_conditions, list) or not success_conditions:
        task["success_conditions"] = _derive_success_conditions_from_hooks(
            hook_rules if isinstance(hook_rules, list) else []
        )
    return task


def normalize_manifest(path: Path) -> bool:
    payload = path.read_text(encoding="utf-8")
    data = yaml.safe_load(payload)
    if not isinstance(data, dict) or not isinstance(data.get("apps"), dict):
        raise RuntimeError("manifest root.apps 必须为 mapping")

    changed = False
    apps = data.get("apps", {})
    for app_cfg in apps.values():
        if not isinstance(app_cfg, dict):
            continue
        instructions = app_cfg.get("instructions", app_cfg.get("tasks"))
        if not isinstance(instructions, list):
            continue
        for task in instructions:
            if not isinstance(task, dict):
                continue
            before = yaml.safe_dump(task, allow_unicode=True, sort_keys=False, default_flow_style=False)
            after_obj = _normalize_task(task)
            after = yaml.safe_dump(after_obj, allow_unicode=True, sort_keys=False, default_flow_style=False)
            if before != after:
                changed = True

    if changed:
        # Keep mapping keys order and make output compact/consistent.
        with path.open("w", encoding="utf-8") as f:
            yaml.safe_dump(
                data,
                f,
                allow_unicode=True,
                sort_keys=False,
                default_flow_style=False,
            )
    return changed


def main() -> None:
    parser = argparse.ArgumentParser(description="Normalize vibe manifest task contracts")
    parser.add_argument(
        "--manifest",
        required=True,
        help="Path to app_manifests.yaml",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="仅检查是否会修改，不实际写入",
    )
    args = parser.parse_args()

    path = Path(args.manifest)
    if not path.exists():
        raise SystemExit(f"文件不存在: {path}")

    # 通过反序列化比对判断是否变化，避免无意义重写
    changed = normalize_manifest(path)
    if args.dry_run:
        if changed:
            print("manifest 会发生变更")
            raise SystemExit(1)
        print("manifest 无变更")
        return

    print("manifest 已标准化" if changed else "manifest 无需变更")


if __name__ == "__main__":
    main()

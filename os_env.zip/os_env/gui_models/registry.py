from typing import Dict, Type
from .base import GuiModel
from .evocua import EvoCuaGuiModel
from .uitars import UitarsGuiModel

REGISTRY: Dict[str, Type[GuiModel]] = {
    "uitars": UitarsGuiModel,
    "evocua": EvoCuaGuiModel,
}

def get_model_class(name: str) -> Type[GuiModel] | None:
    return REGISTRY.get(name.lower())

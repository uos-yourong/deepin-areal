import json
import logging
import os
from typing import Any, Dict, List, Optional, Tuple

from .base import GuiModel

logger = logging.getLogger(__name__)


class EvoCuaGuiModel(GuiModel):
    """EvoCUA parser aligned with OSWorld/mm_agents/evocua/evocua_agent.py."""

    def __init__(self):
        self.screen_size: Tuple[int, int] = (
            int(os.environ.get("SCREEN_WIDTH", "1920") or 1920),
            int(os.environ.get("SCREEN_HEIGHT", "1080") or 1080),
        )
        self.coordinate_type = str(os.environ.get("EVOCUA_COORDINATE_TYPE", "relative")).lower()

    def _resolve_parse_dims(
        self,
        extras: Dict[str, Any],
    ) -> Tuple[Optional[int], Optional[int], Optional[int], Optional[int], str]:
        processed_width = extras.get("processed_width")
        processed_height = extras.get("processed_height")
        original_width = extras.get("screen_width")
        original_height = extras.get("screen_height")
        coordinate_type = str(extras.get("coordinate_type", self.coordinate_type)).lower()

        def _to_pos_int(v: Any) -> Optional[int]:
            try:
                i = int(v)
                return i if i > 0 else None
            except Exception:
                return None

        return (
            _to_pos_int(processed_width),
            _to_pos_int(processed_height),
            _to_pos_int(original_width),
            _to_pos_int(original_height),
            coordinate_type,
        )

    def _parse_response_s2(
        self,
        response: str,
        processed_width: Optional[int] = None,
        processed_height: Optional[int] = None,
        original_width: Optional[int] = None,
        original_height: Optional[int] = None,
        coordinate_type: Optional[str] = None,
    ) -> Tuple[str, List[str]]:
        # Keep official fallback behavior.
        if not (original_width and original_height):
            original_width, original_height = self.screen_size
        coordinate_type = str(coordinate_type or self.coordinate_type).lower()
        low_level_instruction = ""
        pyautogui_code: List[str] = []

        if response is None or not str(response).strip():
            return low_level_instruction, pyautogui_code

        def adjust_coordinates(x: float, y: float) -> Tuple[int, int]:
            if not (original_width and original_height):
                return int(x), int(y)
            if coordinate_type == "absolute":
                if processed_width and processed_height:
                    x_scale = original_width / processed_width
                    y_scale = original_height / processed_height
                    return int(x * x_scale), int(y * y_scale)
                return int(x), int(y)
            x_scale = original_width / 999
            y_scale = original_height / 999
            return int(x * x_scale), int(y * y_scale)

        def process_tool_call(json_str: str) -> None:
            try:
                tool_call = json.loads(json_str)
                if tool_call.get("name") == "computer_use":
                    args = tool_call["arguments"]
                    action = args["action"]

                    def _get_duration(default: float = 0.5) -> float:
                        try:
                            return float(args.get("duration", default))
                        except (TypeError, ValueError):
                            return default

                    def _clean_keys(raw_keys: Any) -> List[Any]:
                        keys = raw_keys if isinstance(raw_keys, list) else [raw_keys]
                        cleaned_keys: List[Any] = []
                        for key in keys:
                            if isinstance(key, str):
                                if key.startswith("keys=["):
                                    key = key[6:]
                                if key.endswith("]"):
                                    key = key[:-1]
                                if key.startswith("['") or key.startswith('["'):
                                    key = key[2:] if len(key) > 2 else key
                                if key.endswith("']") or key.endswith('"]'):
                                    key = key[:-2] if len(key) > 2 else key
                                key = key.strip()
                                cleaned_keys.append(key)
                            else:
                                cleaned_keys.append(key)
                        return cleaned_keys

                    if action == "left_click" or action == "click":
                        if "coordinate" in args:
                            x, y = args["coordinate"]
                            adj_x, adj_y = adjust_coordinates(x, y)
                            pyautogui_code.append(f"pyautogui.click({adj_x}, {adj_y})")
                        else:
                            pyautogui_code.append("pyautogui.click()")

                    elif action == "right_click":
                        if "coordinate" in args:
                            x, y = args["coordinate"]
                            adj_x, adj_y = adjust_coordinates(x, y)
                            pyautogui_code.append(f"pyautogui.rightClick({adj_x}, {adj_y})")
                        else:
                            pyautogui_code.append("pyautogui.rightClick()")

                    elif action == "middle_click":
                        if "coordinate" in args:
                            x, y = args["coordinate"]
                            adj_x, adj_y = adjust_coordinates(x, y)
                            pyautogui_code.append(f"pyautogui.middleClick({adj_x}, {adj_y})")
                        else:
                            pyautogui_code.append("pyautogui.middleClick()")

                    elif action == "double_click":
                        if "coordinate" in args:
                            x, y = args["coordinate"]
                            adj_x, adj_y = adjust_coordinates(x, y)
                            pyautogui_code.append(f"pyautogui.doubleClick({adj_x}, {adj_y})")
                        else:
                            pyautogui_code.append("pyautogui.doubleClick()")

                    elif action == "triple_click":
                        if "coordinate" in args:
                            x, y = args["coordinate"]
                            adj_x, adj_y = adjust_coordinates(x, y)
                            pyautogui_code.append(f"pyautogui.tripleClick({adj_x}, {adj_y})")
                        else:
                            pyautogui_code.append("pyautogui.tripleClick()")

                    elif action == "type":
                        text = args.get("text", "")

                        try:
                            text = text.encode("latin-1", "backslashreplace").decode("unicode_escape")
                        except Exception as e:
                            logger.error(f"Failed to unescape text: {e}")

                        result = ""
                        for char in text:
                            if char == "\n":
                                result += "pyautogui.press('enter')\n"
                            elif char == "'":
                                result += 'pyautogui.press("\'")\n'
                            elif char == "\\":
                                result += "pyautogui.press('\\\\')\n"
                            elif char == '"':
                                result += "pyautogui.press('\"')\n"
                            else:
                                result += f"pyautogui.press('{char}')\n"

                        pyautogui_code.append(result)

                    elif action == "key":
                        keys = _clean_keys(args.get("keys", []))

                        keys_str = ", ".join([f"'{key}'" for key in keys])
                        if len(keys) > 1:
                            pyautogui_code.append(f"pyautogui.hotkey({keys_str})")
                        else:
                            pyautogui_code.append(f"pyautogui.press({keys_str})")

                    elif action == "key_down":
                        keys = _clean_keys(args.get("keys", []))
                        for k in keys:
                            pyautogui_code.append(f"pyautogui.keyDown('{k}')")

                    elif action == "key_up":
                        keys = _clean_keys(args.get("keys", []))
                        for k in reversed(keys):
                            pyautogui_code.append(f"pyautogui.keyUp('{k}')")

                    elif action == "scroll":
                        pixels = args.get("pixels", 0)
                        pyautogui_code.append(f"pyautogui.scroll({pixels})")

                    elif action == "wait":
                        pyautogui_code.append("WAIT")

                    elif action == "terminate":
                        status = args.get("status", "success")
                        if str(status).lower() == "failure":
                            pyautogui_code.append("FAIL")
                        else:
                            pyautogui_code.append("DONE")

                    elif action == "mouse_move":
                        if "coordinate" in args and "coordinate_2" in args:
                            start_x, start_y = args["coordinate"]
                            end_x, end_y = args["coordinate_2"]
                            adj_start_x, adj_start_y = adjust_coordinates(start_x, start_y)
                            adj_end_x, adj_end_y = adjust_coordinates(end_x, end_y)
                            pyautogui_code.append(f"pyautogui.moveTo({adj_start_x}, {adj_start_y})")
                            pyautogui_code.append(
                                f"pyautogui.dragTo({adj_end_x}, {adj_end_y}, duration={_get_duration()})"
                            )
                        elif "coordinate" in args and "scroll" in args:
                            x, y = args["coordinate"]
                            adj_x, adj_y = adjust_coordinates(x, y)
                            pyautogui_code.append(f"pyautogui.moveTo({adj_x}, {adj_y})")
                            pyautogui_code.append(f"pyautogui.scroll({args.get('scroll', 0)})")
                        elif "coordinate" in args:
                            x, y = args["coordinate"]
                            adj_x, adj_y = adjust_coordinates(x, y)
                            if "duration" in args:
                                pyautogui_code.append(
                                    f"pyautogui.moveTo({adj_x}, {adj_y}, duration={_get_duration()})"
                                )
                            else:
                                pyautogui_code.append(f"pyautogui.moveTo({adj_x}, {adj_y})")
                        else:
                            pyautogui_code.append("pyautogui.moveTo(0, 0)")

                    elif action == "left_click_drag":
                        if "coordinate" in args:
                            x, y = args["coordinate"]
                            adj_x, adj_y = adjust_coordinates(x, y)
                            duration = args.get("duration", 0.5)
                            pyautogui_code.append(f"pyautogui.dragTo({adj_x}, {adj_y}, duration={duration})")
                        else:
                            pyautogui_code.append("pyautogui.dragTo(0, 0)")
            except (json.JSONDecodeError, KeyError) as e:
                logger.error(f"Failed to parse tool call: {e}")

        lines = response.split("\n")
        inside_tool_call = False
        current_tool_call: List[str] = []

        for line in lines:
            line = line.strip()
            if not line:
                continue

            if line.lower().startswith(("action:")):
                if not low_level_instruction:
                    low_level_instruction = line.split("Action:")[-1].strip()
                continue

            if line.startswith("<tool_call>"):
                inside_tool_call = True
                continue
            elif line.startswith("</tool_call>"):
                if current_tool_call:
                    process_tool_call("\n".join(current_tool_call))
                    current_tool_call = []
                inside_tool_call = False
                continue

            if inside_tool_call:
                current_tool_call.append(line)
                continue

            if line.startswith("{") and line.endswith("}"):
                try:
                    json_obj = json.loads(line)
                    if "name" in json_obj and "arguments" in json_obj:
                        process_tool_call(line)
                except json.JSONDecodeError:
                    pass

        if current_tool_call:
            process_tool_call("\n".join(current_tool_call))

        if not low_level_instruction and len(pyautogui_code) > 0:
            first_action = pyautogui_code[0]
            if "." in first_action:
                action_type = first_action.split(".", 1)[1].split("(", 1)[0]
            else:
                action_type = first_action.lower()
            low_level_instruction = f"Performing {action_type} action"

        return low_level_instruction, pyautogui_code

    def parse(self, text: str, extras: Dict[str, Any] | None = None) -> Dict[str, Any]:
        extras = extras or {}
        response = text if isinstance(text, str) else ""
        p_w, p_h, o_w, o_h, c_t = self._resolve_parse_dims(extras)
        low_level_instruction, pyautogui_code = self._parse_response_s2(
            response=response,
            processed_width=p_w,
            processed_height=p_h,
            original_width=o_w,
            original_height=o_h,
            coordinate_type=c_t,
        )
        return {
            "actions": pyautogui_code,
            "prediction": response,
            "action": low_level_instruction,
        }

    def __call__(self, text: str, extras: Dict[str, Any] | None = None):
        result = self.parse(text, extras or {})
        actions = result.get("actions") or []
        if not actions:
            actions = ["FAIL"]
        return result.get("action") or "", actions

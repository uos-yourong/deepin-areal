from typing import Dict, Any


class GuiModel:
    def __init__(self):
        pass

    def parse(self, text: str, extras: Dict[str, Any] | None = None) -> Dict[str, Any]:
        raise NotImplementedError

    def __call__(self, text: str, extras: Dict[str, Any] | None = None) -> Dict[str, Any]:
        raise NotImplementedError
        

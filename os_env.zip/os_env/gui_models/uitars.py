import ast
import re
import math
import os
import logging
from typing import Dict, Any, List, Optional
from .base import GuiModel


FINISH_WORD = "finished"
WAIT_WORD = "wait"
ENV_FAIL_WORD = "error_env"
CALL_USER = "call_user"

IMAGE_FACTOR = 28
MIN_PIXELS = 100 * 28 * 28
MAX_PIXELS = 16384 * 28 * 28
MAX_RATIO = 200

_CONTROL_TOKEN_PATTERN = re.compile(r"<\|[^>|]+\|>")
logger = logging.getLogger(__name__)


def _escape_single_quotes(text: str) -> str:
    pattern = r"(?<!\\)'"
    return re.sub(pattern, r"\\'", text)


def _round_by_factor(number: int, factor: int) -> int:
    return round(number / factor) * factor


def _ceil_by_factor(number: int, factor: int) -> int:
    return math.ceil(number / factor) * factor


def _floor_by_factor(number: int, factor: int) -> int:
    return math.floor(number / factor) * factor


def _strip_control_tokens(text: str) -> str:
    """Remove Qwen-style control tokens such as <|im_end|> or <|box_start|>."""
    return _CONTROL_TOKEN_PATTERN.sub("", text)


def _smart_resize(height: int, width: int, factor: int = IMAGE_FACTOR, min_pixels: int = MIN_PIXELS, max_pixels: int = MAX_PIXELS) -> tuple[int, int]:
    if max(height, width) / min(height, width) > MAX_RATIO:
        raise ValueError(
            f"absolute aspect ratio must be smaller than {MAX_RATIO}, got {max(height, width) / min(height, width)}"
        )
    h_bar = max(factor, _round_by_factor(height, factor))
    w_bar = max(factor, _round_by_factor(width, factor))
    if h_bar * w_bar > max_pixels:
        beta = math.sqrt((height * width) / max_pixels)
        h_bar = _floor_by_factor(height / beta, factor)
        w_bar = _floor_by_factor(width / beta, factor)
    elif h_bar * w_bar < min_pixels:
        beta = math.sqrt(min_pixels / (height * width))
        h_bar = _ceil_by_factor(height * beta, factor)
        w_bar = _ceil_by_factor(width * beta, factor)
    return h_bar, w_bar


def _parse_action(action_str: str):
    try:
        node = ast.parse(action_str, mode='eval')
        if not isinstance(node, ast.Expression):
            raise ValueError("Not an expression")
        call = node.body
        if not isinstance(call, ast.Call):
            raise ValueError("Not a function call")
        if isinstance(call.func, ast.Name):
            func_name = call.func.id
        elif isinstance(call.func, ast.Attribute):
            func_name = call.func.attr
        else:
            func_name = None
        kwargs = {}
        for kw in call.keywords:
            key = kw.arg
            if isinstance(kw.value, ast.Constant):
                value = kw.value.value
            elif isinstance(kw.value, ast.Str):
                value = kw.value.s
            else:
                value = None
            kwargs[key] = value
        return {
            'function': func_name,
            'args': kwargs
        }
    except Exception:
        logger.exception("Failed to parse action expression: %s", action_str)
        return None


def _parse_action_to_structure_output(text: str, factor: int, origin_resized_height: int, origin_resized_width: int, model_type: str, max_pixels: int = MAX_PIXELS, min_pixels: int = MIN_PIXELS) -> List[Dict[str, Any]]:
    text = _strip_control_tokens(text.strip())
    if model_type == "qwen25vl":
        _smart_resize(origin_resized_height, origin_resized_width, factor=IMAGE_FACTOR, min_pixels=min_pixels, max_pixels=max_pixels)
    if text.startswith("Thought:"):
        thought_pattern = r"Thought: (.+?)(?=\s*Action:|$)"
        thought_hint = "Thought: "
    elif text.startswith("Reflection:"):
        thought_pattern = r"Reflection: (.+?)Action_Summary: (.+?)(?=\s*Action:|$)"
        thought_hint = "Reflection: "
    elif text.startswith("Action_Summary:"):
        thought_pattern = r"Action_Summary: (.+?)(?=\s*Action:|$)"
        thought_hint = "Action_Summary: "
    else:
        thought_pattern = r"Thought: (.+?)(?=\s*Action:|$)"
        thought_hint = "Thought: "
    reflection, thought = None, None
    thought_match = re.search(thought_pattern, text, re.DOTALL)
    if thought_match:
        if len(thought_match.groups()) == 1:
            thought = thought_match.group(1).strip()
        elif len(thought_match.groups()) == 2:
            thought = thought_match.group(2).strip()
            reflection = thought_match.group(1).strip()
    if "Action:" not in text:
        raise ValueError("missing Action:")
    action_str = text.split("Action:")[-1]
    tmp_all_action = action_str.split("\n\n")
    all_action = []
    for a_str in tmp_all_action:
        if "type(content" in a_str:
            def _escape_quotes(match):
                return match.group(1)
            pattern = r"type\(content='(.*?)'\)"
            content = re.sub(pattern, _escape_quotes, a_str)
            content = _escape_single_quotes(content)
            a_str = "type(content='" + content + "')"
        all_action.append(a_str)
    parsed_actions = [_parse_action(a.replace("\n","\\n").lstrip()) for a in all_action]
    actions: List[Dict[str, Any]] = []
    for action_instance, raw_str in zip(parsed_actions, all_action):
        if action_instance is None:
            raise ValueError(f"Action can't parse: {raw_str}")
        action_type = action_instance["function"]
        params = action_instance["args"]
        action_inputs: Dict[str, Any] = {}
        for param_name, param in params.items():
            if param == "":
                continue
            param = str(param).lstrip()
            action_inputs[param_name.strip()] = param
            if "start_box" in param_name or "end_box" in param_name:
                ori_box = param
                numbers = ori_box.replace("(", "").replace(")", "").split(",")
                vals = [float(num) for num in numbers]
                if len(vals) == 2:
                    vals = [vals[0], vals[1], vals[0], vals[1]]
                action_inputs[param_name.strip()] = str(vals)
        actions.append({
            "reflection": reflection,
            "thought": thought,
            "action_type": action_type,
            "action_inputs": action_inputs,
            "text": text
        })
    return actions


def _parse_box_value(raw_val: Any) -> Optional[List[float]]:
    """Parse box value safely from various formats.

    Args:
        raw_val: Can be string like "[x1, y1, x2, y2]" or "(x1, y1)" or already a list

    Returns:
        List of 4 floats [x1, y1, x2, y2] or None if invalid
    """
    if raw_val is None:
        return None
    candidate = raw_val
    if isinstance(raw_val, str):
        box_str = raw_val.strip()
        if not box_str or box_str.lower() in {"none", "null"}:
            return None
        candidate = box_str
    try:
        if isinstance(candidate, str):
            parsed = ast.literal_eval(candidate)
        else:
            parsed = candidate
    except Exception:
        logger.warning("Failed to parse bounding box value: %s", raw_val)
        return None
    if not isinstance(parsed, (list, tuple)):
        logger.warning("Bounding box is not a list/tuple: %s", parsed)
        return None
    coords = list(parsed)
    if len(coords) == 2:
        coords = [coords[0], coords[1], coords[0], coords[1]]
    if len(coords) != 4:
        logger.warning("Bounding box has invalid length (%s): %s", len(coords), coords)
        return None
    try:
        return [float(coords[0]), float(coords[1]), float(coords[2]), float(coords[3])]
    except Exception:
        logger.warning("Bounding box contains non-numeric values: %s", coords)
        return None


def _parsing_response_to_pyautogui_code(response: Dict[str, Any], image_height: int, image_width: int, input_swap: bool = True) -> str:
    pyautogui_code = f"import pyautogui\nimport time\n"
    observation = response.get("observation") or ""
    thought = response.get("thought") or ""
    pyautogui_code += f"'''\nObservation:\n{observation}\n\nThought:\n{thought}\n'''\n"
    action_type = response.get("action_type")
    action_inputs = response.get("action_inputs", {})
    if action_type == "hotkey":
        if "key" in action_inputs:
            hotkey = action_inputs.get("key", "")
        else:
            hotkey = action_inputs.get("hotkey", "")
        if hotkey == "arrowleft":
            hotkey = "left"
        elif hotkey == "arrowright":
            hotkey = "right"
        elif hotkey == "arrowup":
            hotkey = "up"
        elif hotkey == "arrowdown":
            hotkey = "down"
        if hotkey:
            keys = hotkey.split()
            convert_keys = []
            for key in keys:
                if key == "space":
                    key = ' '
                convert_keys.append(key)
            pyautogui_code += f"\npyautogui.hotkey({', '.join([repr(k) for k in convert_keys])})"
    elif action_type == "press":
        if "key" in action_inputs:
            key_to_press = action_inputs.get("key", "")
        else:
            key_to_press = action_inputs.get("press", "")
        if key_to_press:
            if key_to_press == "arrowleft":
                key_to_press = "left"
            elif key_to_press == "arrowright":
                key_to_press = "right"
            elif key_to_press == "arrowup":
                key_to_press = "up"
            elif key_to_press == "arrowdown":
                key_to_press = "down"
            elif key_to_press == "space":
                key_to_press = " "
            pyautogui_code += f"\npyautogui.press({repr(key_to_press)})"
    elif action_type == "keyup":
        key_to_up = action_inputs.get("key", "")
        pyautogui_code += f"\npyautogui.keyUp({repr(key_to_up)})"
    elif action_type == "keydown":
        key_to_down = action_inputs.get("key", "")
        pyautogui_code += f"\npyautogui.keyDown({repr(key_to_down)})"
    elif action_type == "type":
        content = action_inputs.get("content", "")
        content = _escape_single_quotes(content)
        stripped_content = content
        if content.endswith("\n") or content.endswith("\\n"):
            stripped_content = stripped_content.rstrip("\\n").rstrip("\n")
        if content:
            if input_swap:
                pyautogui_code += f"\nimport pyperclip"
                pyautogui_code += f"\npyperclip.copy('{stripped_content}')"
                pyautogui_code += f"\npyautogui.hotkey('ctrl', 'v')"
                pyautogui_code += f"\ntime.sleep(0.5)\n"
                if content.endswith("\n") or content.endswith("\\n"):
                    pyautogui_code += f"\npyautogui.press('enter')"
            else:
                pyautogui_code += f"\npyautogui.write('{stripped_content}', interval=0.1)"
                pyautogui_code += f"\ntime.sleep(0.5)\n"
                if content.endswith("\n") or content.endswith("\\n"):
                    pyautogui_code += f"\npyautogui.press('enter')"
    elif action_type in ["drag", "select"]:
        start_box = _parse_box_value(action_inputs.get("start_box"))
        end_box = _parse_box_value(action_inputs.get("end_box"))
        if start_box and end_box:
            x1, y1, _, _ = start_box
            x2, y2, _, _ = end_box
            sx = float(x1)
            sy = float(y1)
            ex = float(x2)
            ey = float(y2)
            pyautogui_code += (
                f"\npyautogui.moveTo({sx}, {sy})\n"
                f"\npyautogui.dragTo({ex}, {ey}, duration=1.0)\n"
            )
        else:
            logger.warning("Skipping %s due to invalid drag boxes: %s", action_type, action_inputs)
    elif action_type == "scroll":
        start_box = _parse_box_value(action_inputs.get("start_box"))
        if start_box:
            x1, y1, _, _ = start_box
            x = float(x1)
            y = float(y1)
        else:
            x = None
            y = None
        direction = action_inputs.get("direction", "")
        if x is None:
            if "up" in direction.lower():
                pyautogui_code += f"\npyautogui.scroll(5)"
            elif "down" in direction.lower():
                pyautogui_code += f"\npyautogui.scroll(-5)"
        else:
            if "up" in direction.lower():
                pyautogui_code += f"\npyautogui.scroll(5, x={x}, y={y})"
            elif "down" in direction.lower():
                pyautogui_code += f"\npyautogui.scroll(-5, x={x}, y={y})"
    elif action_type in ["click", "left_single", "left_double", "right_single", "hover"]:
        start_box = _parse_box_value(action_inputs.get("start_box"))
        if start_box:
            x1, y1, x2, y2 = start_box
            x = float((x1 + x2) / 2)
            y = float((y1 + y2) / 2)
            if action_type == "left_single" or action_type == "click":
                pyautogui_code += f"\npyautogui.click({x}, {y}, button='left')"
            elif action_type == "left_double":
                pyautogui_code += f"\npyautogui.doubleClick({x}, {y}, button='left')"
            elif action_type == "right_single":
                pyautogui_code += f"\npyautogui.click({x}, {y}, button='right')"
            elif action_type == "hover":
                pyautogui_code += f"\npyautogui.moveTo({x}, {y})"
        else:
            logger.warning("Skipping %s due to invalid start_box: %s", action_type, action_inputs)
    return pyautogui_code


class UitarsGuiModel(GuiModel):
    def __init__(self):
        self.action_parse_res_factor = 1000
        self.max_pixels = MAX_PIXELS
        self.min_pixels = MIN_PIXELS
        self.input_swap = True
        self.callusr_tolerance = 1


    def parse(self, text: str, extras: Dict[str, Any] | None = None) -> Dict[str, Any]:
        extras = extras or {}
        h = int(os.environ.get("SCREEN_HEIGHT", "1080") or 1080)
        w = int(os.environ.get("SCREEN_WIDTH", "1920") or 1920)
        model_type = extras.get("model_type") or "uitars"
        actions: List[Any] = []
        try:
            parsed_responses = _parse_action_to_structure_output(
                text,
                self.action_parse_res_factor,
                h,
                w,
                model_type,
                self.max_pixels,
                self.min_pixels,
            )
        except Exception as e:
            logger.exception("Failed to parse UITARS response")
            fail_actions = ["FAIL"]
            return {"actions": fail_actions, "error": str(e)}
        for pr in parsed_responses:
            if "action_type" in pr:
                if pr["action_type"] == FINISH_WORD:
                    done_actions = ["DONE"]
                    return {"actions": done_actions, "prediction": text}
                elif pr["action_type"] == WAIT_WORD:
                    wait_actions = ["WAIT"]
                    return {"actions": wait_actions, "prediction": text}
                elif pr["action_type"] == ENV_FAIL_WORD:
                    fail_actions = ["FAIL"]
                    return {"actions": fail_actions, "prediction": text}
                elif pr["action_type"] == CALL_USER:
                    wait_actions = ["WAIT"]
                    return {"actions": wait_actions, "prediction": text}
            code = _parsing_response_to_pyautogui_code(pr, h, w, self.input_swap)
            actions.append(code)
        if not actions:
            actions = ["FAIL"]
        return {"actions": actions, "prediction": text}

    def __call__(self, text: str, extras: Dict[str, Any] | None = None):
        res = self.parse(text, extras or {})
        return res.get("prediction") or text, list(res.get("actions") or [])

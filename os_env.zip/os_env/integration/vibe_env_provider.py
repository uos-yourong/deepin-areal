"""Provider that proxies os_env actions to the local tauri-vibe HTTP service."""

from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

import numpy as np
import requests
import time

from integration.os_env_bridge.session_adapter import extract_vibe_task


@dataclass
class StepResult:
    observation: Optional[np.ndarray]
    reward: float
    done: bool
    truncated: bool
    info: Dict[str, Any]


class VibeTauriProvider:
    def __init__(
        self,
        base_url: str = "http://localhost:8765",
        app_type: str = "wechat",
        screenshot_timeout: float = 2.0,
        max_retries: int = 3,
        **kwargs,
    ):
        self.base_url = base_url.rstrip("/")
        self.app_type = self._normalize_app_type(app_type)
        self.screenshot_timeout = screenshot_timeout
        self.max_retries = max_retries

        self._session = requests.Session()
        self._connected = False
        self._current_window_info: Optional[Dict[str, Any]] = None
        self._last_task_meta: Dict[str, Any] = {}

        self._connect()

    def _connect(self) -> bool:
        for attempt in range(self.max_retries):
            try:
                response = self._session.get(f"{self.base_url}/health", timeout=5)
                if response.status_code == 200:
                    self._connected = True
                    return True
            except requests.exceptions.ConnectionError:
                if attempt < self.max_retries - 1:
                    time.sleep(1)
                else:
                    raise RuntimeError(
                        f"Cannot connect to Vibe Tauri at {self.base_url}. "
                        "Please ensure Vibe HTTP server is running."
                    )
        return False

    def reset(
        self,
        task_config: Optional[Dict[str, Any]] = None,
        seed: Optional[int] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Optional[np.ndarray], Dict[str, Any]]:
        if not self._connected:
            self._connect()

        payload = self._build_reset_payload(task_config, seed, options)
        response = self._session.post(f"{self.base_url}/reset", json=payload, timeout=10)
        response.raise_for_status()
        data = response.json()

        state = data.get("state", {})
        window = state.get("window", {})
        info = data.get("info", {})
        task_meta = {**dict(self._last_task_meta), **dict(info.get("task_meta") or {})}
        hook_trace = dict(info.get("hook_trace") or {})
        self.app_type = str(info.get("app_type") or payload.get("app_type") or self.app_type)
        self._last_task_meta = task_meta

        self._current_window_info = {
            "window_position": (window.get("x", 0), window.get("y", 0)),
            "window_size": (window.get("width", 1200), window.get("height", 800)),
            "screenshot_region": (
                window.get("x", 0),
                window.get("y", 0),
                window.get("width", 1200),
                window.get("height", 800),
            ),
            "provider": "vibe_tauri",
            "app_type": self.app_type,
            "task_info": info,
            "task_meta": task_meta,
            "hook_trace": hook_trace,
            "internal_state": state,
        }
        return None, self._current_window_info

    def step(self, action: Dict[str, Any]) -> StepResult:
        vibe_action = self._convert_action(action)
        try:
            response = self._session.post(
                f"{self.base_url}/step",
                json={"action": vibe_action},
                timeout=5,
            )
            response.raise_for_status()
            data = response.json()

            state = data.get("state", {})
            window = state.get("window", {})
            step_info = dict(data.get("info", {}) or {})
            hook_trace = dict(step_info.get("hook_trace") or {})
            task_meta = {**dict(self._last_task_meta), **dict(step_info.get("task_meta") or {})}
            self._last_task_meta = task_meta
            if self._current_window_info is None:
                self._current_window_info = {}
            self._current_window_info.update(
                {
                    "window_position": (window.get("x", 0), window.get("y", 0)),
                    "window_size": (window.get("width", 1200), window.get("height", 800)),
                    "step_count": state.get("step_count", 0),
                    "app_type": state.get("active_app", self.app_type),
                    "internal_state": state,
                }
            )

            info = {
                **self._current_window_info,
                "action_valid": True,
                "reward_components": data.get("reward", {}),
                "step_info": step_info,
                "task_meta": task_meta,
                "hook_trace": hook_trace,
            }
            return StepResult(
                observation=None,
                reward=self._reward_total(data.get("reward", {})),
                done=bool(data.get("done", False)),
                truncated=bool(data.get("truncated", False)),
                info=info,
            )
        except requests.exceptions.RequestException as exc:
            return StepResult(
                observation=None,
                reward=0.0,
                done=False,
                truncated=False,
                info={"error": str(exc), "task_meta": dict(self._last_task_meta)},
            )

    def _build_reset_payload(
        self,
        task_config: Optional[Dict[str, Any]],
        seed: Optional[int],
        options: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        app_type = self.app_type
        backend_task = None
        merged_options = dict(options or {})

        if isinstance(task_config, dict):
            active_app, task, vibe_cfg = extract_vibe_task(task_config)
            if vibe_cfg:
                app_type = active_app or app_type
                backend_task = self._to_backend_task(task)
                merged_options = {**dict(vibe_cfg.get("options") or {}), **merged_options}
                if seed is None:
                    seed = vibe_cfg.get("seed") or (vibe_cfg.get("data_generation") or {}).get("seed")
                self._last_task_meta = {
                    "source": "vibe_config",
                    "app_type": app_type,
                    "task_type": backend_task.get("task_type", ""),
                    "instruction_id": task.get("instruction_id"),
                    "difficulty": backend_task.get("difficulty", 1),
                    "instruction": task.get("instruction") or task.get("instruction_text"),
                }
            else:
                app_type = str(task_config.get("app_type") or app_type)
                backend_task = self._to_backend_task(task_config)
                self._last_task_meta = {
                    "source": "task_config",
                    "app_type": app_type,
                    "task_type": backend_task.get("task_type", ""),
                    "instruction_id": task_config.get("instruction_id"),
                    "difficulty": backend_task.get("difficulty", 1),
                    "instruction": task_config.get("instruction") or task_config.get("instruction_text"),
                }

        self.app_type = self._normalize_app_type(app_type)
        return {
            "app_type": self.app_type,
            "task_config": backend_task,
            "seed": seed,
            "options": merged_options or None,
        }

    def _convert_action(self, action: Dict[str, Any]) -> Dict[str, Any]:
        action_type = action.get("action_type", "mouse")
        if action_type == "system":
            target_app = action.get("target_app") or action.get("app") or action.get("target")
            if target_app is not None:
                target_app = str(target_app)
            reset_task = action.get("reset_task", False)
            if isinstance(reset_task, str):
                reset_task = reset_task.lower() in {"1", "true", "yes", "on"}
            return {
                "type": "system",
                "system_action": {
                    "action": action.get("action", "switch_app"),
                    "target_app": target_app,
                    "reset_task": bool(reset_task),
                },
            }

        if action_type == "mouse":
            coord = action.get("coordinate", [0, 0])
            if isinstance(coord, (list, tuple)) and len(coord) >= 2:
                return {
                    "type": "mouse",
                    "mouse_action": {
                        "subtype": action.get("move_type", "move"),
                        "coordinate": {"x": coord[0], "y": coord[1]},
                        "button": action.get("button", "left"),
                        "delta": action.get("delta", 0),
                    },
                }

        if action_type == "keyboard":
            key_type = action.get("key_type", "type")
            if key_type == "type":
                return {
                    "type": "keyboard",
                    "keyboard_action": {
                        "subtype": "type_text",
                        "text": action.get("text", ""),
                    },
                }
            if key_type == "press":
                return {
                    "type": "keyboard",
                    "keyboard_action": {
                        "subtype": "key_press",
                        "key": action.get("key", ""),
                    },
                }

        return action

    def get_state(self) -> Optional[Dict[str, Any]]:
        try:
            response = self._session.get(f"{self.base_url}/state", timeout=2)
            return response.json().get("state")
        except Exception:
            return None

    def close(self) -> None:
        self._session.close()
        self._connected = False

    @staticmethod
    def _normalize_app_type(app_type: str) -> str:
        value = str(app_type or "wechat").strip().lower()
        aliases = {
            "wx": "wechat",
            "wecom": "wework",
            "enterprisewechat": "wework",
            "email": "mail",
            "邮箱": "mail",
            "企业微信": "wework",
            "tencentmeeting": "tencentmeeting",
            "tencent_meeting": "tencentmeeting",
            "meeting": "tencentmeeting",
            "腾讯会议": "tencentmeeting",
        }
        return aliases.get(value, value or "wechat")

    @staticmethod
    def _to_backend_task(task: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(task, dict):
            return {}
        difficulty = task.get("difficulty", 1)
        if isinstance(difficulty, bool) or difficulty is None:
            difficulty = 1
        try:
            difficulty = int(difficulty)
        except Exception:
            difficulty = 1

        max_steps = task.get("max_steps", 50)
        if isinstance(max_steps, bool) or max_steps is None:
            max_steps = 50
        try:
            max_steps = int(max_steps)
        except Exception:
            max_steps = 50

        hook_rules = task.get("hook_rules")
        if hook_rules is None:
            hook_rules = task.get("hooks")
        if not isinstance(hook_rules, list):
            hook_rules = []
        else:
            hook_rules = list(hook_rules)

        return {
            "task_type": task.get("task_type") or task.get("type") or "",
            "difficulty": difficulty,
            "description": task.get("description")
            or task.get("instruction")
            or task.get("instruction_text")
            or "",
            "initial_state_config": dict(task.get("initial_state_config") or {}),
            "target": dict(task.get("target") or {}),
            "success_conditions": list(task.get("success_conditions") or []),
            "failure_conditions": list(task.get("failure_conditions") or []),
            "max_steps": max_steps,
            "reward_config": dict(task.get("reward_config") or task.get("reward") or {}),
            "randomization": dict(task.get("randomization") or {}),
            "hook_rules": hook_rules,
        }

    @staticmethod
    def _reward_total(reward: Dict[str, Any]) -> float:
        if not isinstance(reward, dict):
            return 0.0
        if "total" in reward:
            try:
                return float(reward.get("total") or 0.0)
            except Exception:
                return 0.0
        total = 0.0
        for key in ("base", "progress", "efficiency", "penalties", "terminal", "hooks"):
            try:
                total += float(reward.get(key) or 0.0)
            except Exception:
                continue
        return total

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

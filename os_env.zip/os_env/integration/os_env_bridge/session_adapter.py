"""Utilities for normalizing ``vibe_config`` payloads into os_env task payloads."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, Optional, Tuple


def _coerce_dict(value: Any) -> Dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _coerce_int(value: Any, default: int = 0) -> int:
    if isinstance(value, bool):
        return default
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        try:
            return int(value)
        except Exception:
            return default
    return default


def _normalize_app_type(value: Any) -> str:
    raw = str(value or "wechat").strip().lower()
    aliases = {
        "wx": "wechat",
        "wecom": "wework",
        "enterprisewechat": "wework",
        "email": "mail",
        "邮箱": "mail",
        "企业微信": "wework",
        "tencentmeeting": "tencentmeeting",
        "tencent_meeting": "tencentmeeting",
        "meeting": "tencentmeeting",
        "腾讯会议": "tencentmeeting",
    }
    return aliases.get(raw, raw or "wechat")


def extract_vibe_task(raw_payload: Optional[Dict[str, Any]]) -> Tuple[str, Dict[str, Any], Dict[str, Any]]:
    """Extract ``app_type`` / ``task`` / ``vibe_config`` from a raw task payload."""

    payload = _coerce_dict(raw_payload)
    vibe_cfg = _coerce_dict(payload.get("vibe_config"))
    if not vibe_cfg:
        return "wechat", {}, {}

    active_app = _normalize_app_type(vibe_cfg.get("active_app") or vibe_cfg.get("app_type"))
    task = {}

    apps = vibe_cfg.get("apps")
    if isinstance(apps, list) and apps:
        first = apps[0] if isinstance(apps[0], dict) else {}
        if isinstance(first, dict):
            active_app = _normalize_app_type(first.get("app_type") or active_app)
            task = _coerce_dict(first.get("task") or first.get("task_config"))
    else:
        task = _coerce_dict(vibe_cfg.get("task") or vibe_cfg.get("task_config"))

    if task.get("app_type"):
        active_app = _normalize_app_type(task.get("app_type"))

    return active_app, task, vibe_cfg


def build_session_payload(raw_payload: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Build a provider-facing reset payload from a raw vibe payload."""

    active_app, task, vibe_cfg = extract_vibe_task(raw_payload)
    if not vibe_cfg:
        return _coerce_dict(raw_payload)

    seed = vibe_cfg.get("seed")
    data_generation = _coerce_dict(vibe_cfg.get("data_generation"))
    if seed is None:
        seed = data_generation.get("seed")

    task_payload = deepcopy(task)
    task_payload.setdefault("app_type", active_app)

    return {
        "app_type": active_app,
        "task_config": task_payload,
        "seed": seed,
        "options": _coerce_dict(vibe_cfg.get("options")),
        "raw_vibe_config": deepcopy(vibe_cfg),
    }


def normalize_task_config_for_os_env(
    raw_payload: Optional[Dict[str, Any]],
) -> Tuple[Optional[Dict[str, Any]], Dict[str, Any], Dict[str, Any]]:
    """Normalize incoming payload to os_env's internal task payload shape."""

    payload = _coerce_dict(raw_payload)
    if not payload:
        return None, {}, {}

    if "vibe_config" not in payload:
        return payload, {"source": "legacy_task_config"}, {}

    active_app, task, vibe_cfg = extract_vibe_task(payload)
    task_type = str(task.get("task_type") or task.get("type") or "default")
    difficulty = _coerce_int(task.get("difficulty", 1), 1)
    instruction_id = task.get("instruction_id")
    instruction = (
        task.get("instruction")
        or task.get("instruction_text")
        or f"{active_app}:{task_type}:{difficulty}"
    )
    seed = _coerce_int(vibe_cfg.get("seed"), None)
    data_generation = _coerce_dict(vibe_cfg.get("data_generation"))
    if seed is None:
        seed = _coerce_int(data_generation.get("seed"), None)

    normalized = {
        "id": instruction_id or f"{active_app}_{task_type}_{difficulty}",
        "instruction": instruction,
        "config": payload.get("config") if isinstance(payload.get("config"), list) else [],
        "vibe_task": deepcopy(task),
        "vibe_config": deepcopy(vibe_cfg),
        "vibe_session_payload": build_session_payload(payload),
    }

    task_meta = {
        "source": "vibe_config",
        "app_type": active_app,
        "task_type": task_type,
        "instruction_id": instruction_id,
        "difficulty": difficulty,
        "instruction": instruction,
        "seed": seed,
    }
    hook_trace = {
        "source": "vibe_config",
        "app_type": active_app,
        "task_type": task_type,
        "instruction_id": instruction_id,
    }
    return normalized, task_meta, hook_trace


def merge_vibe_runtime_info(
    info: Optional[Dict[str, Any]],
    runtime_info: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Merge runtime provider info into a response info dict."""

    merged = _coerce_dict(info)
    runtime = _coerce_dict(runtime_info)
    if not runtime:
        return merged

    hook_trace = _coerce_dict(merged.get("hook_trace"))
    hook_trace.update(_coerce_dict(runtime.get("hook_trace")))
    if hook_trace:
        merged["hook_trace"] = hook_trace

    task_meta = _coerce_dict(merged.get("task_meta"))
    task_meta.update(_coerce_dict(runtime.get("task_meta")))
    if task_meta:
        merged["task_meta"] = task_meta

    for key, value in runtime.items():
        if key in {"hook_trace", "task_meta"}:
            continue
        merged[key] = value

    return merged


__all__ = [
    "build_session_payload",
    "extract_vibe_task",
    "merge_vibe_runtime_info",
    "normalize_task_config_for_os_env",
]

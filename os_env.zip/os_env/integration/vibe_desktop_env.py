"""Vibe Desktop Environment

与现有 DesktopEnv 集成的增强版本。
完全兼容 Gym Env 接口，替换 provider 即可使用 Vibe 仿真环境。

使用方法:
    # 在训练脚本中替换 DesktopEnv 为 VibeDesktopEnv
    from vibe.integration.vibe_desktop_env import VibeDesktopEnv

    env = VibeDesktopEnv(
        provider_name="vibe",  # 使用 Vibe 仿真
        vibe_base_url="http://localhost:8765",
        vibe_app_type="wechat"
    )

    # 其他用法完全相同
    obs = env.reset(task_config)
    obs, reward, done, truncated, info = env.step(action)
"""

import os
import base64
import sys
import time
import logging
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Type

# 添加到路径
vibe_root = Path(__file__).parent.parent
if str(vibe_root) not in sys.path:
    sys.path.insert(0, str(vibe_root))

from desktop_env.desktop_env import DesktopEnv

from integration.vibe_env_provider import VibeTauriProvider, StepResult

logger = logging.getLogger("vibe.env")


class VibeDesktopEnv(DesktopEnv):
    """增强版 DesktopEnv，支持 Vibe 仿真环境

    完全向下兼容原有 DesktopEnv，只需更改 provider_name 为 "vibe" 即可使用。

    新增参数:
        provider_name (str): 设为 "vibe" 使用 Vibe 仿真，其他值保持原有行为
        vibe_base_url (str): Vauri HTTP 服务地址 (default: http://localhost:8765)
        vibe_app_type (str): wechat/wecom/qq (default: wechat)
        vibe_max_retries (int): 连接重试次数 (default: 3)

    示例:
        # 原有用法（虚拟机）
        env = DesktopEnv(provider_name="libvirt", path_to_vm="...")

        # Vibe 仿真用法
        env = VibeDesktopEnv(
            provider_name="vibe",
            vibe_base_url="http://localhost:8765",
            vibe_app_type="wechat"
        )
    """

    def __init__(
        self,
        provider_name: str = "vibe",
        # Vibe 特有参数
        vibe_base_url: str = "http://localhost:8765",
        vibe_app_type: str = "wechat",
        vibe_max_retries: int = 3,
        screenshot_timeout: float = 2.0,
        # 原有参数兼容
        **kwargs,
    ):
        """
        初始化 Vibe Desktop Environment

        Args:
            provider_name: "vibe" 或原有 provider (libvirt, vmware, docker, etc.)
            vibe_base_url: Vibe Tauri HTTP 服务 URL
            vibe_app_type: 应用类型 (wechat/wecom/qq)
            vibe_max_retries: 连接重试次数
            screenshot_timeout: 截图等待超时
            **kwargs: 其他 DesktopEnv 参数（用于兼容原有 provider）
        """
        self.vibe_provider = None
        self.vibe_base_url = vibe_base_url
        self.vibe_app_type = vibe_app_type
        self.screenshot_timeout = screenshot_timeout

        if provider_name == "vibe":
            # 初始化 Vibe 模式
            logger.info(f"Initializing Vibe Desktop Environment (app: {vibe_app_type})")

            # 不调用父类 __init__ 的 provider 创建部分
            # 而是直接初始化 VibeProvider
            self._init_vibe_mode(
                base_url=vibe_base_url,
                app_type=vibe_app_type,
                max_retries=vibe_max_retries,
            )

            # 设置必要的属性（兼容父类）
            self.provider_name = "vibe"
            self.screen_width = kwargs.get("screen_width", 1920)
            self.screen_height = kwargs.get("screen_height", 1080)
            self.os_type = kwargs.get("os_type", "deepin")
            self.action_space = kwargs.get("action_space", "pyautogui")
            self.headless = kwargs.get("headless", False)
            self.require_a11y_tree = False
            self.require_terminal = False
            self.vm_ip = None
            self.server_port = None
            self.path_to_vm = f"vibe:{self.vibe_app_type}"
            self.cache_dir_base = kwargs.get(
                "cache_dir",
                str(vibe_root / "desktop_env" / "down_cache"),
            )
            self.cache_dir = self.cache_dir_base
            os.makedirs(self.cache_dir_base, exist_ok=True)
            self.config = []
            self.task_id = ""
            self.instruction = ""
            self.action_history = []
            self._step_no = 0
            self._traj_no = 0
            self.is_environment_used = False
            self.vibe_window_info = {}
            self._vibe_task_meta = {}
            self._vibe_hook_trace = {}

        else:
            # 使用原有模式
            super().__init__(provider_name=provider_name, **kwargs)

    def _init_vibe_mode(self, base_url: str, app_type: str, max_retries: int):
        """初始化 Vibe 模式"""
        try:
            self.vibe_provider = VibeTauriProvider(
                base_url=base_url, app_type=app_type, max_retries=max_retries
            )

            # 创建模拟的 controller（用于截图）
            self.controller = VibeScreenshotController(
                provider=self.vibe_provider, timeout=self.screenshot_timeout
            )

            self.instruction = ""

        except Exception as e:
            logger.error(f"Failed to initialize Vibe provider: {e}")
            raise

    def reset(
        self, task_config: Optional[Dict[str, Any]] = None, seed=None, options=None
    ) -> Dict[str, Any]:
        """重置环境

        兼容父类接口，返回包含 screenshot 的 observation dict。
        """
        if self.provider_name != "vibe":
            return super().reset(task_config, seed, options)

        # Vibe 模式
        try:
            obs, info = self.vibe_provider.reset(task_config, seed, options)

            # 保存窗口信息供 controller 截图使用
            self.vibe_window_info = info
            self.vibe_app_type = str(info.get("app_type") or self.vibe_app_type)
            self.path_to_vm = f"vibe:{self.vibe_app_type}"
            self._vibe_task_meta = dict(info.get("task_meta") or {})
            self._vibe_hook_trace = dict(info.get("hook_trace") or {})

            # 设置任务信息（如果有）
            if task_config:
                self._set_vibe_task_info(task_config)

            # 获取截图
            screenshot = self.controller.get_screenshot()

            # 构建 observation
            observation = {
                "screenshot": screenshot,
                "accessibility_tree": None,  # Vibe 模式不支持
                "terminal": None,
                "instruction": getattr(self, "instruction", ""),
            }

            # 重置计数
            self._step_no = 0
            self.action_history = []
            self.is_environment_used = False

            logger.info("Vibe environment reset complete")
            return observation

        except Exception as e:
            logger.error(f"Vibe reset error: {e}")
            raise

    def step(self, action, pause=2):
        """执行动作

        兼容父类接口，返回 (obs, reward, done, truncated, info)。
        """
        if self.provider_name != "vibe":
            return super().step(action, pause)

        # Vibe 模式
        self._step_no += 1
        self.action_history.append(action)
        self.is_environment_used = True

        try:
            # 执行动作
            result: StepResult = self.vibe_provider.step(action)

            # 暂停（如果需要）
            if pause > 0:
                time.sleep(pause)

            # 获取截图
            screenshot = self.controller.get_screenshot()

            # 构建 observation
            observation = {
                "screenshot": screenshot,
                "accessibility_tree": None,
                "terminal": None,
                "instruction": getattr(self, "instruction", ""),
            }

            # 构建 info
            info = {
                **result.info,
                "action_history": self.action_history.copy(),
                "step": self._step_no,
            }
            self._vibe_task_meta = dict(info.get("task_meta") or self._vibe_task_meta or {})
            self._vibe_hook_trace = dict(info.get("hook_trace") or {})

            logger.info(f"Step {self._step_no} completed. Reward: {result.reward:.2f}")

            return observation, result.reward, result.done, result.truncated, info

        except Exception as e:
            logger.error(f"Vibe step error: {e}")
            # 返回错误状态
            return self._get_obs(), 0.0, False, False, {"error": str(e)}

    def _get_obs(self):
        """获取当前观测"""
        if self.provider_name != "vibe":
            return super()._get_obs()

        return {
            "screenshot": self.controller.get_screenshot()
            if hasattr(self, "controller")
            else None,
            "accessibility_tree": None,
            "terminal": None,
            "instruction": getattr(self, "instruction", ""),
        }

    def reset_only(self) -> None:
        if self.provider_name != "vibe":
            return super().reset_only()
        self.reset(task_config=None)

    def setup_task(
        self,
        task_config: Optional[Dict[str, Any]],
        seed: Optional[int] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> bool:
        if self.provider_name != "vibe":
            return super().setup_task(task_config)
        self.reset(task_config=task_config, seed=seed, options=options)
        return True

    def _set_vibe_task_info(self, task_config: Optional[Dict[str, Any]]) -> None:
        if not isinstance(task_config, dict):
            self.task_id = ""
            self.instruction = ""
            self.config = []
            return

        self.task_id = str(task_config.get("id") or task_config.get("instruction_id") or f"{self.vibe_app_type}_task")
        self.instruction = str(
            task_config.get("instruction")
            or task_config.get("instruction_text")
            or self._vibe_task_meta.get("instruction")
            or ""
        )
        config = task_config.get("config")
        self.config = list(config) if isinstance(config, list) else []

    def close(self):
        """关闭环境"""
        if self.provider_name == "vibe" and self.vibe_provider:
            self.vibe_provider.close()
        else:
            super().close()

    def get_vibe_state(self) -> Optional[Dict]:
        """获取 Vibe 内部状态 - 用于调试"""
        if self.vibe_provider:
            return self.vibe_provider.get_state()
        return None


class VibeScreenshotController:
    """Vibe 截图控制器

    模拟原有 controller 的截图接口，实际通过外部系统或 Tauri 获取截图。
    """

    def __init__(self, provider: VibeTauriProvider, timeout: float = 2.0):
        self.provider = provider
        self.timeout = timeout
        self._last_screenshot = None

    def get_screenshot(self) -> Optional[bytes]:
        """获取截图

        实际实现可以通过以下方式:
        1. 调用 Tauri 的截图 API
        2. 调用外部截图服务（main.py）
        3. 返回模拟数据（用于测试）

        Returns:
            PNG 图像字节，或 None
        """
        screenshot = self._get_screenshot_from_external()
        if screenshot:
            self._last_screenshot = screenshot
            return screenshot
        if self._last_screenshot:
            return self._last_screenshot
        return self._fallback_screenshot()

    def _get_screenshot_from_external(self) -> Optional[bytes]:
        """从外部服务获取截图（如 main.py）"""
        try:
            import requests

            # 获取窗口信息
            info = self.provider._current_window_info
            if not info:
                return None

            window_pos = info.get("window_position", (0, 0))
            window_size = info.get("window_size", (1200, 800))

            # 调用 main.py 的截图服务
            response = requests.post(
                "http://localhost:5000/capture_screen",  # main.py 默认端口
                json={
                    "region": [
                        window_pos[0],
                        window_pos[1],
                        window_size[0],
                        window_size[1],
                    ]
                },
                timeout=self.timeout,
            )

            if response.status_code == 200:
                return response.content

        except Exception as e:
            logger.warning(f"Screenshot error: {e}")

        return None

    def _fallback_screenshot(self) -> bytes:
        """返回最小的占位 PNG 字节，保证训练环节可继续执行。"""
        return base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8"
            "/5/hPQAFhQJ/pbL1XwAAAABJRU5ErkJggg=="
        )

    def get_vm_platform(self) -> str:
        """获取平台信息"""
        return "vibe"

    def get_vm_screen_size(self) -> Tuple[int, int]:
        """获取屏幕尺寸"""
        if self.provider._current_window_info:
            size = self.provider._current_window_info.get("window_size", (1200, 800))
            return size
        return (1920, 1080)

    def get_accessibility_tree(self) -> Optional[Dict]:
        """获取无障碍树（Vibe 模式不支持）"""
        return None

    def get_terminal_output(self) -> Optional[str]:
        """获取终端输出（Vibe 模式不支持）"""
        return None


# ==================== 使用示例 ====================


def example_training_loop():
    """训练循环示例"""

    # 方式 1: 使用 VibeDesktopEnv（推荐）
    from vibe.integration.vibe_desktop_env import VibeDesktopEnv

    env = VibeDesktopEnv(
        provider_name="vibe",
        vibe_base_url="http://localhost:8765",
        vibe_app_type="wechat",
    )

    # 方式 2: 直接使用 Provider（轻量）
    # from vibe.integration.vibe_env_provider import VibeTauriProvider
    # provider = VibeTauriProvider()

    # 训练循环
    task_config = {
        "id": "wechat_open_conversation",
        "instruction": "打开与李静的聊天会话并发送'Hello'消息",
        "config": {"target_conversation": "李静", "target_message": "Hello"},
    }

    observation = env.reset(task_config=task_config, seed=42)
    print(f"Initial window position: {env.vibe_window_info.get('window_position')}")

    actions = [
        {"action_type": "mouse", "move_type": "click", "coordinate": [0.15, 0.15]},
        {"action_type": "keyboard", "key_type": "type", "text": "Hello"},
        {"action_type": "keyboard", "key_type": "press", "key": "Return"},
    ]

    total_reward = 0
    for i, action in enumerate(actions):
        observation, reward, done, truncated, info = env.step(action)
        total_reward += reward

        print(f"Step {i + 1}: reward={reward:.2f}, done={done}")

        if done or truncated:
            print(f"Episode finished! Total reward: {total_reward:.2f}")
            break

    env.close()


if __name__ == "__main__":
    example_training_loop()

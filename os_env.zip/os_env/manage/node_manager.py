#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
import tempfile
import traceback
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional
import time

import yaml
import logging
import ansible_runner
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from hydra import initialize_config_dir, compose, main as hydra_main
from hydra.core.global_hydra import GlobalHydra
from omegaconf import OmegaConf, DictConfig
from utils.io import read_yaml as _read_yaml, deep_merge_dict as _deep_merge, sync_ansible_from_config, load_all_config
from utils.config_schema import RootConfig
from desktop_env.config.loader import get_conf



def _detect_root() -> Path:
    here = Path(__file__).resolve().parent
    if (here / 'ansible').exists():
        return here
    parent = here.parent
    if (parent / 'ansible').exists():
        return parent
    cur = here
    for _ in range(3):
        cur = cur.parent
        if (cur / 'ansible').exists():
            return cur
    return here

ROOT = _detect_root()
ANSIBLE_DIR = ROOT / 'ansible'
INV = ANSIBLE_DIR / 'inventory.yaml'
PLAY_CAPACITY = ANSIBLE_DIR / 'playbooks' / 'capacity_plan.yaml'
PLAY_DIST = ANSIBLE_DIR / 'playbooks' / 'distribute_code.yaml'
PLAY_RUN_WORKER = ANSIBLE_DIR / 'playbooks' / 'run_worker.yaml'
PLAY_CLEANUP = ANSIBLE_DIR / 'playbooks' / 'cleanup_nodes.yaml'
ARTIFACTS_DIR = ANSIBLE_DIR / 'artifacts'


def _worker_provider(cfg: Optional[Dict[str, Any]] = None) -> str:
    payload = cfg if isinstance(cfg, dict) else {}
    vm_manager = payload.get("vm_manager") if isinstance(payload.get("vm_manager"), dict) else {}
    value = (
        vm_manager.get("provider")
        or os.environ.get("OS_ENV_WORKER_PROVIDER")
        or "libvirt"
    )
    return str(value).strip().lower() or "libvirt"


def _ensure_node_manager_logging() -> None:
    log_file = (ROOT / 'logs' / 'node_manager.log').resolve()
    try:
        log_file.parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logging.error(f"create logs dir failed: {e}")
        return

    root = logging.getLogger()
    if root.level > logging.INFO:
        root.setLevel(logging.INFO)

    formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
    has_file = False
    has_stream = False
    for handler in root.handlers:
        if isinstance(handler, logging.FileHandler):
            try:
                if Path(handler.baseFilename).resolve() == log_file:
                    has_file = True
            except Exception:
                logging.exception("Failed to inspect existing node_manager file handler: %s", handler)
        elif isinstance(handler, logging.StreamHandler):
            has_stream = True

    if not has_file:
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setFormatter(formatter)
        root.addHandler(file_handler)
    if not has_stream:
        stream_handler = logging.StreamHandler(sys.stdout)
        stream_handler.setFormatter(formatter)
        root.addHandler(stream_handler)


def load_yaml(path: Path) -> Dict[str, Any]:
    return _read_yaml(path)


def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    return _deep_merge(base, override)


def run_playbook(playbook: Path, extra_vars: dict = None, cmdline: str = None) -> ansible_runner.Runner:
    logging.info(f"Running playbook: {playbook.name}")
    envvars = {
        # Isolate ansible from user-site Jinja2 packages that may be incompatible
        # with system ansible plugins.
        "PYTHONNOUSERSITE": "1",
    }
    r = ansible_runner.run(
        private_data_dir=str(ANSIBLE_DIR),
        project_dir=str(ANSIBLE_DIR),
        playbook=str(playbook.relative_to(ANSIBLE_DIR)),
        inventory=str(INV),
        extravars=extra_vars or {},
        cmdline=cmdline or None,
        envvars=envvars,
    )
    if r.rc not in (0, None):
        logging.error(f"Playbook {playbook.name} failed: status={getattr(r,'status',None)} rc={r.rc}")
        print(f"Playbook {playbook.name} failed: status={r.status} rc={r.rc}", file=sys.stderr)
        sys.exit(r.rc or 1)
    logging.info(f"Playbook {playbook.name} finished successfully")
    return r


def cleanup_cluster_nodes(prefer_hosts: Optional[List[str]] = None) -> Dict[str, Any]:
    _ensure_node_manager_logging()

    all_cfg = load_all_config()
    if not isinstance(all_cfg, dict):
        all_cfg = {}
    try:
        sync_ansible_from_config(ANSIBLE_DIR, all_cfg)
    except Exception as e:
        logging.warning(f"sync ansible config before cleanup failed: {e}")

    inv = load_yaml(INV)
    inv_hosts = list((inv.get('all', {}).get('hosts') or {}).keys())

    vm_nodes = ((all_cfg.get('vm_manager') or {}).get('nodes') or {})
    active_hosts: List[str] = []
    if isinstance(vm_nodes, dict) and vm_nodes:
        for host, count in vm_nodes.items():
            try:
                if int(count) > 0:
                    active_hosts.append(str(host))
            except Exception:
                logging.exception("Invalid vm_manager.nodes value host=%s count=%r", host, count)
                continue
    if not active_hosts:
        active_hosts = inv_hosts

    if prefer_hosts:
        allowed = set(prefer_hosts)
        active_hosts = [h for h in active_hosts if h in allowed]

    if not active_hosts:
        return {"requested_hosts": [], "cleaned_hosts": [], "skipped": True}

    cmdline = f"-l {','.join(active_hosts)}"
    try:
        run_playbook(PLAY_CLEANUP, extra_vars={}, cmdline=cmdline)
    except SystemExit as e:
        raise RuntimeError(f"cleanup playbook failed: {e}") from e
    return {"requested_hosts": active_hosts, "cleaned_hosts": active_hosts, "skipped": False}


def parse_capacity_results(artifact_dir: Path) -> Dict[str, int]:
    """Parse capacity from ansible-runner artifacts.

    Supports both NDJSON file (job_events.json) and per-event files in job_events/.
    """
    result: Dict[str, int] = {}
    # Prefer directory of per-event JSON files
    events_dir = artifact_dir / 'job_events'
    if events_dir.exists() and events_dir.is_dir():
        try:
            for ev_file in sorted(events_dir.glob('*.json')):
                try:
                    with open(ev_file, 'r', encoding='utf-8') as f:
                        ev = json.load(f)
                except Exception as e:
                    logging.error(f"parse_capacity_results read event file failed {ev_file}: {e}")
                    continue
                ed = ev.get('event_data') or {}
                res = ed.get('res') or {}
                msg = res.get('msg') or ''
                if isinstance(msg, str):
                    m = re.search(r"Node\s+(\S+)\s+can host up to\s+(\d+)\s+VMs", msg)
                    if m:
                        host = m.group(1)
                        count = int(m.group(2))
                        result[host] = count
        except Exception as e:
            logging.error(f"Error parsing capacity results (dir): {e}")
        return result

    job_events = artifact_dir / 'job_events.json'
    if not job_events.exists():
        artifacts_root = ANSIBLE_DIR / 'artifacts'
        latest = None
        for p in artifacts_root.glob('*/job_events.json'):
            if latest is None or p.stat().st_mtime > latest.stat().st_mtime:
                latest = p
        job_events = latest if latest else job_events
        if not job_events or not job_events.exists():
            return result
    try:
        with open(job_events, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                except Exception as e:
                    logging.error(f"parse_capacity_results load ndjson line failed: {e}")
                    continue
                ed = ev.get('event_data') or {}
                res = ed.get('res') or {}
                msg = res.get('msg') or ''
                if isinstance(msg, str):
                    m = re.search(r"Node\s+(\S+)\s+can host up to\s+(\d+)\s+VMs", msg)
                    if m:
                        host = m.group(1)
                        count = int(m.group(2))
                        result[host] = count
    except Exception as e:
        logging.error(f"Error parsing capacity results (ndjson): {e}")
    return result


def parse_worker_results(artifact_dir: Path) -> Dict[str, Any]:
    by_host: Dict[str, Any] = {}
    endpoints: List[Dict[str, Any]] = []

    events_dir = artifact_dir / 'job_events'
    def _extract_json(s: Any) -> Optional[Dict[str, Any]]:
        if isinstance(s, dict):
            return s
        if not isinstance(s, str):
            return None
        i = s.find('{')
        if i < 0:
            return None
        try:
            return json.loads(s[i:])
        except Exception as e:
            logging.error(f"_extract_json failed: {e}")
            return None
    if events_dir.exists() and events_dir.is_dir():
        try:
            for ev_file in sorted(events_dir.glob('*.json')):
                try:
                    with open(ev_file, 'r', encoding='utf-8') as f:
                        ev = json.load(f)
                except Exception as e:
                    logging.error(f"parse_worker_results read event file failed {ev_file}: {e}")
                    continue
                ed = ev.get('event_data') or {}
                res = ed.get('res') or {}
                msg = res.get('msg')
                host_alias = ed.get('host') or ed.get('inventory_hostname')
                data = _extract_json(msg)
                if not data:
                    continue
                if not isinstance(data, dict) or 'workers' not in data:
                    continue
                by_host[host_alias or 'unknown'] = data
                for w in (data.get('workers') or []):
                    if not isinstance(w, dict):
                        continue
                    ep = {
                        'worker_host': w.get('worker_host') or data.get('node_ip') or host_alias,
                        'worker_port': w.get('worker_port'),
                        'env_id': w.get('env_id'),
                        'vm_name': w.get('vm_name'),
                        'ip': w.get('ip'),
                        'http_endpoint': w.get('http_endpoint'),
                        'vnc_port': w.get('vnc_port'),
                        'error': w.get('error'),
                    }
                    endpoints.append(ep)
        except Exception as e:
            logging.error(f"Error parsing worker results (dir): {e}")
        return {"by_host": by_host, "endpoints": endpoints}

    job_events = artifact_dir / 'job_events.json'
    if not job_events.exists():
        artifacts_root = ANSIBLE_DIR / 'artifacts'
        latest = None
        for p in artifacts_root.glob('*/job_events.json'):
            if latest is None or p.stat().st_mtime > latest.stat().st_mtime:
                latest = p
        job_events = latest if latest else job_events
        if not job_events or not job_events.exists():
            return {"by_host": {}, "endpoints": []}

    try:
        with open(job_events, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                except Exception as e:
                    logging.error(f"parse_worker_results load ndjson line failed: {e}")
                    continue
                ed = ev.get('event_data') or {}
                res = ed.get('res') or {}
                msg = res.get('msg')
                host_alias = ed.get('host') or ed.get('inventory_hostname')
                data = _extract_json(msg)
                if not data:
                    continue
                if not isinstance(data, dict) or 'workers' not in data:
                    continue
                by_host[host_alias or 'unknown'] = data
                for w in (data.get('workers') or []):
                    if not isinstance(w, dict):
                        continue
                    ep = {
                        'worker_host': w.get('worker_host') or data.get('node_ip') or host_alias,
                        'worker_port': w.get('worker_port'),
                        'env_id': w.get('env_id'),
                        'vm_name': w.get('vm_name'),
                        'ip': w.get('ip'),
                        'http_endpoint': w.get('http_endpoint'),
                        'vnc_port': w.get('vnc_port'),
                        'error': w.get('error'),
                    }
                    endpoints.append(ep)
    except Exception as e:
        logging.error(f"Error parsing worker results (ndjson): {e}")
    return {"by_host": by_host, "endpoints": endpoints}


def get_controller_state_dir() -> Path:
    try:
        p = os.environ.get('CONTROLLER_STATE_DIR')
        if not p:
            p = get_conf('paths', 'controller_state_dir')
        if p:
            d = Path(p)
            d.mkdir(parents=True, exist_ok=True)
            return d
    except Exception as e:
        logging.error(f"Error loading controller_state_dir: {e}")
    d = ROOT / 'state'
    d.mkdir(parents=True, exist_ok=True)
    return d


def pool_path() -> Path:
    sd = get_controller_state_dir()
    sd.mkdir(parents=True, exist_ok=True)
    return sd / 'workers_pool.json'


def load_pool() -> Dict[str, Any]:
    p = pool_path()
    if not p.exists():
        return {"workers": []}
    try:
        with open(p, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, dict) and 'workers' in data:
                return data
    except Exception as e:
        logging.error(f"Error loading workers pool: {e}")
    return {"workers": []}


def save_pool(pool: Dict[str, Any]) -> None:
    p = pool_path()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        prev_mode = None
        try:
            prev_mode = p.stat().st_mode
        except Exception:
            logging.exception("Failed to stat workers pool file for mode copy: %s", p)
            prev_mode = None
        fd, tmp = tempfile.mkstemp(prefix=p.name + ".tmp.", dir=str(p.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(pool, f, ensure_ascii=False, indent=2)
                f.flush()
            if prev_mode is not None:
                try:
                    os.chmod(tmp, prev_mode)
                except Exception:
                    logging.exception("Failed to chmod temp workers pool file: %s", tmp)
            os.replace(tmp, p)
        finally:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                logging.exception("Failed to cleanup temp workers pool file: %s", tmp)
    except Exception as e:
        logging.error(f"Error saving workers pool: {e}")


def _endpoint_key(w: Dict[str, Any]) -> str:
    host = w.get('worker_host') or ''
    port = w.get('worker_port') or ''
    return f"{host}:{port}"

def _normalize_port(v: Any) -> Optional[int]:
    if v is None:
        return None
    try:
        p = int(v)
    except Exception:
        logging.exception("Invalid worker port value: %r", v)
        return None
    return p if p > 0 else None


def update_pool_with_endpoints(endpoints: List[Dict[str, Any]]) -> Dict[str, Any]:
    pool = load_pool()
    existing = { _endpoint_key(w): w for w in pool.get('workers') or [] }
    for ep in endpoints:
        host = ep.get("worker_host")
        port = _normalize_port(ep.get("worker_port"))
        if not host or port is None:
            logging.warning(f"Skipping invalid worker endpoint (missing host/port): {ep}")
            continue
        if ep.get("error"):
            logging.warning(f"Skipping worker endpoint with error: {ep}")
            continue
        ep = dict(ep)
        ep["worker_port"] = port
        k = _endpoint_key(ep)
        rec = existing.get(k)
        if rec:
            for key in ['env_id','vm_name','ip','http_endpoint','vnc_port']:
                if ep.get(key) is not None:
                    rec[key] = ep[key]
            existing[k] = rec
        else:
            ep2 = dict(ep)
            ep2['status'] = 'available'
            ep2['allocated_at'] = None
            ep2['allocated_by'] = None
            existing[k] = ep2
    pool['workers'] = list(existing.values())
    save_pool(pool)
    return pool


def unavailable_pool_path() -> Path:
    sd = get_controller_state_dir()
    sd.mkdir(parents=True, exist_ok=True)
    return sd / 'unavailable_workers.json'


def load_unavailable_pool() -> Dict[str, Any]:
    p = unavailable_pool_path()
    if not p.exists():
        return {"workers": []}
    try:
        with open(p, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, dict) and 'workers' in data:
                return data
    except Exception as e:
        logging.error(f"Error loading unavailable pool: {e}")
    return {"workers": []}


def save_unavailable_pool(pool: Dict[str, Any]) -> None:
    p = unavailable_pool_path()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        prev_mode = None
        try:
            prev_mode = p.stat().st_mode
        except Exception:
            logging.exception("Failed to stat unavailable pool file for mode copy: %s", p)
            prev_mode = None
        fd, tmp = tempfile.mkstemp(prefix=p.name + ".tmp.", dir=str(p.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(pool, f, ensure_ascii=False, indent=2)
                f.flush()
            if prev_mode is not None:
                try:
                    os.chmod(tmp, prev_mode)
                except Exception:
                    logging.exception("Failed to chmod temp unavailable pool file: %s", tmp)
            os.replace(tmp, p)
        finally:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                logging.exception("Failed to cleanup temp unavailable pool file: %s", tmp)
    except Exception as e:
        logging.error(f"Error saving unavailable pool: {e}")


def move_worker_to_unavailable(worker: Dict[str, Any], reason: Optional[str] = None) -> None:
    pool = load_pool()
    workers = pool.get('workers') or []
    key = _endpoint_key(worker)
    updated = False
    for w in workers:
        if _endpoint_key(w) == key:
            w['status'] = 'unavailable'
            w['reason'] = reason or 'unknown'
            w['moved_at'] = int(time.time())
            w['allocated_at'] = None
            w['allocated_by'] = None
            w['session_id'] = None
            updated = True
            break
    if not updated:
        rec = dict(worker)
        rec['status'] = 'unavailable'
        rec['reason'] = reason or 'unknown'
        rec['moved_at'] = int(time.time())
        rec['allocated_at'] = None
        rec['allocated_by'] = None
        rec['session_id'] = None
        workers.append(rec)
        pool['workers'] = workers
    save_pool(pool)


def clear_pools() -> None:
    save_pool({"workers": []})
    save_unavailable_pool({"workers": []})


def _build_headers() -> Dict[str, str]:
    headers: Dict[str, str] = {}
    token = os.environ.get("ENV_WORKER_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _endpoint_url(worker: Dict[str, Any], path: str) -> Optional[str]:
    host = worker.get('worker_host')
    port = worker.get('worker_port')
    if not host or not port:
        return None
    return f"http://{host}:{int(port)}{path}"


def _probe_alive(worker: Dict[str, Any], headers: Dict[str, str], timeout: float = 3.0) -> bool:
    """Return True if worker responds to /health or /info, else False."""
    for path in ("/health", "/info"):
        url = _endpoint_url(worker, path)
        if not url:
            return False
        try:
            r = requests.get(url, headers=headers, timeout=timeout)
            if r.status_code == 200:
                return True
        except Exception as e:
            logging.debug(f"probe_alive request failed ({url}): {e}")
    return False


def _call_close(worker: Dict[str, Any], headers: Dict[str, str], timeout: float = 5.0, verify_close: bool = True) -> Dict[str, Any]:
    """Call DELETE /close on a worker endpoint and optionally verify shutdown."""
    url = _endpoint_url(worker, "/close")
    close_exc: Optional[Exception] = None
    close_tb: Optional[str] = None
    result = {
        "endpoint": _endpoint_key(worker),
        "worker_host": worker.get('worker_host'),
        "worker_port": worker.get('worker_port'),
        "ok": False,
        "status_code": None,
        "error": None,
        "verified_closed": False,
    }
    if not url:
        result["error"] = "invalid endpoint"
        return result
    try:
        r = requests.delete(url, headers=headers, timeout=timeout)
        result["status_code"] = r.status_code
        if r.status_code == 200:
            result["ok"] = True
        else:
            result["error"] = f"HTTP {r.status_code}"
    except Exception as e:
        close_exc = e
        close_tb = traceback.format_exc()
        result["error"] = str(e)

    # Optional verification: wait briefly and check service is down
    if verify_close:
        deadline = time.time() + max(timeout, 2.0)
        # give the worker a moment to exit
        time.sleep(0.7)
        while time.time() < deadline:
            alive = _probe_alive(worker, headers=headers, timeout=1.5)
            if not alive:
                result["verified_closed"] = True
                break
            time.sleep(0.5)
        # If DELETE failed but service is down, still consider verified_closed
        if not result["ok"] and result["verified_closed"]:
            result["ok"] = True
            if result["error"]:
                result["error"] = f"{result['error']} (but closed)"
    if close_exc is not None:
        endpoint = _endpoint_key(worker)
        if result["ok"]:
            logging.info(
                "Call close request failed endpoint=%s err=%s (verified closed)",
                endpoint,
                close_exc,
            )
        else:
            logging.error("Call close failed endpoint=%s err=%s", endpoint, close_exc)
            if close_tb:
                logging.debug("Call close traceback endpoint=%s\n%s", endpoint, close_tb)
    return result


def shutdown_workers(prefer_host: Optional[str] = None,
                     status_filter: str = "allocated",
                     concurrency: int = 16,
                     timeout: float = 5.0,
                     verify_close: bool = True,
                     remove_from_pool: bool = True) -> Dict[str, Any]:

    pool = load_pool()
    workers = pool.get('workers') or []
    targets = []
    for w in workers:
        if status_filter and w.get('status') != status_filter:
            continue
        if prefer_host and w.get('worker_host') != prefer_host:
            continue
        targets.append(w)

    headers = _build_headers()
    results: List[Dict[str, Any]] = []
    closed_keys: set = set()

    if not targets:
        return {
            "requested": 0,
            "attempted": 0,
            "closed": 0,
            "failed": 0,
            "details": [],
            "pool_updated": False,
        }

    with ThreadPoolExecutor(max_workers=max(1, int(concurrency))) as ex:
        fut_map = {ex.submit(_call_close, w, headers, timeout, verify_close): w for w in targets}
        for fut in as_completed(fut_map):
            w = fut_map[fut]
            try:
                res = fut.result()
            except Exception as e:
                logging.exception("shutdown_workers future failed endpoint=%s", _endpoint_key(w))
                res = {
                    "endpoint": _endpoint_key(w),
                    "worker_host": w.get('worker_host'),
                    "worker_port": w.get('worker_port'),
                    "ok": False,
                    "status_code": None,
                    "error": str(e),
                    "verified_closed": False,
                }
            results.append(res)
            if res.get("ok") and res.get("verified_closed"):
                closed_keys.add(_endpoint_key(w))

    # Optionally prune closed endpoints from pool
    pool_updated = False
    if remove_from_pool and closed_keys:
        new_workers = [w for w in workers if _endpoint_key(w) not in closed_keys]
        pool['workers'] = new_workers
        save_pool(pool)
        pool_updated = True

    summary = {
        "requested": len(targets),
        "attempted": len(results),
        "closed": sum(1 for r in results if r.get("ok")),
        "failed": sum(1 for r in results if not r.get("ok")),
        "details": results,
        "pool_updated": pool_updated,
    }
    return summary


def destroy_workers(prefer_host: Optional[str] = None,
                    status_filter: str = "available",
                    concurrency: int = 8,
                    timeout: float = 5.0,
                    remove_from_pool: bool = True) -> Dict[str, Any]:
    pool = load_pool()
    workers = pool.get('workers') or []
    targets = []
    for w in workers:
        if status_filter and w.get('status') != status_filter:
            continue
        if prefer_host and w.get('worker_host') != prefer_host:
            continue
        targets.append(w)

    headers = _build_headers()
    results: List[Dict[str, Any]] = []
    destroyed_keys: set = set()
    if not targets:
        if remove_from_pool and (not status_filter) and prefer_host is None:
            clear_pools()
            return {
                "requested": 0,
                "attempted": 0,
                "destroyed": 0,
                "failed": 0,
                "details": [],
                "pool_updated": True,
            }
        return {
            "requested": 0,
            "attempted": 0,
            "destroyed": 0,
            "failed": 0,
            "details": [],
            "pool_updated": False,
        }

    def _close_and_destroy(w: Dict[str, Any]) -> Dict[str, Any]:
        r1 = _call_close(w, headers, timeout=timeout, verify_close=True)
        destroyed = bool(r1.get("ok") and r1.get("verified_closed"))
        res = {
            "endpoint": _endpoint_key(w),
            "worker_host": w.get('worker_host'),
            "worker_port": w.get('worker_port'),
            "vm_name": w.get('vm_name'),
            "closed": bool(r1.get('ok')),
            "verified_closed": bool(r1.get("verified_closed")),
            "destroyed": destroyed,
            "error": r1.get('error'),
        }
        return res

    with ThreadPoolExecutor(max_workers=max(1, int(concurrency))) as ex:
        fut_map = {ex.submit(_close_and_destroy, w): w for w in targets}
        for fut in as_completed(fut_map):
            w = fut_map[fut]
            try:
                res = fut.result()
            except Exception as e:
                logging.exception("destroy_workers future failed endpoint=%s", _endpoint_key(w))
                res = {
                    "endpoint": _endpoint_key(w),
                    "worker_host": w.get('worker_host'),
                    "worker_port": w.get('worker_port'),
                    "vm_name": w.get('vm_name'),
                    "closed": False,
                    "destroyed": False,
                    "error": str(e),
                }
            results.append(res)
            if res.get("destroyed"):
                destroyed_keys.add(_endpoint_key(w))

    destroyed_count = sum(1 for r in results if r.get("destroyed"))
    failed_count = len(results) - destroyed_count
    full_cleanup_mode = bool(remove_from_pool and (not status_filter) and prefer_host is None)

    pool_updated = False
    if remove_from_pool:
        if full_cleanup_mode and failed_count == 0:
            clear_pools()
            pool_updated = True
        elif destroyed_keys:
            failed_map = {
                str(r.get("endpoint") or ""): str(r.get("error") or "close_failed")
                for r in results
                if not r.get("destroyed")
            }
            new_workers = []
            for w in workers:
                key = _endpoint_key(w)
                if key in destroyed_keys:
                    continue
                w2 = dict(w)
                if key in failed_map:
                    w2['status'] = 'unavailable'
                    w2['reason'] = f"shutdown_failed:{failed_map[key]}"
                    w2['moved_at'] = int(time.time())
                    w2['allocated_at'] = None
                    w2['allocated_by'] = None
                    w2['session_id'] = None
                new_workers.append(w2)
            pool['workers'] = new_workers
            save_pool(pool)
            pool_updated = True

    return {
        "requested": len(targets),
        "attempted": len(results),
        "destroyed": destroyed_count,
        "failed": failed_count,
        "details": results,
        "pool_updated": pool_updated,
    }

def allocate_one_from_pool(prefer_host: Optional[str] = None) -> Optional[Dict[str, Any]]:
    pool = load_pool()
    workers = pool.get('workers') or []
    updated = False
    for w in workers:
        if w.get('status') != 'available':
            continue
        if prefer_host and w.get('worker_host') != prefer_host:
            continue
        host = w.get("worker_host")
        port = _normalize_port(w.get("worker_port"))
        if not host or port is None:
            w['status'] = 'unavailable'
            w['reason'] = 'invalid_endpoint'
            w['moved_at'] = int(time.time())
            w['allocated_at'] = None
            w['allocated_by'] = None
            w['session_id'] = None
            updated = True
            continue

        w['worker_port'] = port
        w['status'] = 'allocated'
        w['allocated_at'] = int(time.time())
        w['allocated_by'] = os.environ.get('USER') or 'unknown'
        save_pool(pool)
        return w

    if updated:
        save_pool(pool)
    return None

def provision_with_config(config_path: str) -> Dict[str, Any]:
    _ensure_node_manager_logging()

    cfg_path = Path(config_path)
    if GlobalHydra.instance().is_initialized():
        with open(cfg_path, "r", encoding="utf-8") as f:
            raw_cfg = yaml.safe_load(f) or {}
        if not isinstance(raw_cfg, dict):
            raise ValueError(f"Invalid config content in {cfg_path}")
        cfg = raw_cfg
    else:
        cfg_dir = str(cfg_path.parent.resolve())
        cfg_name = cfg_path.stem
        with initialize_config_dir(config_dir=cfg_dir):
            cfg_obj = compose(config_name=cfg_name)
        cfg = OmegaConf.to_container(cfg_obj, resolve=True)

    nodes_spec: Dict[str, int] = (cfg.get('nodes') or {})
    if not nodes_spec:
        raise ValueError("Config must specify 'nodes' mapping: {host: vm_count, ...}")

    active_hosts = [h for h, n in nodes_spec.items() if int(n) > 0]
    assignments = {h: int(nodes_spec[h]) for h in active_hosts}

    logging.info(f"VM assignments: {assignments}")

    sync_ansible_from_config(ANSIBLE_DIR, load_all_config())


    extra_dist = {'code_src': get_conf('paths', 'code_src')}
    dist_cmdline = f"-l {','.join(active_hosts)}" if active_hosts else None

    if active_hosts:
        run_playbook(PLAY_DIST, extra_vars=extra_dist, cmdline=dist_cmdline)
    else:
        logging.warning('No active hosts, skipping code distribution')

    tmpl = load_yaml(ANSIBLE_DIR / 'group_vars' / 'all.yaml')
    configs_by_host = build_configs_by_host(tmpl, ANSIBLE_DIR / 'host_vars', only_hosts=active_hosts)

    extra_run = {
        'assignments': assignments,
        'configs_by_host': configs_by_host,
        'worker_provider': _worker_provider(cfg),
    }
    worker_cmdline = f"-l {','.join(active_hosts)}" if active_hosts else None
    r2 = run_playbook(PLAY_RUN_WORKER, extra_vars=extra_run, cmdline=worker_cmdline)

    artifact_dir2 = Path(getattr(getattr(r2, 'config', None), 'artifact_dir', ARTIFACTS_DIR))
    worker_results = parse_worker_results(artifact_dir2)
    endpoints = worker_results.get('endpoints', [])
    pool = update_pool_with_endpoints(endpoints)

    return {
        'assignments': assignments,
        'endpoints': endpoints,
        'pool_size': len(pool.get('workers') or []),
        'by_host': worker_results.get('by_host', {}),
    }


def apportion(n: int, capacities: Dict[str, int]) -> Dict[str, int]:
    total_cap = sum(capacities.values())
    if total_cap <= 0:
        return {h: 0 for h in capacities}

    if total_cap <= n:
        return dict(capacities)

    quotas: Dict[str, int] = {}
    remainders: List[Tuple[str, float]] = []
    for host, cap in capacities.items():
        q = (n * cap) / total_cap
        quotas[host] = int(q)
        remainders.append((host, q - int(q)))
    remaining = n - sum(quotas.values())
    for host, _ in sorted(remainders, key=lambda x: x[1], reverse=True):
        if remaining <= 0:
            break
        quotas[host] += 1
        remaining -= 1
    return quotas


def build_configs_by_host(group_vars: Dict[str, Any], host_vars_dir: Path, only_hosts: Optional[List[str]] = None) -> Dict[str, Dict[str, Any]]:
    configs: Dict[str, Dict[str, Any]] = {}
    inv = load_yaml(INV)
    hosts = list((inv.get('all', {}).get('hosts') or {}).keys())
    if only_hosts:
        s = set(only_hosts)
        hosts = [h for h in hosts if h in s]
    for host in hosts:
        host_yaml = host_vars_dir / f"{host}.yaml"
        override = load_yaml(host_yaml)
        merged = deep_merge(group_vars, override)
        configs[host] = merged
    return configs


@hydra_main(version_base=None, config_path="..", config_name="all_config")
def main(cfg: DictConfig) -> None:
    _ensure_node_manager_logging()
    base = OmegaConf.structured(RootConfig)
    merged = OmegaConf.merge(base, cfg)
    root_cfg: RootConfig = OmegaConf.to_object(merged)
    all_cfg = OmegaConf.to_container(merged, resolve=True)
    nm_cfg = root_cfg.vm_manager
    ans_cfg = root_cfg.ansible or {}
    gv_cfg = ans_cfg.get('group_vars') or {}
    specified_total = int(nm_cfg.total)
    nodes_spec: Dict[str, int] = nm_cfg.nodes
    enforce_limits = bool(nm_cfg.options.enforce_limits)
    sync_ansible_from_config(ANSIBLE_DIR, all_cfg)
    active_hosts: List[str] = []
    if nodes_spec:
        try:
            active_hosts = [h for h, n in nodes_spec.items() if int(n) > 0]
        except Exception as e:
            logging.error(f"active_hosts parse failed: {e}")
            active_hosts = [h for h, n in nodes_spec.items() if (isinstance(n, int) and n > 0)]

    if specified_total is None or int(specified_total) <= 0:
        print('Error: 总数量必须通过命令行或 config.yaml 指定且 > 0', file=sys.stderr)
        logging.error('Missing or invalid total count')
        return

    # Only pass local code_src; let host_vars control per-host destinations
    extra_dist = {
        'code_src': get_conf('paths', 'code_src'),
    }
    logging.debug(f"extra_dist={extra_dist}")
    dist_cmdline = None
    if active_hosts:
        dist_cmdline = f"-l {','.join(active_hosts)}"
    if nodes_spec and not active_hosts:
        logging.warning('nodes 中所有节点数量均为 0，跳过代码分发与容量监测')
    else:
        run_playbook(PLAY_DIST, extra_vars=extra_dist, cmdline=dist_cmdline)

    vm_tmpl = gv_cfg.get('vm_template') or {}
    try:
        extra_cap = {
            'vm_vcpus': int(vm_tmpl['vcpus']),
            'vm_mem_mb': int(vm_tmpl['memory']),
            'vm_disk_gb': int(vm_tmpl['size']),
        }
    except Exception as e:
        logging.error(f"invalid vm_template config: {e}")
        print('Error: ansible.group_vars.vm_template 配置不正确', file=sys.stderr)
        return
    logging.info(f"capacity template: vcpus={extra_cap['vm_vcpus']} mem_mb={extra_cap['vm_mem_mb']} disk_gb={extra_cap['vm_disk_gb']}")
    cap_cmdline = dist_cmdline
    if nodes_spec and not active_hosts:
        r = None
    else:
        r = run_playbook(PLAY_CAPACITY, extra_vars=extra_cap, cmdline=cap_cmdline)
    artifact_dir = Path(r.config.artifact_dir) if hasattr(r, 'config') and hasattr(r.config, 'artifact_dir') else ANSIBLE_DIR / 'artifacts'
    logging.debug(f"artifact_dir={artifact_dir}")
    capacities = parse_capacity_results(artifact_dir) if r else {}
    if not capacities:
        print('Warning: capacity results not parsed; defaulting to zero for all hosts.', file=sys.stderr)
        logging.warning('Capacity results not parsed; defaulting to zero for all hosts.')
        capacities = {}
        if nodes_spec:
            for host in active_hosts:
                capacities[host] = 0
        else:
            inv = load_yaml(INV)
            for host in (inv.get('all', {}).get('hosts') or {}).keys():
                capacities[host] = 0
    else:
        if nodes_spec:
            for host in (nodes_spec or {}).keys():
                if host not in capacities:
                    capacities[host] = 0

    if nodes_spec:
        assignments = {}
        for host, req in nodes_spec.items():
            req_int = int(req)
            cap = int(capacities.get(host, 0))
            if enforce_limits and req_int > cap:
                print(f"Error: 节点 {host} 请求数量 {req_int} 超过容量 {cap}", file=sys.stderr)
                logging.error(f"requested {host} {req_int} > capacity {cap}")
                sys.exit(1)
            assignments[host] = min(req_int, cap) if enforce_limits else req_int
        total_assigned = sum(assignments.values())
        if total_assigned != int(specified_total):
            logging.warning(f"配置总数 {specified_total} 与按节点合计 {total_assigned} 不一致，按节点合计为准")
    else:
        assignments = apportion(int(specified_total), capacities)
        total_assigned = sum(assignments.values())
    total_assigned = sum(assignments.values())
    summary = {
        'requested': int(specified_total),
        'total_capacity': sum(capacities.values()),
        'capacities': capacities,
        'assignments': assignments,
    }
    logging.info(f"capacity summary: {summary}")
    print(json.dumps(summary, ensure_ascii=False, indent=2))

    if total_assigned == 0:
        print('No capacity available across nodes. Exiting.')
        logging.error('No capacity available across nodes. Exiting.')
        return

    worker_hosts = [h for h, n in (assignments or {}).items() if int(n) > 0]
    group_vars = gv_cfg
    configs_by_host = build_configs_by_host(group_vars, ANSIBLE_DIR / 'host_vars', only_hosts=worker_hosts)
    logging.debug(f"configs_by_host keys: {list(configs_by_host.keys())}")

    extra_run = {
        'assignments': assignments,
        'configs_by_host': configs_by_host,
        'worker_provider': _worker_provider(all_cfg),
    }
    logging.info('Dispatching run_worker to hosts')
    worker_cmdline = f"-l {','.join(worker_hosts)}" if worker_hosts else None
    r2 = run_playbook(PLAY_RUN_WORKER, extra_vars=extra_run, cmdline=worker_cmdline)
    artifact_dir2 = Path(r2.config.artifact_dir) if hasattr(r2, 'config') and hasattr(r2.config, 'artifact_dir') else ANSIBLE_DIR / 'artifacts'
    worker_results = parse_worker_results(artifact_dir2)
    endpoints = worker_results.get('endpoints', [])
    pool = update_pool_with_endpoints(endpoints)
    aggregated = {
        'vm_manager_summary': summary,
        'workers': endpoints,
        'by_host': worker_results.get('by_host', {}),
        'pool_file': str(pool_path()),
        'pool_size': len(pool.get('workers') or [])
    }
    logging.info(f"aggregated endpoints count={len(aggregated['workers'])} pool_size={aggregated['pool_size']}")
    print(json.dumps(aggregated, ensure_ascii=False, indent=2))
    logging.info('node_manager finished')


if __name__ == '__main__':
    main()

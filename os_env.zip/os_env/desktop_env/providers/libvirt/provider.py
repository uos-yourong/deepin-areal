import logging
import os
import shlex
import subprocess
import time
import json
import xml.etree.ElementTree as ET
from desktop_env.providers.base import Provider
from desktop_env.config.loader import get_conf, get_vm_specs
logger = logging.getLogger("desktopenv.providers.libvirt.LibvirtProvider")
logger.setLevel(logging.INFO)
WAIT_TIME = 3
VNC_PUBLIC_HOST = get_conf('provider', 'vnc_public_host')
class LibvirtProvider(Provider):
    """Libvirt provider for managing virtual machines using libvirt/KVM."""
    
    def __init__(self, region=None, client_password="password"):
        """Initialize the LibvirtProvider."""
        self.region = region
        cfg_pwd = get_conf('libvirt', 'sudo_password')
        self.client_password = cfg_pwd if cfg_pwd else client_password
        # Unified specs for potential use in provider operations
        self.specs = get_vm_specs()
    
    def _execute_command(self, command: list, timeout: int = 60, return_output: bool = True):
        """Execute a command and return the output."""
        try:
            # Check if command starts with sudo and modify it to use password
            if command and command[0] == "sudo":
                # Convert ["sudo", "virsh", ...] to "echo password | sudo -S virsh ..."
                sudo_command = shlex.join(command[1:])  # Remove "sudo" and join the rest safely
                full_command = f"echo '{self.client_password}' | sudo -S {sudo_command}"
                
                result = subprocess.run(
                    full_command,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=timeout,
                    text=True,
                    encoding="utf-8"
                )
            else:
                result = subprocess.run(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=timeout,
                    text=True,
                    encoding="utf-8"
                )
            
            if result.returncode != 0:
                # Filter out sudo password prompt from stderr
                stderr = result.stderr
                if '[sudo] password for' in stderr:
                    stderr_lines = stderr.split('\n')
                    stderr = '\n'.join([line for line in stderr_lines if '[sudo] password for' not in line])
                
                if stderr.strip():  # Only raise if there's actual error content
                    raise Exception(f"Command failed: {' '.join(command)}\nError: {stderr}")
            
            if return_output:
                return result.stdout.strip()
            return None
        except subprocess.TimeoutExpired:
            raise Exception(f"Command timed out: {' '.join(command)}")
    
    @staticmethod
    def _get_vm_name_from_path(path_to_vm: str) -> str:
        """Extract VM name from path. For libvirt, path_to_vm is the VM name."""
        return path_to_vm
    
    def _vm_exists(self, vm_name: str) -> bool:
        """Check if a VM exists in libvirt."""
        try:
            self._execute_command(["sudo", "virsh", "dominfo", vm_name])
            return True
        except Exception as e:
            logger.error(f"_vm_exists check failed: {e}")
            return False
    
    def _vm_is_running(self, vm_name: str) -> bool:
        """Check if a VM is currently running."""
        try:
            output = self._execute_command(["sudo", "virsh", "domstate", vm_name])
            return "running" in output.lower()
        except Exception as e:
            logger.error(f"_vm_is_running check failed: {e}")
            return False
    
    def _detect_display_address(self, vm_name: str):
        """Detect display endpoint. Return (protocol, host, port) or (None, None, None)."""
        # Prefer domdisplay which reports the active display URI
        try:
            out = self._execute_command(["sudo", "virsh", "domdisplay", vm_name])
            if out:
                if "://" in out:
                    proto, rest = out.split("://", 1)
                    # Remove possible userinfo and path
                    if '@' in rest:
                        rest = rest.split('@', 1)[1]
                    rest = rest.split('/', 1)[0]
                    host = rest
                    port = None
                    if ':' in rest:
                        host, p = rest.rsplit(':', 1)
                        try:
                            port = int(p)
                        except Exception as e:
                            logger.error(f"parse domdisplay port failed: {e}")
                            port = None
                    return proto.lower(), host, port
        except Exception as e:
            logger.error(f"domdisplay failed: {e}")
        # Fallback: vncdisplay gives X-style display like :0 => 5900
        try:
            out = self._execute_command(["sudo", "virsh", "vncdisplay", vm_name])
            if out and out.strip().startswith(":"):
                display_num = out.strip().lstrip(":")
                if display_num.isdigit():
                    port = 5900 + int(display_num)
                    return "vnc", "127.0.0.1", port
        except Exception as e:
            logger.error(f"vncdisplay failed: {e}")
        # Last resort: parse dumpxml for graphics element
        try:
            xml_str = self._execute_command(["sudo", "virsh", "dumpxml", vm_name])
            if xml_str:
                root = ET.fromstring(xml_str)
                g = root.find("./devices/graphics")
                if g is not None:
                    proto = g.get("type")
                    port_attr = g.get("port")
                    port = None
                    if port_attr and port_attr != "-1":
                        try:
                            port = int(port_attr)
                        except Exception as e:
                            logger.error(f"parse graphics port failed: {e}")
                            port = None
                    host = g.get("listen")
                    listen_elem = g.find("listen")
                    if listen_elem is not None:
                        host = listen_elem.get("address") or host
                    return (proto.lower() if proto else None), (host or "127.0.0.1"), port
        except Exception as e:
            logger.error(f"dumpxml parse graphics failed: {e}")
        return None, None, None
    def start_emulator(self, path_to_vm: str, headless: bool, os_type: str):
        """Start the libvirt VM."""
        vm_name = self._get_vm_name_from_path(path_to_vm)
        logger.info(f"Starting libvirt VM: {vm_name}")
        
        # Check if VM exists
        if not self._vm_exists(vm_name):
            raise Exception(f"VM {vm_name} does not exist")
        
        # Start VM if not already running
        if not self._vm_is_running(vm_name):
            try:
                self._execute_command(["sudo", "virsh", "start", vm_name], return_output=False)
                logger.info(f"VM {vm_name} started successfully")
            except Exception as e:
                # Check if error is because VM is already running
                error_msg = str(e)
                if "域已经活跃" in error_msg or "already active" in error_msg.lower():
                    logger.info(f"VM {vm_name} is already running (detected during start)")
                else:
                    logger.error(f"Failed to start VM {vm_name}: {e}")
                    raise
        else:
            logger.info(f"VM {vm_name} is already running")
        
        # Wait for VM to be fully started
        time.sleep(WAIT_TIME)
        
    
    def get_ip_address(self, path_to_vm: str, max_retries: int = 30, retry_interval: float = 2.0) -> str:
        """Get the IP address of the VM (fast path for libvirt/deepin-25).
        Strategy (fast -> robust):
        1) QEMU Guest Agent: virsh qemu-agent-command guest-network-get-interfaces
        2) Libvirt DHCP leases: /var/lib/libvirt/dnsmasq/<network>.leases (match MAC)
        3) libvirt net-dhcp-leases <network> (match MAC)
        4) domifaddr with explicit source (lease -> arp)
        We avoid slow IP-range ping scanning.

        Args:
            path_to_vm: VM name/path
            max_retries: Maximum number of retry attempts to get IP (default: 30)
            retry_interval: Seconds to wait between retries (default: 2.0)

        Returns:
            IP address of the VM

        Raises:
            Exception: If IP cannot be determined after all retries
        """
        vm_name = self._get_vm_name_from_path(path_to_vm)
        def _parse_first_ipv4_from_domifaddr(output: str):
            for line in output.split('\n'):
                if 'ipv4' in line.lower() and '/' in line:
                    for part in line.split():
                        if '/' in part and '.' in part:
                            ip = part.split('/')[0]
                            if ip and ip != '127.0.0.1':
                                return ip
            return None
        def _vm_interfaces():
            """Return ([(mac, network_name, bridge_name)], primary_target_dev)."""
            try:
                xml_str = self._execute_command(["sudo", "virsh", "dumpxml", vm_name])
                root = ET.fromstring(xml_str)
                ifaces = []
                primary_target = None
                for iface in root.findall("./devices/interface"):
                    mac = None
                    mac_elem = iface.find("mac")
                    if mac_elem is not None:
                        mac = mac_elem.get("address")
                    src_network = None
                    src_bridge = None
                    src = iface.find("source")
                    if src is not None:
                        src_network = src.get("network")
                        src_bridge = src.get("bridge")
                    tgt = iface.find("target")
                    if tgt is not None and not primary_target:
                        primary_target = tgt.get("dev")
                    if mac:
                        ifaces.append((mac, src_network, src_bridge))
                return ifaces, primary_target
            except Exception as e:
                logger.error(f"dumpxml for interfaces failed: {e}")
                return [], None
        def _bridge_to_network_name(bridge_name: str):
            """Map linux bridge (e.g., virbr0) to libvirt network name (e.g., default)."""
            try:
                nets_str = self._execute_command(["sudo", "virsh", "net-list", "--name"]) or ""
                for net in filter(None, nets_str.split('\n')):
                    try:
                        net_xml = self._execute_command(["sudo", "virsh", "net-dumpxml", net])
                        net_root = ET.fromstring(net_xml)
                        br = net_root.find("./bridge")
                        if br is not None and br.get("name") == bridge_name:
                            return net
                    except Exception as e:
                        logger.error(f"net-dumpxml failed: {e}")
                        continue
            except Exception as e:
                logger.error(f"net-list failed: {e}")
                return None
        dnsmasq_prefix_cache = {}
        def _query_qga_interfaces(vm_name: str):
            """Try QGA commands with limited retries, log only when all attempts fail."""
            known_errors = (
                "guest agent is not responding",
                "guest agent is not connected",
                "guest agent is not configured",
            )
            first_known_err = None
            for attempt in range(5):
                try:
                    self._execute_command(
                        ["sudo", "virsh", "qemu-agent-command", vm_name, '{"execute":"guest-ping"}'],
                        timeout=4
                    )
                    return self._execute_command(
                        ["sudo", "virsh", "qemu-agent-command", vm_name, '{"execute":"guest-network-get-interfaces"}'],
                        timeout=5
                    )
                except Exception as e:
                    msg = str(e).lower()
                    if any(err in msg for err in known_errors):
                        if first_known_err is None:
                            first_known_err = str(e).strip()
                        if attempt < 4:
                            time.sleep(2)
                            continue
                        break
                    else:
                        logger.error(f"QGA commands failed: {e}")
                        return None
            if first_known_err:
                logger.warning(f"QGA not ready for {vm_name}: {first_known_err}")
            return None
        def _dnsmasq_file_bases(network: str):
            """Return possible dnsmasq file name prefixes for the given libvirt network."""
            if not network:
                return []
            if network in dnsmasq_prefix_cache:
                return dnsmasq_prefix_cache[network]
            bases = [network]
            try:
                net_xml = self._execute_command(["sudo", "virsh", "net-dumpxml", network])
                root = ET.fromstring(net_xml)
                bridge = root.find("./bridge")
                if bridge is not None:
                    br_name = bridge.get("name")
                    if br_name and br_name not in bases:
                        bases.append(br_name)
            except Exception as e:
                logger.error(f"net-dumpxml {network} failed: {e}")
            dnsmasq_prefix_cache[network] = bases
            return bases
        def _lease_ip_from_dnsmasq(network: str, mac: str):
            try:
                for base in _dnsmasq_file_bases(network):
                    lease_file = f"/var/lib/libvirt/dnsmasq/{base}.leases"
                    if not os.path.exists(lease_file):
                        continue
                    try:
                        content = self._execute_command(["sudo", "cat", lease_file])
                    except Exception as e:
                        logger.error(f"read leases file {lease_file} failed: {e}")
                        continue
                    latest = None
                    latest_ts = -1
                    for line in content.split('\n'):
                        parts = line.split()
                        if len(parts) >= 3 and parts[1].lower() == mac.lower():
                            try:
                                ts = int(parts[0])
                            except Exception:
                                logger.exception("Invalid lease timestamp entry: %s", line)
                                ts = 0
                            ip = parts[2]
                            if ts >= latest_ts and ip and ip != '127.0.0.1':
                                latest = ip
                                latest_ts = ts
                    if latest:
                        return latest
                for base in _dnsmasq_file_bases(network):
                    status_file = f"/var/lib/libvirt/dnsmasq/{base}.status"
                    if not os.path.exists(status_file):
                        continue
                    try:
                        content = self._execute_command(["sudo", "cat", status_file])
                    except Exception as e:
                        logger.error(f"read leases status {status_file} failed: {e}")
                        continue
                    data = json.loads(content or "[]")
                    for entry in data:
                        if entry.get("mac-address", "").lower() == mac.lower():
                            ip = entry.get("ip-address")
                            if ip and ip != "127.0.0.1":
                                return ip
            except Exception as e:
                logger.error(f"parse leases data failed: {e}")
            return None
        def _lease_ip_from_libvirt(network: str, mac: str):
            try:
                out = self._execute_command(["sudo", "virsh", "net-dhcp-leases", network])
                for line in out.split('\n'):
                    if mac.lower() in line.lower() and '/' in line and '.' in line:
                        for token in line.split():
                            if '/' in token and '.' in token:
                                ip = token.split('/')[0]
                                if ip and ip != '127.0.0.1':
                                    return ip
            except Exception as e:
                logger.error(f"net-dhcp-leases failed: {e}")
            return None
        # 1) Try QEMU Guest Agent
        j = _query_qga_interfaces(vm_name)
        if j:
            try:
                data = json.loads(j)
                for nic in data.get("return", []) or []:
                    if nic.get("name", "").startswith("lo"):
                        continue
                    for addr in nic.get("ip-addresses", []) or []:
                        if addr.get("ip-address-type") == "ipv4":
                            ip = addr.get("ip-address")
                            if ip and ip != "127.0.0.1":
                                logger.info(f"Found IP via QGA: {ip}")
                                return ip
            except Exception as e:
                logger.error(f"parse QGA response failed: {e}")
        # 2) MAC + network/bridge info
        ifaces, _ = _vm_interfaces()
        candidates = []
        for mac, net_name, br_name in ifaces:
            if net_name:
                candidates.append((mac, net_name))
            elif br_name:
                mapped = _bridge_to_network_name(br_name)
                if mapped:
                    candidates.append((mac, mapped))
        # 3) Leases (dnsmasq -> libvirt)
        for mac, net in candidates:
            ip = _lease_ip_from_dnsmasq(net, mac)
            if ip:
                logger.info(f"Found IP via dnsmasq leases: {ip}")
                return ip
            ip = _lease_ip_from_libvirt(net, mac)
            if ip:
                logger.info(f"Found IP via libvirt leases: {ip}")
                return ip
        # 4) domifaddr fallbacks with short timeouts
        for source in ("lease", "arp", None):
            try:
                if source:
                    out = self._execute_command(["sudo", "virsh", "domifaddr", vm_name, "--source", source], timeout=3)
                else:
                    out = self._execute_command(["sudo", "virsh", "domifaddr", vm_name], timeout=3)
                ip = _parse_first_ipv4_from_domifaddr(out or "")
                if ip:
                    logger.info(f"Found IP via domifaddr/{source or 'auto'}: {ip}")
                    return ip
            except Exception as e:
                logger.error(f"domifaddr {source} failed: {e}")
                continue
        return None

    def _get_ip_with_retry(self, path_to_vm: str, max_retries: int = 30, retry_interval: float = 2.0) -> str:
        """Wrapper that retries IP detection with backoff."""
        vm_name = self._get_vm_name_from_path(path_to_vm)

        for attempt in range(max_retries):
            ip = self.get_ip_address(path_to_vm, max_retries=1, retry_interval=0)
            if ip:
                logger.info(f"Successfully obtained IP {ip} for VM {vm_name} after {attempt + 1} attempt(s)")
                return ip

            if attempt < max_retries - 1:
                # 只输出第一次和最后几次尝试的日志，避免刷屏
                # if attempt == 0 or attempt >= max_retries - 3:
                    # logger.info(f"Attempt {attempt + 1}/{max_retries}: Could not get IP for VM {vm_name}, retrying in {retry_interval}s...")
                time.sleep(retry_interval)

        # All retries exhausted
        raise Exception(f"Failed to determine IP address for VM {vm_name} after {max_retries} attempts. "
                       f"VM may not be fully started or network is not configured properly.")
    def save_state(self, path_to_vm: str, snapshot_name: str):
        """Create a snapshot of the VM."""
        vm_name = self._get_vm_name_from_path(path_to_vm)
        logger.info(f"Creating snapshot '{snapshot_name}' for VM: {vm_name}")
        
        try:
            # Try simple syntax first (newer libvirt often supports positional args)
            self._execute_command(["sudo", "virsh", "snapshot-create-as", vm_name, snapshot_name], 
                                timeout=300, return_output=False)
            logger.info(f"Snapshot '{snapshot_name}' created successfully (simple syntax)")
        except Exception as e_simple:
            logger.warning(f"Simple snapshot-create-as failed: {e_simple}. Retrying with legacy flags.")
            try:
                # Fallback: explicitly specify domain/name/description (more compatible across versions)
                desc = f"{vm_name} internal snapshot"
                self._execute_command([
                    "sudo", "virsh", "snapshot-create-as",
                    "--domain", vm_name,
                    "--name", snapshot_name,
                    "--description", desc
                ], timeout=300, return_output=False)
                logger.info(f"Snapshot '{snapshot_name}' created successfully (legacy flags)")
            except Exception as e_legacy:
                logger.error(f"Failed to create snapshot with both syntaxes: {e_legacy}")
                raise
        
        time.sleep(WAIT_TIME)
    
    def revert_to_snapshot(self, path_to_vm: str, snapshot_name: str):
        """Revert VM to a specific snapshot."""
        vm_name = self._get_vm_name_from_path(path_to_vm)
        logger.info(f"Reverting VM {vm_name} to snapshot: {snapshot_name}")
        
        try:
            # Check if snapshot exists
            snapshots_output = self._execute_command(["sudo", "virsh", "snapshot-list", vm_name])
            if snapshot_name not in snapshots_output:
                logger.warning(f"Snapshot '{snapshot_name}' not found, creating it first")
                self.save_state(path_to_vm, snapshot_name)
                return path_to_vm
            
            # Revert to snapshot
            self._execute_command(["sudo", "virsh", "snapshot-revert", vm_name, snapshot_name], 
                                timeout=120, return_output=False)  # 2 minutes timeout
            logger.info(f"Successfully reverted to snapshot '{snapshot_name}'")
            
        except Exception as e:
            logger.error(f"Failed to revert to snapshot: {e}")
            raise
        
        time.sleep(WAIT_TIME)
        return path_to_vm
    
    def stop_emulator(self, path_to_vm: str, region=None, *args, **kwargs):
        """Stop the libvirt VM."""
        vm_name = self._get_vm_name_from_path(path_to_vm)
        logger.info(f"Stopping libvirt VM: {vm_name}")
        
        try:
            if self._vm_is_running(vm_name):
                # Try graceful shutdown first
                try:
                    self._execute_command(["sudo", "virsh", "shutdown", vm_name], timeout=30, return_output=False)
                    time.sleep(10)  # Wait for graceful shutdown
                except Exception as e:
                    logger.error(f"graceful shutdown failed: {e}")
                
                # If still running, force destroy
                if self._vm_is_running(vm_name):
                    self._execute_command(["sudo", "virsh", "destroy", vm_name], return_output=False)
                    logger.info(f"VM {vm_name} forcefully stopped")
                else:
                    logger.info(f"VM {vm_name} gracefully stopped")
            else:
                logger.info(f"VM {vm_name} is already stopped")
                
        except Exception as e:
            logger.warning(f"Error stopping VM {vm_name}: {e}")
    
    def get_vnc_port(self, path_to_vm: str) -> int:
        """Get the VNC port for the VM."""
        vm_name = self._get_vm_name_from_path(path_to_vm)
        
        try:
            # Get VM XML configuration
            xml_output = self._execute_command(["sudo", "virsh", "dumpxml", vm_name])
            
            # Parse XML to find VNC port
            root = ET.fromstring(xml_output)
            graphics = root.find(".//graphics[@type='vnc']")
            
            if graphics is not None:
                port = graphics.get('port')
                if port and port != '-1':
                    return int(port)
            
            # If not found in XML, return default
            logger.warning(f"Could not determine VNC port for VM {vm_name}, using default 5900")
            return 5900
            
        except Exception as e:
            logger.warning(f"Error getting VNC port for VM {vm_name}: {e}")
            return 5900

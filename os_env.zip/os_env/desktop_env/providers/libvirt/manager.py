import logging
import os
import json
import re
import shlex
import socket
import subprocess
import threading
import time
import random
from typing import Dict, List, Optional, Set, Tuple

import psutil
from filelock import FileLock

from desktop_env.providers.base import VMManager
from desktop_env.config.loader import get_conf, get_vm_specs

logger = logging.getLogger("desktopenv.providers.libvirt.LibvirtVMManager")
logger.setLevel(logging.INFO)

REGISTRY_PATH = '.libvirt_vms'
LOCK_FILE_NAME = '.libvirt_lck'
MAX_RETRY_TIMES = 20
VNC_RESERVATION_FILE_NAME = '.libvirt_vnc_ports.json'
VNC_RESERVATION_TTL_SECONDS = 600
VNC_SCAN_WINDOW = 2000



TEMPLATE_IMAGE_PATH = get_conf('libvirt', 'template_image_path')
VM_IMAGES_DIR = get_conf('libvirt', 'vm_images_dir')
VM_PREFIX = get_conf('libvirt', 'vm_prefix')
BASE_VNC_PORT = int(get_conf('libvirt', 'base_vnc_port'))
_SPECS = get_vm_specs()
DEFAULT_MEMORY = int(_SPECS.get('memory'))
DEFAULT_VCPUS = int(_SPECS.get('vcpus'))
DEFAULT_DISK_SIZE = int(_SPECS.get('disk_size'))
BRIDGE_NAME = get_conf('libvirt', 'bridge_name')
VNC_LISTEN = get_conf('libvirt', 'vnc_listen')
VNC_PASSWORD = get_conf('libvirt', 'vnc_password')
VIDEO_MODEL = get_conf('libvirt', 'video_model')

update_lock = threading.Lock()


def _resolve_lock_timeout_seconds(default: int = 1200) -> int:
    def _to_int(val, fallback: int) -> int:
        try:
            return int(str(val).strip())
        except Exception:
            logger.exception("Invalid lock timeout value=%r fallback=%s", val, fallback)
            return fallback

    env_val = os.environ.get("LIBVIRT_LOCK_TIMEOUT_SECONDS")
    if env_val not in (None, ""):
        return max(60, _to_int(env_val, default))

    try:
        cfg_val = get_conf('libvirt', 'lock_timeout_seconds')
        if cfg_val not in (None, ""):
            return max(60, _to_int(cfg_val, default))
    except Exception:
        logger.exception("Failed to load libvirt.lock_timeout_seconds from config")

    return max(60, int(default))


LOCK_TIMEOUT_SECONDS = _resolve_lock_timeout_seconds()


def _vm_prefix() -> str:
    """Return the VM name prefix from config."""
    return VM_PREFIX or get_conf('libvirt', 'vm_prefix')


def _state_dir() -> str:
    try:
        state_dir = get_conf('paths', 'state_dir')
        if state_dir:
            os.makedirs(state_dir, exist_ok=True)
            return state_dir
    except Exception as e:
        logger.warning(f"resolve state_dir failed: {e}")
    return "."


def _global_lock_path() -> str:
    return os.path.join(_state_dir(), LOCK_FILE_NAME)


def _vnc_reservation_path() -> str:
    return os.path.join(_state_dir(), VNC_RESERVATION_FILE_NAME)


def _is_socket_port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.25)
            return sock.connect_ex((host, int(port))) == 0
    except Exception:
        logger.exception("Socket port probe failed host=%s port=%s", host, port)
        return False


def _parse_ports_from_listen_output(output: str) -> Set[int]:
    ports: Set[int] = set()
    if not output:
        return ports
    for match in re.findall(r":(\d+)\b", output):
        try:
            ports.add(int(match))
        except Exception:
            logger.exception("Failed to parse tcp listen port token=%r", match)
            continue
    return ports


def _collect_listening_tcp_ports() -> Set[int]:
    ports: Set[int] = set()
    for command in (["ss", "-ltn"], ["netstat", "-tuln"]):
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=5)
            if result.returncode != 0:
                continue
            ports.update(_parse_ports_from_listen_output(result.stdout))
            if ports:
                break
        except Exception:
            logger.exception("Failed to collect listening tcp ports with command=%s", command)
            continue
    return ports


def _collect_libvirt_vnc_ports(client_password: str = "password") -> Set[int]:
    ports: Set[int] = set()
    try:
        list_cmd = f"echo '{client_password}' | sudo -S virsh list --all --name"
        vm_list = subprocess.run(
            list_cmd, shell=True, capture_output=True, text=True, timeout=10
        )
        if vm_list.returncode != 0:
            return ports
        vm_names = [name.strip() for name in vm_list.stdout.splitlines() if name.strip()]
        for vm_name in vm_names:
            dump_cmd = f"echo '{client_password}' | sudo -S virsh dumpxml {vm_name}"
            dump_res = subprocess.run(
                dump_cmd, shell=True, capture_output=True, text=True, timeout=10
            )
            if dump_res.returncode != 0:
                continue
            for tag in re.findall(r"<graphics\b[^>]*>", dump_res.stdout):
                if ("type='vnc'" not in tag) and ('type="vnc"' not in tag):
                    continue
                match = re.search(r"port=['\"](-?\d+)['\"]", tag)
                if not match:
                    continue
                try:
                    p = int(match.group(1))
                except Exception:
                    logger.exception("Failed to parse VNC port from graphics tag: %s", tag)
                    continue
                if p >= 0:
                    ports.add(p)
    except Exception as e:
        logger.warning(f"collect libvirt vnc ports failed: {e}")
    return ports


def _load_vnc_reservations() -> Dict[str, Dict[str, float]]:
    path = _vnc_reservation_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f) or {}
        ports = data.get("ports")
        return ports if isinstance(ports, dict) else {}
    except Exception:
        logger.exception("Failed to load VNC reservations from %s", path)
        return {}


def _save_vnc_reservations(ports: Dict[str, Dict[str, float]]) -> None:
    path = _vnc_reservation_path()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"ports": ports}, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.warning(f"save vnc reservations failed: {e}")


def _prune_expired_reservations(ports: Dict[str, Dict[str, float]]) -> Dict[str, Dict[str, float]]:
    now = time.time()
    cleaned: Dict[str, Dict[str, float]] = {}
    for key, meta in (ports or {}).items():
        try:
            expires_at = float((meta or {}).get("expires_at", 0))
        except Exception:
            logger.exception("Invalid VNC reservation expires_at key=%s meta=%r", key, meta)
            expires_at = 0
        if expires_at > now:
            cleaned[str(key)] = meta
    return cleaned


def release_reserved_vnc_ports(ports: List[int], lock_needed: bool = True) -> None:
    if not ports:
        return
    lock = FileLock(_global_lock_path(), timeout=LOCK_TIMEOUT_SECONDS)
    if lock_needed:
        with lock:
            _release_reserved_vnc_ports_no_lock(ports)
    else:
        _release_reserved_vnc_ports_no_lock(ports)


def _release_reserved_vnc_ports_no_lock(ports: List[int]) -> None:
    reservations = _prune_expired_reservations(_load_vnc_reservations())
    changed = False
    for port in ports:
        key = str(port)
        if key in reservations:
            reservations.pop(key, None)
            changed = True
    if changed:
        _save_vnc_reservations(reservations)


def is_vnc_port_available(
    port: int,
    client_password: str = "password",
    extra_blocked_ports: Optional[Set[int]] = None,
    ignore_reserved_ports: Optional[Set[int]] = None,
) -> bool:
    try:
        port = int(port)
    except Exception:
        logger.exception("Invalid VNC port value for availability check: %r", port)
        return False
    if port <= 0:
        return False
    blocked = set(extra_blocked_ports or set())
    blocked.update(_collect_listening_tcp_ports())
    blocked.update(_collect_libvirt_vnc_ports(client_password))
    ignored = set(ignore_reserved_ports or set())
    for key in _prune_expired_reservations(_load_vnc_reservations()).keys():
        try:
            reserved_port = int(key)
        except Exception:
            logger.exception("Invalid reserved VNC port key=%r", key)
            continue
        if reserved_port not in ignored:
            blocked.add(reserved_port)
    if port in blocked:
        return False
    return not _is_socket_port_in_use(port)


def reserve_available_vnc_ports(
    count: int,
    start_port: int = BASE_VNC_PORT,
    client_password: str = "password",
    owner: Optional[str] = None,
    ttl_seconds: int = VNC_RESERVATION_TTL_SECONDS,
    scan_window: int = VNC_SCAN_WINDOW,
) -> List[int]:
    if int(count) <= 0:
        return []
    try:
        start_port = int(start_port)
    except Exception:
        logger.exception("Invalid start_port for reserve_available_vnc_ports: %r", start_port)
        start_port = BASE_VNC_PORT
    lock = FileLock(_global_lock_path(), timeout=LOCK_TIMEOUT_SECONDS)
    with lock:
        reservations = _prune_expired_reservations(_load_vnc_reservations())
        blocked: Set[int] = set()
        blocked.update(_collect_listening_tcp_ports())
        blocked.update(_collect_libvirt_vnc_ports(client_password))
        for key in reservations.keys():
            try:
                blocked.add(int(key))
            except Exception:
                logger.exception("Invalid reserved VNC port key=%r", key)
                continue

        selected: List[int] = []
        max_port = start_port + max(int(scan_window), int(count) * 8)
        current = start_port
        while current <= max_port and len(selected) < int(count):
            if current not in blocked and not _is_socket_port_in_use(current):
                selected.append(current)
                blocked.add(current)
            current += 1

        if len(selected) != int(count):
            raise RuntimeError(
                f"Unable to reserve {count} VNC ports from {start_port} to {max_port}; only {len(selected)} available"
            )

        now = time.time()
        expires_at = now + max(30, int(ttl_seconds))
        owner_val = owner or f"pid:{os.getpid()}"
        for p in selected:
            reservations[str(p)] = {
                "owner": owner_val,
                "reserved_at": now,
                "expires_at": expires_at,
            }
        _save_vnc_reservations(reservations)
        return selected


def generate_new_vm_name(client_password="password", lock=None):
    """Generate a new unique VM name with optional lock for thread safety."""
    registry_idx = 1
    while True:
        attempted_new_name = f"{VM_PREFIX}-{registry_idx}"
        # Check if VM already exists in libvirt
        try:
            full_command = f"echo '{client_password}' | sudo -S virsh dominfo {attempted_new_name}"
            result = subprocess.run(full_command, shell=True,
                                  capture_output=True, text=True, timeout=10)
            if result.returncode != 0:
                # VM doesn't exist, we can use this name
                return attempted_new_name
        except subprocess.TimeoutExpired:
            logger.warning(f"Timeout checking VM name {attempted_new_name}")

        registry_idx += 1
        if registry_idx > 100:
            raise RuntimeError("Could not generate unique VM name after 100 attempts")


def get_available_vnc_port(
    start_port=BASE_VNC_PORT,
    client_password: str = "password",
    reserved_ports: Optional[Set[int]] = None,
):
    """Get an available VNC port starting from the base port.
    The port is checked against active listeners, existing libvirt VMs and reserved ports.
    """
    try:
        start_port = int(start_port)
    except Exception:
        logger.exception("Invalid start_port for get_available_vnc_port: %r", start_port)
        start_port = BASE_VNC_PORT
    port = start_port
    blocked = set(reserved_ports or set())
    blocked.update(_collect_listening_tcp_ports())
    blocked.update(_collect_libvirt_vnc_ports(client_password))
    reservations = _prune_expired_reservations(_load_vnc_reservations())
    for key in reservations.keys():
        try:
            blocked.add(int(key))
        except Exception:
            logger.exception("Invalid reserved VNC port key=%r", key)
            continue
    while port < start_port + VNC_SCAN_WINDOW:
        try:
            if port not in blocked and not _is_socket_port_in_use(port):
                return port
        except Exception as e:
            logger.error(f"probe VNC port failed: {e}")
        port += 1
    raise Exception("No available VNC port found")


def _is_port_conflict_error(err: Exception) -> bool:
    msg = str(err or "").lower()
    keywords = [
        "path_in_use",
        "already in use",
        "address already in use",
        "端口",
        "被占用",
        "in use by",
    ]
    return any(k in msg for k in keywords)


def _create_vm_from_template(vm_name: str, vnc_port: int, client_password: str = "password") -> str:
    """Create a new VM from template image."""
    logger.info(f"Creating new libvirt VM: {vm_name} with VNC port {vnc_port}")

    # Create new disk based on template
    vm_disk_path = os.path.join(VM_IMAGES_DIR, f"{vm_name}.qcow2")

    # Step 1: Create disk from template
    try:
        cmd_create_disk = f"echo '{client_password}' | sudo -S qemu-img create -f qcow2 -o backing_file={TEMPLATE_IMAGE_PATH},backing_fmt=qcow2 {vm_disk_path} {DEFAULT_DISK_SIZE}G"
        subprocess.run(cmd_create_disk, shell=True, capture_output=True, text=True, check=True)
        # The overlay lands as root:root 644, but the emulator runs as
        # libvirt-qemu:kvm and needs write access to the qcow2 — chown it.
        cmd_chown_disk = f"echo '{client_password}' | sudo -S chown libvirt-qemu:kvm {vm_disk_path}"
        subprocess.run(cmd_chown_disk, shell=True, capture_output=True, text=True, check=True)
        logger.info(f"Created disk for VM {vm_name}")
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to create disk for {vm_name}: {e.stderr}")
        raise Exception(f"Failed to prepare VM disk: {e.stderr}")

    # Step 2: Try high-version virt-install first
    cmd_create_vm_high = (
        f"echo '{client_password}' | sudo -S virt-install "
        f"--name {vm_name} --memory {DEFAULT_MEMORY} --vcpus {DEFAULT_VCPUS} "
        f"--disk path={vm_disk_path},format=qcow2,bus=virtio,size={DEFAULT_DISK_SIZE} "
        f"--network bridge={BRIDGE_NAME},model=virtio "
        f"--graphics vnc,listen={VNC_LISTEN},port={vnc_port},password='{VNC_PASSWORD}' "
        f"--console pty,target_type=serial --boot hd --noautoconsole "
        f"--video model={VIDEO_MODEL} "
        f"--channel type=unix,target.type=virtio,target.name=org.qemu.guest_agent.0 "
        f"--osinfo detect=on,require=off --check path_in_use=off"
    )

    try:
        subprocess.run(cmd_create_vm_high, shell=True, capture_output=True, text=True, check=True)
        logger.info(f"Created and started VM {vm_name} (high-version virt-install)")
        return vm_name
    except subprocess.CalledProcessError as e_high:
        logger.warning(
            "High-version virt-install failed, will retry with low-version compatible flags.\n"
            f"stderr: {e_high.stderr}"
        )

    # Step 3: Fallback for older virt-install versions (remove --osinfo/--check/size)
    cmd_create_vm_basic = (
        f"echo '{client_password}' | sudo -S virt-install "
        f"--name {vm_name} --memory {DEFAULT_MEMORY} --vcpus {DEFAULT_VCPUS} "
        f"--disk path={vm_disk_path},format=qcow2,bus=virtio "
        f"--network bridge={BRIDGE_NAME},model=virtio "
        f"--graphics vnc,listen={VNC_LISTEN},port={vnc_port},password='{VNC_PASSWORD}' "
        f"--console pty,target_type=serial --boot hd --noautoconsole "
        f"--video model={VIDEO_MODEL} "
        f"--channel type=unix,target.type=virtio,target.name=org.qemu.guest_agent.0 "
        f"--osinfo detect=on,require=off"
    )

    try:
        subprocess.run(cmd_create_vm_basic, shell=True, capture_output=True, text=True, check=True)
        logger.info(f"Created and started VM {vm_name} (fallback virt-install)")
        return vm_name
    except subprocess.CalledProcessError as e_basic:
        logger.error(f"Fallback virt-install also failed for {vm_name}: {e_basic.stderr}")
        # Cleanup disk when both attempts fail
        try:
            if os.path.exists(vm_disk_path):
                cleanup_cmd = f"echo '{client_password}' | sudo -S rm -f {vm_disk_path}"
                subprocess.run(cleanup_cmd, shell=True, check=True)
        except Exception as e:
            logger.warning(f"cleanup vm disk {vm_disk_path} failed: {e}")
        raise Exception(f"Failed to create VM with virt-install (both variants). stderr: {e_basic.stderr}")


class LibvirtVMManager(VMManager):
    """VM Manager for libvirt/KVM virtual machines."""
    
    checked_and_cleaned = False
    
    def __init__(self, client_password="password"):
        state_dir = get_conf('paths', 'state_dir')
        try:
            os.makedirs(state_dir, exist_ok=True)
        except Exception as e:
            logger.error(f"create state_dir failed: {e}")
        self.registry_path = os.path.join(state_dir, REGISTRY_PATH)
        lock_path = os.path.join(state_dir, LOCK_FILE_NAME)
        self._ensure_writable_file(lock_path)
        self._ensure_writable_file(self.registry_path)
        self.lock = FileLock(lock_path, timeout=LOCK_TIMEOUT_SECONDS)
        logger.info(f"libvirt registry lock timeout={LOCK_TIMEOUT_SECONDS}s path={lock_path}")
        cfg_pwd = get_conf('libvirt', 'sudo_password')
        self.client_password = cfg_pwd if cfg_pwd else client_password
        self.initialize_registry()

    def _ensure_writable_file(self, path: str) -> None:
        if not path:
            return
        try:
            if os.path.exists(path):
                if os.access(path, os.W_OK):
                    return
                content = None
                if os.path.isfile(path):
                    try:
                        with open(path, "r", encoding="utf-8") as f:
                            content = f.read()
                    except Exception:
                        logger.exception("Failed to read unwritable file before recreation: %s", path)
                        content = None
                try:
                    os.remove(path)
                except Exception as e:
                    logger.warning(f"remove unwritable file failed {path}: {e}")
                    return
                try:
                    with open(path, "w", encoding="utf-8") as f:
                        if content:
                            f.write(content)
                except Exception as e:
                    logger.warning(f"recreate file failed {path}: {e}")
            else:
                with open(path, "a", encoding="utf-8"):
                    pass
        except Exception as e:
            logger.warning(f"ensure writable file failed {path}: {e}")
    
    def add_vm(self, vm_path, region=None, **kwargs):
        """Add VM to registry."""
        with self.lock:
            self._add_vm(vm_path)
    
    def occupy_vm(self, vm_path, pid, region=None, **kwargs):
        """Mark VM as occupied by a process."""
        with self.lock:
            self._occupy_vm(vm_path, pid)
        
    def initialize_registry(self):
        """Initialize the VM registry file."""
        self._ensure_writable_file(self.registry_path)
        if not os.path.exists(self.registry_path):
            with open(self.registry_path, 'w') as f:
                pass
    
    def _execute_command(self, command: list, timeout: int = 60) -> str:
        """Execute a command and return the output."""
        try:
            # Check if command starts with sudo and modify it to use password
            if command and command[0] == "sudo":
                # Convert ["sudo", "virsh", ...] to "echo password | sudo -S virsh ..."
                sudo_command = shlex.join(command[1:])  # Remove "sudo" and join safely
                full_command = f"echo '{self.client_password}' | sudo -S {sudo_command}"
                
                result = subprocess.run(
                    full_command,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=timeout,
                    text=True,
                    encoding="utf-8",
                    check=True
                )
            else:
                result = subprocess.run(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=timeout,
                    text=True,
                    encoding="utf-8",
                    check=True
                )
            return result.stdout.strip()
        except subprocess.CalledProcessError as e:
            raise Exception(f"Command failed: {' '.join(command)}\nError: {e.stderr}")
        except subprocess.TimeoutExpired:
            raise Exception(f"Command timed out: {' '.join(command)}")
    
    def _vm_exists(self, vm_name: str) -> bool:
        """Check if a VM exists in libvirt."""
        try:
            full_command = f"echo '{self.client_password}' | sudo -S virsh dominfo {vm_name}"
            result = subprocess.run(full_command, shell=True, capture_output=True, text=True, timeout=10)
            return result.returncode == 0
        except Exception:
            logger.exception("Failed to check VM existence vm_name=%s", vm_name)
            return False

    def _vm_is_running(self, vm_name: str) -> bool:
        """Check whether a VM is currently running."""
        try:
            full_command = f"echo '{self.client_password}' | sudo -S virsh domstate {vm_name}"
            result = subprocess.run(full_command, shell=True, capture_output=True, text=True, timeout=10)
            if result.returncode != 0:
                return False
            state = (result.stdout or "").strip().lower()
            return state.startswith("running")
        except Exception:
            logger.exception("Failed to check VM running state vm_name=%s", vm_name)
            return False
    
    def _add_vm(self, vm_name: str):
        """Add a VM to the registry if not exists."""
        lines: List[str] = []
        if os.path.exists(self.registry_path):
            with open(self.registry_path, 'r') as f:
                lines = f.readlines()
        for line in lines:
            if line.startswith(f"{vm_name}|"):
                return
        with open(self.registry_path, 'a') as f:
            f.write(f"{vm_name}|free\n")
    
    def _occupy_vm(self, vm_name: str, pid: int):
        """Mark a VM as occupied by a process."""
        lines = []
        with open(self.registry_path, 'r') as f:
            lines = f.readlines()
        
        with open(self.registry_path, 'w') as f:
            for line in lines:
                if line.startswith(f"{vm_name}|"):
                    f.write(f"{vm_name}|{pid}\n")
                else:
                    f.write(line)
    
    def _release_vm(self, vm_name: str):
        """Release a VM back to the free pool."""
        lines = []
        with open(self.registry_path, 'r') as f:
            lines = f.readlines()
        
        with open(self.registry_path, 'w') as f:
            for line in lines:
                if line.startswith(f"{vm_name}|"):
                    f.write(f"{vm_name}|free\n")
                else:
                    f.write(line)
    
    def _delete_vm(self, vm_name: str):
        """Delete a VM completely."""
        try:
            # Stop VM if running
            destroy_cmd = f"echo '{self.client_password}' | sudo -S virsh destroy {vm_name}"
            subprocess.run(destroy_cmd, shell=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            # Try delete 'init_state' snapshot if exists (ignore errors)
            try:
                list_cmd = f"echo '{self.client_password}' | sudo -S virsh snapshot-list {vm_name}"
                result = subprocess.run(list_cmd, shell=True, capture_output=True, text=True)
                if result.returncode == 0 and 'init_state' in result.stdout:
                    del_cmd = f"echo '{self.client_password}' | sudo -S virsh snapshot-delete {vm_name} --snapshotname init_state"
                    subprocess.run(del_cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception as e:
                logger.warning(f"Error deleting init_state snapshot for {vm_name}: {e}")
            # Undefine VM
            undefine_cmd = f"echo '{self.client_password}' | sudo -S virsh undefine {vm_name}"
            subprocess.run(undefine_cmd, shell=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            # Remove disk
            vm_disk_path = os.path.join(VM_IMAGES_DIR, f"{vm_name}.qcow2")
            if os.path.exists(vm_disk_path):
                rm_cmd = f"echo '{self.client_password}' | sudo -S rm -f {vm_disk_path}"
                subprocess.run(rm_cmd, shell=True)
            
            # Remove from registry
            lines = []
            with open(self.registry_path, 'r') as f:
                lines = f.readlines()
            
            with open(self.registry_path, 'w') as f:
                for line in lines:
                    if not line.startswith(f"{vm_name}|"):
                        f.write(line)
                        
        except Exception as e:
            logger.warning(f"Error deleting VM {vm_name}: {e}")
    
    def check_and_clean(self, lock_needed=True):
        """Check and clean up the VM registry."""
        if lock_needed:
            with self.lock:
                self._check_and_clean()
        else:
            self._check_and_clean()
    
    def _check_and_clean(self):
        """Internal method to check and clean up VMs."""
        active_pids = {p.pid for p in psutil.process_iter()}
        new_lines = []
        existing_vms = set()

        if not os.path.exists(self.registry_path):
            return

        with open(self.registry_path, 'r') as file:
            lines = file.readlines()
            for line in lines:
                if '|' not in line.strip():
                    continue

                vm_name, pid_str = line.strip().split('|', 1)

                # Check if VM still exists
                if not self._vm_exists(vm_name):
                    continue

                existing_vms.add(vm_name)

                if pid_str == "free":
                    new_lines.append(line)
                    continue

                try:
                    pid = int(pid_str)
                    if pid in active_pids:
                        new_lines.append(line)
                    else:
                        new_lines.append(f'{vm_name}|free\n')
                except ValueError:
                    logger.warning("Invalid pid in VM registry vm_name=%s pid=%r; mark as free", vm_name, pid_str)
                    new_lines.append(f'{vm_name}|free\n')

        # 扫描系统中已存在但未在注册表中的虚拟机（匹配 VM_PREFIX 前缀）
        try:
            result = subprocess.run(
                f"echo '{self.client_password}' | sudo -S virsh list --all --name",
                shell=True, capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                for vm_name in result.stdout.strip().split('\n'):
                    vm_name = vm_name.strip()
                    if vm_name and vm_name.startswith(_vm_prefix()) and vm_name not in existing_vms:
                        logger.info(f"发现未注册的虚拟机 {vm_name}，添加到注册表")
                        new_lines.append(f'{vm_name}|free\n')
        except Exception as e:
            logger.warning(f"扫描现有虚拟机失败: {e}")

        with open(self.registry_path, 'w') as file:
            file.writelines(new_lines)
    
    def list_free_vms(self, lock_needed=True):
        """List all free VMs."""
        if lock_needed:
            with self.lock:
                return self._list_free_vms()
        else:
            return self._list_free_vms()
    
    def _list_free_vms(self):
        """Internal method to list free VMs."""
        free_vms = []
        if not os.path.exists(self.registry_path):
            return free_vms
            
        with open(self.registry_path, 'r') as file:
            lines = file.readlines()
            for line in lines:
                if '|' not in line.strip():
                    continue
                vm_name, pid_str = line.strip().split('|', 1)
                if pid_str == "free":
                    free_vms.append((vm_name, pid_str))
        return free_vms
    
    def get_vm_path(self, os_type, region=None, screen_size=(1920, 1080), vm_name=None, **kwargs):
        """Get a VM path (name for libvirt).

        Args:
            os_type: Operating system type
            region: Region (optional)
            screen_size: Screen size tuple
            vm_name: Pre-allocated VM name (optional, if provided, will use this specific name)
            **kwargs: Additional arguments

        Returns:
            VM name/path
        """
        requested_vnc_port = kwargs.get("vnc_port")
        try:
            requested_vnc_port = int(requested_vnc_port) if requested_vnc_port is not None else None
        except Exception:
            logger.exception("Invalid requested vnc_port=%r", requested_vnc_port)
            requested_vnc_port = None
        if requested_vnc_port is not None and requested_vnc_port <= 0:
            requested_vnc_port = None

        # 如果提供了预分配的虚拟机名称，直接使用它
        if vm_name:
            logger.info(f"Using pre-allocated VM name: {vm_name}")

            with self.lock:
                if not LibvirtVMManager.checked_and_cleaned:
                    LibvirtVMManager.checked_and_cleaned = True
                    self._check_and_clean()

                target_vm_name = vm_name
                if self._vm_exists(target_vm_name):
                    old_name = target_vm_name
                    target_vm_name = generate_new_vm_name(self.client_password, self.lock)
                    logger.warning(
                        f"VM {old_name} already exists; allocate new VM name {target_vm_name} instead of reusing"
                    )
                else:
                    logger.info(f"VM {target_vm_name} does not exist, creating it")

                max_port_attempts = max(1, int(kwargs.get("max_vnc_port_attempts", 20)))
                next_start_port = requested_vnc_port or BASE_VNC_PORT
                tried_ports: Set[int] = set()
                last_error: Optional[Exception] = None

                for attempt in range(max_port_attempts):
                    if requested_vnc_port is not None and attempt == 0:
                        vnc_port = requested_vnc_port
                    else:
                        vnc_port = get_available_vnc_port(
                            start_port=next_start_port,
                            client_password=self.client_password,
                            reserved_ports=tried_ports,
                        )
                    tried_ports.add(vnc_port)
                    next_start_port = vnc_port + 1

                    if not is_vnc_port_available(
                        vnc_port,
                        client_password=self.client_password,
                        ignore_reserved_ports={requested_vnc_port} if requested_vnc_port else None,
                    ):
                        logger.info(f"VNC port {vnc_port} is busy before create, try next")
                        continue

                    try:
                        created_vm_name = _create_vm_from_template(target_vm_name, vnc_port, self.client_password)
                        self._add_vm(created_vm_name)
                        self._occupy_vm(created_vm_name, os.getpid())
                        if requested_vnc_port is not None:
                            _release_reserved_vnc_ports_no_lock([requested_vnc_port])
                        return created_vm_name
                    except Exception as e:
                        last_error = e
                        if _is_port_conflict_error(e):
                            logger.warning(
                                f"Create VM {target_vm_name} failed due to VNC port conflict on {vnc_port}, retrying"
                            )
                            continue
                        if "已被其他客户机" in str(e) or "path_in_use" in str(e) or "已经在使用" in str(e):
                            target_vm_name = generate_new_vm_name(self.client_password, self.lock)
                            logger.warning(
                                f"Create VM name conflict, retry with new VM name {target_vm_name}"
                            )
                            continue
                        logger.error(f"Failed to create VM {target_vm_name}: {e}")
                        if requested_vnc_port is not None:
                            _release_reserved_vnc_ports_no_lock([requested_vnc_port])
                        raise

                if requested_vnc_port is not None:
                    _release_reserved_vnc_ports_no_lock([requested_vnc_port])
                raise Exception(
                    f"Failed to create VM from requested name {vm_name} after {max_port_attempts} attempts: {last_error}"
                )
        
        # 原有的逻辑：没有提供预分配名称时的处理
        with self.lock:
            if not LibvirtVMManager.checked_and_cleaned:
                LibvirtVMManager.checked_and_cleaned = True
                self._check_and_clean()

        allocation_needed = False
        retry_fetch = False
        with self.lock:
            free_vms = self._list_free_vms()
            def _suffix_index(name: str) -> int:
                try:
                    return int(name.rsplit('-', 1)[1])
                except Exception:
                    logger.exception("Failed to parse vm suffix index from name=%s", name)
                    return 10**9  # 非匹配名排到最后

            free_vms = sorted(free_vms, key=lambda x: _suffix_index(x[0]))

            if len(free_vms) == 0:
                allocation_needed = True
            else:
                # Try to reuse the first free VM
                chosen_vm_name = free_vms[0][0]

                # Check if VM exists and is in a usable state
                if self._vm_exists(chosen_vm_name):
                    # Try to start the VM if it's stopped
                    try:
                        if self._vm_is_running(chosen_vm_name):
                            logger.info(f"VM already running, reusing: {chosen_vm_name}")
                        else:
                            start_cmd = f"echo '{self.client_password}' | sudo -S virsh start {chosen_vm_name}"
                            result = subprocess.run(start_cmd, shell=True, capture_output=True, text=True)
                            if result.returncode == 0 or self._vm_is_running(chosen_vm_name):
                                logger.info(f"Successfully started existing VM: {chosen_vm_name}")
                            else:
                                logger.warning(
                                    f"Existing VM failed to start, delete broken VM and retry: {chosen_vm_name}"
                                )
                                self._delete_vm(chosen_vm_name)
                                retry_fetch = True
                    except Exception as e:
                        logger.warning(f"Failed to start VM {chosen_vm_name}: {e}. Will try next available VM or create new one.")
                        # Remove this VM from free list and try next
                        self._delete_vm(chosen_vm_name)
                        retry_fetch = True

                    if not retry_fetch:
                        self._occupy_vm(chosen_vm_name, os.getpid())
                        return chosen_vm_name
                else:
                    logger.warning(f"VM {chosen_vm_name} not found, removing from registry.")
                    # Remove from registry
                    lines = []
                    with open(self.registry_path, 'r') as f:
                        lines = f.readlines()
                    with open(self.registry_path, 'w') as f:
                        for line in lines:
                            if not line.startswith(f"{chosen_vm_name}|"):
                                f.write(line)
                    retry_fetch = True

        if retry_fetch:
            return self.get_vm_path(os_type, region, screen_size, **kwargs)

        if allocation_needed:
            logger.info("No free virtual machine available. Creating a new one...")
            max_retries = 5
            retry_count = 0

            while retry_count < max_retries:
                with self.lock:
                    new_vm_name = generate_new_vm_name(self.client_password, self.lock)
                    vnc_port = get_available_vnc_port(
                        client_password=self.client_password,
                    )

                    try:
                        created_vm_name = _create_vm_from_template(new_vm_name, vnc_port, self.client_password)
                        self._add_vm(created_vm_name)
                        self._occupy_vm(created_vm_name, os.getpid())
                        return created_vm_name
                    except Exception as e:
                        retry_count += 1
                        if "已被其他客户机" in str(e) or "path_in_use" in str(e) or "已经在使用" in str(e):
                            logger.warning(f"VM name conflict detected for {new_vm_name}, trying next index (attempt {retry_count}/{max_retries})")
                            continue
                        if _is_port_conflict_error(e):
                            logger.warning(
                                f"VNC port conflict detected for {new_vm_name}:{vnc_port}, retrying (attempt {retry_count}/{max_retries})"
                            )
                            continue
                        logger.error(f"Failed to create new VM: {e}")
                        raise

            raise Exception(f"Failed to create VM after {max_retries} attempts due to name conflicts")
    
    def release_vm(self, vm_name: str):
        """Release a VM back to the pool."""
        with self.lock:
            self._release_vm(vm_name)
    
    def delete_vm(self, vm_name: str):
        """Delete a VM completely."""
        with self.lock:
            self._delete_vm(vm_name)

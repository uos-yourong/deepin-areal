from desktop_env.providers.base import VMManager, Provider
from desktop_env.providers.libvirt.manager import LibvirtVMManager
from desktop_env.providers.libvirt.provider import LibvirtProvider


def create_vm_manager_and_provider(provider_name: str, region: str, use_proxy: bool = False, client_password: str = "password"):
    """
    仅保留 libvirt 实现的工厂函数；其他云/虚拟化分支已移除以简化代码。
    Args:
        provider_name (str): 供应商名称，仅支持 "libvirt"
        region (str): 区域（保留参数以兼容调用）
        use_proxy (bool): （保留参数）
        client_password (str): libvirt sudo 密码
    """
    provider_name = provider_name.lower().strip()
    if provider_name != "libvirt":
        raise NotImplementedError(f"Only 'libvirt' provider is supported after cleanup, got: {provider_name}")
    return LibvirtVMManager(client_password=client_password), LibvirtProvider(region, client_password=client_password)

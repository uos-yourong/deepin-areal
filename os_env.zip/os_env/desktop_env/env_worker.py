#!/usr/bin/env python3
import argparse
import atexit
import os
import sys
import logging
import signal
import subprocess
import threading
import time
import base64
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, List

import uvicorn
import requests
from fastapi import FastAPI, HTTPException, Depends, Header
from pydantic import BaseModel, Field

OS_ENV_ROOT = Path(__file__).resolve().parents[1]
if str(OS_ENV_ROOT) not in sys.path:
    sys.path.insert(0, str(OS_ENV_ROOT))

from desktop_env.desktop_env import DesktopEnv
from desktop_env.config.loader import get_conf
from integration.os_env_bridge.session_adapter import normalize_task_config_for_os_env

try:
    from integration.vibe_desktop_env import VibeDesktopEnv
except Exception:
    VibeDesktopEnv = None


logger = logging.getLogger("env_worker")
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

app = FastAPI(title="DesktopEnv Env Worker", version="0.1.0")


ENV_WORKER_TOKEN = os.environ.get("ENV_WORKER_TOKEN")


def require_auth(authorization: Optional[str] = Header(default=None)):
    if not ENV_WORKER_TOKEN:
        return True
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Unauthorized")
    token = authorization.split(" ", 1)[1]
    if token != ENV_WORKER_TOKEN:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return True


class StepRequest(BaseModel):
    action: Any
    pause: int = Field(default=2)


class Observation(BaseModel):
    screenshot_b64: Optional[str] = None
    last_mouse: Optional[Tuple[int, int]] = None
    accessibility_tree: Optional[str] = None
    terminal: Optional[str] = None
    instruction: Optional[str] = None


class StepResponse(BaseModel):
    observation: Observation
    reward: float
    done: bool
    truncated: bool = False
    info: Dict[str, Any]


class ResetRequest(BaseModel):
    # Kept for backward compatibility; reset endpoint also accepts task_config.
    task_config: Optional[Dict[str, Any]] = None
    config: Optional[List[Dict[str, Any]]] = None
    seed: Optional[int] = None
    options: Optional[Dict[str, Any]] = None
    cache_endpoint: Optional[str] = None


class SetupRequest(BaseModel):
    task_config: Optional[Dict[str, Any]] = None
    config: Optional[List[Dict[str, Any]]] = None
    seed: Optional[int] = None
    options: Optional[Dict[str, Any]] = None
    cache_endpoint: Optional[str] = None


class ResetResponse(BaseModel):
    observation: Observation
    info: Dict[str, Any] = {}


class SetupResponse(BaseModel):
    observation: Observation
    info: Dict[str, Any] = {}


class EnvInfo(BaseModel):
    env_id: str
    vm_name: str
    ip: Optional[str]
    http_endpoint: Optional[str]
    vnc_port: Optional[int]
    provider_name: str
    os_type: str
    screen_size: Tuple[int, int]
    task_meta: Dict[str, Any] = {}
    hook_trace: Dict[str, Any] = {}


class _State:
    def __init__(self):
        self.env: Optional[DesktopEnv] = None
        self.env_id: Optional[str] = None
        self.lock = threading.Lock()
        self.meta_lock = threading.Lock()
        self.active_op: str = ""
        self.op_started_at: float = 0.0
        self.task_meta: Dict[str, Any] = {}
        self.hook_trace: Dict[str, Any] = {}


STATE = _State()
_FIREWALL_LOCK = threading.Lock()
_FIREWALL_STATE: Dict[str, Any] = {"applied": False, "controller_ip": None, "port": None}


def _firewall_enabled() -> bool:
    flag = str(os.environ.get("MANAGE_UFW_FOR_WORKER_PORT", "1")).strip().lower()
    if flag in {"0", "false", "no", "off"}:
        return False
    controller_ip = _controller_node_ip()
    node_ip = str(os.environ.get("NODE_IP") or "").strip()
    if controller_ip and node_ip and controller_ip == node_ip:
        logger.info("Skip UFW manage for local controller worker port")
        return False
    return True


def _controller_node_ip() -> str:
    return str(os.environ.get("CONTROLLER_NODE_IP") or os.environ.get("CONTROLLER_IP") or "").strip()


def _sudo_password() -> str:
    try:
        return str(get_conf("libvirt", "sudo_password"))
    except Exception:
        logger.exception("Failed to load libvirt.sudo_password from config")
        return ""


def _run_sudo_command(cmd: List[str], timeout: int = 20) -> Tuple[bool, str]:
    password = _sudo_password()
    try:
        if password:
            result = subprocess.run(
                ["sudo", "-S", *cmd],
                input=password + "\n",
                text=True,
                capture_output=True,
                timeout=timeout,
            )
        else:
            result = subprocess.run(
                ["sudo", "-n", *cmd],
                text=True,
                capture_output=True,
                timeout=timeout,
            )
            if result.returncode != 0 and os.geteuid() == 0:
                result = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
        output = (result.stderr or result.stdout or "").strip()
        if result.returncode != 0:
            return False, output
        if output.upper().startswith("ERROR:"):
            return False, output
        return True, (result.stdout or "").strip()
    except Exception as e:
        logger.exception("sudo command execution failed: %s", cmd)
        return False, str(e)


def _apply_firewall_rule_for_worker_port(port: int) -> None:
    if not _firewall_enabled():
        return
    controller_ip = _controller_node_ip()
    if not controller_ip:
        logger.warning("Skip UFW allow: CONTROLLER_NODE_IP is empty")
        return
    try:
        port = int(port)
    except Exception:
        logger.warning(f"Skip UFW allow: invalid worker port {port}")
        return
    if port <= 0:
        logger.warning(f"Skip UFW allow: invalid worker port {port}")
        return

    with _FIREWALL_LOCK:
        _run_sudo_command(
            [
                "ufw",
                "delete",
                "allow",
                "proto",
                "tcp",
                "from",
                controller_ip,
                "to",
                "any",
                "port",
                str(port),
            ]
        )
        ok, err = _run_sudo_command(
            [
                "ufw",
                "allow",
                "proto",
                "tcp",
                "from",
                controller_ip,
                "to",
                "any",
                "port",
                str(port),
            ]
        )
        if ok:
            _FIREWALL_STATE["applied"] = True
            _FIREWALL_STATE["controller_ip"] = controller_ip
            _FIREWALL_STATE["port"] = port
            logger.info(f"UFW allow controller {controller_ip} -> worker port {port}")
        else:
            logger.warning(f"UFW allow failed for port {port}: {err}")


def _revoke_firewall_rule_for_worker_port() -> None:
    if not _firewall_enabled():
        return
    with _FIREWALL_LOCK:
        if not _FIREWALL_STATE.get("applied"):
            return
        controller_ip = _FIREWALL_STATE.get("controller_ip")
        port = _FIREWALL_STATE.get("port")
        if not controller_ip or not port:
            _FIREWALL_STATE["applied"] = False
            return
        ok, err = _run_sudo_command(
            [
                "ufw",
                "--force",
                "delete",
                "allow",
                "proto",
                "tcp",
                "from",
                str(controller_ip),
                "to",
                "any",
                "port",
                str(port),
            ]
        )
        if ok:
            logger.info(f"UFW revoke controller {controller_ip} -> worker port {port}")
        else:
            logger.warning(f"UFW revoke failed for port {port}: {err}")
        _FIREWALL_STATE["applied"] = False


def _register_firewall_cleanup_handlers() -> None:
    atexit.register(_revoke_firewall_rule_for_worker_port)

    def _signal_handler(signum, _frame):
        logger.warning(f"Received signal {signum}, revoking worker port firewall rule")
        _revoke_firewall_rule_for_worker_port()
        os._exit(0)

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _signal_handler)
        except Exception as e:
            logger.warning(f"register signal handler failed for {sig}: {e}")


def _encode_observation(obs: Dict[str, Any], controller) -> Observation:
    screenshot_b64: Optional[str] = None
    try:
        content = obs.get("screenshot")
        if isinstance(content, (bytes, bytearray)):
            screenshot_b64 = base64.b64encode(content).decode("ascii")
        elif isinstance(content, str):
            screenshot_b64 = content
    except Exception as e:
        logger.error(f"encode screenshot failed: {e}")
        screenshot_b64 = None

    last_mouse = getattr(controller, "last_mouse", None)
    return Observation(
        screenshot_b64=screenshot_b64,
        last_mouse=last_mouse,
        accessibility_tree=obs.get("accessibility_tree"),
        terminal=obs.get("terminal"),
        instruction=obs.get("instruction"),
    )


def _serialize_env_info(env: DesktopEnv, env_id: str) -> EnvInfo:
    provider_name = getattr(env, "provider_name", "")
    vm_name = getattr(env, "path_to_vm", "") or env_id
    if provider_name == "vibe":
        http_endpoint = str(getattr(env, "vibe_base_url", "") or "") or None
        vnc_port = None
        vm_name = str(getattr(env, "path_to_vm", "") or getattr(env, "vibe_app_type", "") or env_id)
    else:
        http_endpoint = None
        try:
            if getattr(env, "vm_ip", None):
                http_endpoint = f"http://{env.vm_ip}:{env.server_port}"
        except Exception as e:
            logger.error(f"compose http_endpoint failed: {e}")
            http_endpoint = None
        try:
            vnc_port = env.provider.get_vnc_port(env.path_to_vm)
        except Exception as e:
            logger.error(f"get_vnc_port failed: {e}")
            vnc_port = None
    return EnvInfo(
        env_id=env_id,
        vm_name=vm_name,
        ip=getattr(env, "vm_ip", None),
        http_endpoint=http_endpoint,
        vnc_port=vnc_port,
        provider_name=provider_name,
        os_type=getattr(env, "os_type", ""),
        screen_size=(getattr(env, "screen_width", 0), getattr(env, "screen_height", 0)),
        task_meta=getattr(env, "_vibe_task_meta", None) or {},
        hook_trace=getattr(env, "_vibe_hook_trace", None) or {},
    )


def _coerce_int(value: Any) -> Optional[int]:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        try:
            return int(value)
        except Exception:
            return None
    return None


def _coerce_dict(value: Any) -> Dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _normalize_os_env_task_payload(
    task_config: Optional[Dict[str, Any]],
    config: Optional[List[Dict[str, Any]]],
    seed: Optional[int] = None,
    options: Optional[Dict[str, Any]] = None,
) -> Tuple[
    Optional[Dict[str, Any]],
    Dict[str, Any],
    Dict[str, Any],
    Optional[int],
    Dict[str, Any],
]:
    request_seed = _coerce_int(seed)
    request_options = dict(options or {})

    if task_config is None:
        if config is not None:
            return {"config": config}, {"source": "legacy_task_config"}, {}, request_seed, request_options
        return None, {}, {}, request_seed, request_options

    if not isinstance(task_config, dict):
        return {"config": config or []}, {"source": "legacy_task_config"}, {}, request_seed, request_options

    raw_payload = dict(task_config)
    if config is not None and "config" not in raw_payload:
        raw_payload["config"] = config

    resolved_seed = request_seed if request_seed is not None else _coerce_int(raw_payload.get("seed"))
    resolved_options = request_options.copy()
    resolved_options.update(_coerce_dict(raw_payload.get("options")))

    if "vibe_config" in raw_payload:
        vibe_cfg = _coerce_dict(raw_payload.get("vibe_config"))
        resolved_seed = resolved_seed if resolved_seed is not None else _coerce_int(vibe_cfg.get("seed"))
        if resolved_seed is None:
            resolved_seed = _coerce_int(_coerce_dict(vibe_cfg.get("data_generation")).get("seed"))
        resolved_options.update(_coerce_dict(vibe_cfg.get("options")))

    if normalize_task_config_for_os_env is None:
        if "vibe_config" not in raw_payload:
            return raw_payload, {"source": "legacy_task_config"}, {}, resolved_seed, resolved_options

        vibe_cfg = raw_payload.get("vibe_config")
        if not isinstance(vibe_cfg, dict):
            return raw_payload, {"source": "invalid_vibe_config"}, {}, resolved_seed, resolved_options

        apps = vibe_cfg.get("apps")
        active_app = str(vibe_cfg.get("active_app") or vibe_cfg.get("app_type") or "wechat")
        task = {}
        if isinstance(apps, list) and apps:
            target = apps[0] if isinstance(apps[0], dict) else {}
            if isinstance(target, dict):
                active_app = str(target.get("app_type") or active_app)
                task = target.get("task") or target.get("task_config") or {}
        else:
            task = vibe_cfg.get("task") or {}
            if not isinstance(task, dict):
                task = {}

        task_type = task.get("task_type") or task.get("type") or "default"
        instruction_id = task.get("instruction_id")
        difficulty = _coerce_int(task.get("difficulty"), 1) or 1
        instruction = task.get("instruction") or task.get("instruction_text") or f"{active_app}:{task_type}:{difficulty}"
        resolved_seed = _coerce_int(task.get("seed")) if resolved_seed is None else resolved_seed
        resolved_options.update(_coerce_dict(task.get("options")))

        return (
            {
                "id": instruction_id or f"{active_app}_{task_type}_{difficulty}",
                "instruction": instruction,
                "config": [],
                "vibe_task": task,
                "vibe_config": raw_payload,
            },
            {
                "source": "vibe_config",
                "app_type": active_app,
                "task_type": task_type,
                "instruction_id": instruction_id,
                "difficulty": difficulty,
            },
            {
                "source": "vibe_config",
                "app_type": active_app,
                "task_type": task_type,
                "instruction_id": instruction_id,
            },
            resolved_seed,
            resolved_options,
        )

    payload, task_meta, hook_meta = normalize_task_config_for_os_env(raw_payload)
    if isinstance(task_meta, dict):
        resolved_seed = _coerce_int(task_meta.get("seed")) if _coerce_int(task_meta.get("seed")) is not None else resolved_seed
    resolved_options.update(_coerce_dict(_coerce_dict(payload.get("vibe_session_payload")).get("options")))
    return payload, task_meta, hook_meta, resolved_seed, resolved_options


def _attach_meta(task_meta: Dict[str, Any], hook_trace_meta: Dict[str, Any]) -> None:
    with STATE.meta_lock:
        STATE.task_meta = dict(task_meta or {})
        STATE.hook_trace = dict(hook_trace_meta or {})
    if STATE.env is not None:
        setattr(STATE.env, "_vibe_task_meta", dict(task_meta or {}))
        setattr(STATE.env, "_vibe_hook_trace", dict(hook_trace_meta or {}))


def _sync_hook_trace(hook_trace: Optional[Dict[str, Any]]) -> None:
    if not hook_trace or not isinstance(hook_trace, dict):
        return
    with STATE.meta_lock:
        merged = dict(STATE.hook_trace or {})
        merged.update(hook_trace)
        STATE.hook_trace = merged
        if STATE.env is not None:
            setattr(STATE.env, "_vibe_hook_trace", dict(merged))


def _current_hook_trace() -> Dict[str, Any]:
    with STATE.meta_lock:
        if STATE.hook_trace:
            return dict(STATE.hook_trace)

    if STATE.env is not None:
        trace = getattr(STATE.env, "_vibe_hook_trace", None)
        if isinstance(trace, dict):
            with STATE.meta_lock:
                STATE.hook_trace = dict(trace)
            return dict(trace)

    return {}


def _with_meta_step_info(info: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(info or {})
    runtime_hook_trace = merged.get("hook_trace")
    _sync_hook_trace(runtime_hook_trace if isinstance(runtime_hook_trace, dict) else None)

    if STATE.task_meta:
        merged["task_meta"] = {
            **dict(STATE.task_meta),
            **dict(merged.get("task_meta") or {}),
        }
    merged["hook_trace"] = _current_hook_trace()
    if merged["hook_trace"] and "provider" not in merged:
        merged["provider"] = getattr(STATE.env, "provider_name", "os_env_snapshot")

    return merged


def _begin_active_op(op_name: str) -> None:
    with STATE.meta_lock:
        STATE.active_op = str(op_name or "")
        STATE.op_started_at = time.time()


def _end_active_op(op_name: str) -> None:
    with STATE.meta_lock:
        if STATE.active_op == str(op_name or ""):
            STATE.active_op = ""
            STATE.op_started_at = 0.0


@app.get("/ping")
def ping(_auth=Depends(require_auth)):
    if not STATE.env:
        raise HTTPException(status_code=503, detail="Env not initialized")
    with STATE.meta_lock:
        active_op = STATE.active_op
        op_started_at = float(STATE.op_started_at or 0.0)
    now = time.time()
    busy = bool(active_op)
    return {
        "status": "busy" if busy else "ok",
        "busy": busy,
        "active_op": active_op or None,
        "busy_elapsed_s": (now - op_started_at) if (busy and op_started_at > 0) else 0.0,
        "timestamp": now,
    }


@app.get("/info", response_model=EnvInfo)
def info(_auth=Depends(require_auth)):
    if not STATE.env:
        raise HTTPException(status_code=500, detail="Env not initialized")
    env_name = STATE.env_id or getattr(STATE.env, "path_to_vm", "") or getattr(STATE.env, "vibe_app_type", "env")
    return _serialize_env_info(STATE.env, env_name)


@app.post("/step", response_model=StepResponse)
def step(req: StepRequest, _auth=Depends(require_auth)):
    if not STATE.env:
        raise HTTPException(status_code=404, detail="Env not found")
    _begin_active_op("step")
    try:
        with STATE.lock:
            a = req.action
            step_result = STATE.env.step(a, pause=req.pause)
            if isinstance(step_result, tuple) and len(step_result) == 5:
                observation, reward, done, truncated, info = step_result
            else:
                observation, reward, done, info = step_result
                truncated = False
            obs = _encode_observation(observation, STATE.env.controller)
            runtime_trace = _current_hook_trace()
            if runtime_trace and not info.get("hook_trace"):
                info["hook_trace"] = runtime_trace
            return StepResponse(
                observation=obs,
                reward=float(reward or 0.0),
                done=bool(done),
                truncated=bool(truncated),
                info=_with_meta_step_info(info or {}),
            )
    finally:
        _end_active_op("step")


@app.post("/reset", response_model=ResetResponse)
def reset(req: ResetRequest, _auth=Depends(require_auth)):
    if not STATE.env:
        raise HTTPException(status_code=404, detail="Env not found")
    _begin_active_op("reset")
    try:
        with STATE.lock:
            task_payload, task_meta, hook_meta, seed, options = _normalize_os_env_task_payload(
                req.task_config, req.config, req.seed, req.options
            )
            _attach_meta(task_meta, hook_meta)
            if task_payload is not None:
                STATE.env.reset(task_payload, seed=seed, options=options)
            else:
                # Reset is intentionally pure: recover VM state to snapshot.
                STATE.env.reset_only()
            observation = STATE.env._get_obs()
            obs = _encode_observation(observation, STATE.env.controller)
            return ResetResponse(
                observation=obs,
                info={
                    "provider": getattr(STATE.env, "provider_name", "os_env_snapshot"),
                    "task_meta": task_meta,
                    "hook_trace": _current_hook_trace(),
                    "bridge_hook_trace": hook_meta,
                },
            )
    finally:
        _end_active_op("reset")


@app.post("/setup", response_model=SetupResponse)
def setup(req: SetupRequest, _auth=Depends(require_auth)):
    if not STATE.env:
        raise HTTPException(status_code=404, detail="Env not found")
    _begin_active_op("setup")
    try:
        with STATE.lock:
            try:
                cache_endpoint = str(req.cache_endpoint or "").strip()
                if cache_endpoint:
                    os.environ["DESKTOP_ENV_DOWNLOAD_CACHE_ENDPOINT"] = cache_endpoint
                else:
                    os.environ.pop("DESKTOP_ENV_DOWNLOAD_CACHE_ENDPOINT", None)
            except Exception as e:
                logger.error(f"update DESKTOP_ENV_DOWNLOAD_CACHE_ENDPOINT failed: {e}")
            payload, task_meta, hook_meta, seed, options = _normalize_os_env_task_payload(
                req.task_config, req.config, req.seed, req.options
            )
            _attach_meta(task_meta, hook_meta)
            if getattr(STATE.env, "provider_name", "") == "vibe":
                ok = bool(STATE.env.setup_task(payload, seed=seed, options=options))
            else:
                ok = bool(STATE.env.setup_task(payload))
            if not ok:
                raise HTTPException(status_code=503, detail="setup failed after retries")
            observation = STATE.env._get_obs()
            obs = _encode_observation(observation, STATE.env.controller)
            return SetupResponse(
                observation=obs,
                info={
                    "provider": getattr(STATE.env, "provider_name", "os_env_snapshot"),
                    "task_meta": task_meta,
                    "hook_trace": _current_hook_trace(),
                    "bridge_hook_trace": hook_meta,
                },
            )
    finally:
        _end_active_op("setup")


@app.get("/observe", response_model=Observation)
def observe(_auth=Depends(require_auth)):
    if not STATE.env:
        raise HTTPException(status_code=404, detail="Env not found")
    with STATE.lock:
        observation = STATE.env._get_obs()
        return _encode_observation(observation, STATE.env.controller)


@app.delete("/close")
def close(_auth=Depends(require_auth)):
    if not STATE.env:
        _revoke_firewall_rule_for_worker_port()
        return {"status": "ok"}
    with STATE.lock:
        try:
            STATE.env.close()
        except Exception as e:
            logger.error(f"STATE.env.close failed: {e}")
        finally:
            _revoke_firewall_rule_for_worker_port()
    threading.Thread(target=lambda: (time.sleep(0.5), os._exit(0)), daemon=True).start()
    return {"status": "ok"}



def main():
    parser = argparse.ArgumentParser(description="Start a single DesktopEnv microservice (one VM per process)")
    parser.add_argument("--provider", default="libvirt")
    parser.add_argument("--os-type", default="deepin")
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--screen-width", type=int, default=int(os.environ.get("SCREEN_WIDTH", 1920)))
    parser.add_argument("--screen-height", type=int, default=int(os.environ.get("SCREEN_HEIGHT", 1080)))
    parser.add_argument("--enable-proxy", action="store_true")
    parser.add_argument("--cache-dir", default=os.path.join(os.path.dirname(__file__), "down_cache"))
    parser.add_argument("--client-password", default="")
    parser.add_argument("--path-to-vm", default=None)
    parser.add_argument("--vnc-port", type=int, default=None)
    parser.add_argument("--host", default=os.environ.get("ENV_WORKER_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("ENV_WORKER_PORT", "8300")))
    args = parser.parse_args()
    _register_firewall_cleanup_handlers()

    client_pwd_cfg = get_conf('desktop_env', 'client_password')
    client_password = args.client_password or client_pwd_cfg

    log_file = os.environ.get("WORKER_LOG_FILE")
    try:
        handlers = [logging.StreamHandler()]
        if log_file:
            d = os.path.dirname(log_file)
            if d:
                try:
                    os.makedirs(d, exist_ok=True)
                except Exception as e:
                    logger.error(f"create log dir failed: {e}")
            handlers.append(logging.FileHandler(log_file, encoding="utf-8"))
        logging.getLogger().handlers = []
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s', handlers=handlers)
        logger.info("env_worker logging initialized")
    except Exception as e:
        logger.error(f"env_worker logging setup failed: {e}")

    try:
        node_cache_dir = args.cache_dir or os.path.join(os.path.dirname(__file__), "down_cache")
        os.makedirs(node_cache_dir, exist_ok=True)
        os.environ["DESKTOP_ENV_DOWNLOAD_CACHE_DIR"] = node_cache_dir
    except Exception as e:
        logger.error(f"setup node cache dir failed: {e}")

    if args.provider == "vibe":
        if VibeDesktopEnv is None:
            raise RuntimeError("VibeDesktopEnv import failed; cannot start env_worker with provider=vibe")
        vibe_base_url = os.environ.get("VIBE_BASE_URL", "http://localhost:8765")
        vibe_app_type = os.environ.get("VIBE_APP_TYPE", "wechat")
        screenshot_timeout = float(os.environ.get("VIBE_SCREENSHOT_TIMEOUT", "2.0"))
        env = VibeDesktopEnv(
            provider_name="vibe",
            vibe_base_url=vibe_base_url,
            vibe_app_type=vibe_app_type,
            screenshot_timeout=screenshot_timeout,
            cache_dir=node_cache_dir,
            action_space="pyautogui",
            screen_width=args.screen_width,
            screen_height=args.screen_height,
            os_type=args.os_type,
            headless=args.headless,
        )
        STATE.env_id = f"vibe:{vibe_app_type}"
    else:
        env = DesktopEnv(
            provider_name=args.provider,
            region=None,
            path_to_vm=args.path_to_vm,
            snapshot_name="init_state",
            action_space="pyautogui",
            cache_dir=node_cache_dir,
            screen_size=(args.screen_width, args.screen_height),
            headless=args.headless,
            require_a11y_tree=False,
            require_terminal=False,
            os_type=args.os_type,
            enable_proxy=args.enable_proxy,
            client_password=client_password,
            vnc_port=args.vnc_port,
        )
        STATE.env_id = env.path_to_vm
    STATE.env = env
    if args.provider != "vibe":
        _apply_firewall_rule_for_worker_port(args.port)
    env_label = getattr(env, "path_to_vm", "") or getattr(env, "vibe_app_type", "") or STATE.env_id
    logger.info(f"Env Worker started for vm={env_label} ip={getattr(env,'vm_ip',None)} host={args.host} port={args.port}")
    try:
        uvicorn.run(app, host=args.host, port=args.port)
    finally:
        _revoke_firewall_rule_for_worker_port()


if __name__ == "__main__":
    main()

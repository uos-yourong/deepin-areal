import os
import yaml
import logging
import re
from typing import Any, Dict, Optional

_CONFIG_CACHE: Dict[str, Any] = {}
_CONFIG_PATH: Optional[str] = None
_TEMPLATE_CACHE: Dict[str, Any] = {}

def load_config(path: str = None) -> Dict[str, Any]:
    """Load the active configuration.

    Priority:
      1) Explicit ``path`` argument (expects all_config.yaml)
      2) ``CONFIG_PATH`` environment variable (path to all_config.yaml)
      3) ``all_config.yaml`` under repo root
    """
    if _CONFIG_CACHE:
        return _CONFIG_CACHE
    if path is None:
        path = os.environ.get("CONFIG_PATH")
    if path is None:
        repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        path = os.path.join(repo_root, "all_config.yaml")
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    group_vars = (cfg.get("ansible") or {}).get("group_vars")
    if not group_vars:
        group_vars = cfg
    def _get_by_path(d: Dict[str, Any], p: str) -> Any:
        cur: Any = d
        for part in p.split("."):
            if not isinstance(cur, dict):
                return None
            cur = cur.get(part)
        return cur
    def _resolve_value(v: Any, ctx: Dict[str, Any]) -> Any:
        if isinstance(v, str):
            s = v.strip()
            m = re.fullmatch(r"\$\{\s*([^}]+)\s*\}", s)
            if m:
                path = m.group(1).strip()
                val = _get_by_path(cfg, path)
                return val if val is not None else v
            m2 = re.fullmatch(r"\{\{\s*([^}|]+)\s*\|\s*int\s*\}\}", s)
            if m2:
                path = m2.group(1).strip()
                val = _get_by_path(group_vars, path) or _get_by_path(cfg, path)
                # Handle chained templates like:
                # "{{ vm_template.size | int }}" -> "${ansible.vm_template_meta.size}" -> 100
                if isinstance(val, str):
                    val2 = _resolve_value(val, ctx)
                    if not isinstance(val2, str):
                        val = val2
                try:
                    return int(val)
                except Exception:
                    logging.exception("Failed to resolve int template value path=%s raw=%r", path, val)
                    return v
        return v
    def _resolve_dict(d: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
        for k in list(d.keys()):
            v = d[k]
            if isinstance(v, dict):
                d[k] = _resolve_dict(v, ctx)
            elif isinstance(v, list):
                d[k] = [(_resolve_dict(x, ctx) if isinstance(x, dict) else _resolve_value(x, ctx)) for x in v]
            else:
                d[k] = _resolve_value(v, ctx)
        return d
    for _ in range(2):
        group_vars = _resolve_dict(group_vars, cfg)
    _CONFIG_CACHE.update(group_vars)
    global _CONFIG_PATH
    _CONFIG_PATH = path
    return _CONFIG_CACHE

def get_conf(*keys, default=None):
    cfg = load_config()
    cur: Any = cfg
    for k in keys:
        if isinstance(cur, dict) and k in cur:
            cur = cur[k]
        else:
            raise KeyError("missing config key path: " + ".".join(str(x) for x in keys))
    path = ".".join(str(x) for x in keys)
    allow_empty = {"libvirt.sudo_password", "desktop_env.client_password"}
    if cur is None or (cur == "" and path not in allow_empty):
        if default is not None:
            return default
        raise ValueError("empty config value for key path: " + path)
    return cur

def get_config_path() -> Optional[str]:
    return _CONFIG_PATH

def get_config_dir() -> str:
    path = get_config_path()
    if path:
        return os.path.dirname(os.path.abspath(path))
    # fallback to module directory
    return os.path.dirname(os.path.abspath(__file__))

def load_vm_template(path: Optional[str] = None) -> Dict[str, Any]:
    """Load VM template preferences from all_config.yaml (group_vars)."""
    if _TEMPLATE_CACHE:
        return _TEMPLATE_CACHE
    cfg = load_config(path)
    _TEMPLATE_CACHE.update(cfg)
    return _TEMPLATE_CACHE

def get_vm_specs() -> Dict[str, int]:
    """Return effective VM specs dict with keys: vcpus, memory, disk_size.
    Priority: vm_template -> libvirt defaults.
    """
    tmpl = load_vm_template() or {}
    t = tmpl.get("vm_template") if isinstance(tmpl, dict) else None
    if not isinstance(t, dict):
        vcpus = get_conf("libvirt", "default_vcpus")
        memory = get_conf("libvirt", "default_memory")
        size = get_conf("libvirt", "default_disk_size")
    else:
        vcpus = t.get("vcpus")
        memory = t.get("memory")
        size = t.get("size")
        if vcpus is None or memory is None or size is None:
            vcpus = vcpus if vcpus is not None else get_conf("libvirt", "default_vcpus")
            memory = memory if memory is not None else get_conf("libvirt", "default_memory")
            size = size if size is not None else get_conf("libvirt", "default_disk_size")
    return {
        "vcpus": int(vcpus),
        "memory": int(memory),
        "disk_size": int(size),
    }

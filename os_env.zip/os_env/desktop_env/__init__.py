# -*- coding: utf-8 -*-
"""
Desktop Environment Module

This module provides the DesktopEnv class for GUI automation and task execution.
"""

from .desktop_env import DesktopEnv

__all__ = ['DesktopEnv']
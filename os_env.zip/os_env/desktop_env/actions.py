KEYBOARD_KEYS = {
  'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
  '0','1','2','3','4','5','6','7','8','9',
  'f1','f2','f3','f4','f5','f6','f7','f8','f9','f10','f11','f12',
  'up','down','left','right',
  'enter','esc','escape','tab','space',
  'backspace','delete','insert',
  'home','end','pageup','pagedown',
  'shift','ctrl','control','alt','option','cmd','command','win','super',
  'capslock','numlock','scrolllock',
  'printscreen','pause','break',
  'menu','apps'
}
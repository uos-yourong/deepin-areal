
display_x=1680
display_y=1050

object_path=$(dbus-send --print-reply --session --dest=com.deepin.daemon.Display /com/deepin/daemon/Display org.freedesktop.DBus.Properties.Get string:com.deepin.daemon.Display string:Monitors | grep "/com/deepin/daemon/Display" | cut -d "\"" -f 2) || exit 1
dbus-send --print-reply --session --dest=com.deepin.daemon.Display $object_path com.deepin.daemon.Display.Monitor.SetModeBySize uint16:$display_x uint16:$display_y || exit 1
dbus-send --print-reply --session --dest=com.deepin.daemon.Display /com/deepin/daemon/Display com.deepin.daemon.Display.ApplyChanges || exit 1
dbus-send --print-reply --session --dest=com.deepin.daemon.Display /com/deepin/daemon/Display com.deepin.daemon.Display.Save  || exit 1
#!/usr/bin/env python3
import argparse
import json
import os
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import subprocess
import time
import requests
import socket
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from desktop_env.config.loader import get_conf
from desktop_env.providers.libvirt.manager import reserve_available_vnc_ports


def _read_int_env(name: str, default: int) -> int:
    try:
        return int(str(os.environ.get(name, default)).strip())
    except Exception:
        logging.exception("Failed to parse int env %s, fallback=%s", name, default)
        return int(default)


def _read_float_env(name: str, default: float) -> float:
    try:
        return float(str(os.environ.get(name, default)).strip())
    except Exception:
        logging.exception("Failed to parse float env %s, fallback=%s", name, default)
        return float(default)


def _read_csv_env(name: str) -> List[str]:
    raw = str(os.environ.get(name, "") or "").strip()
    if not raw:
        return []
    return [item.strip() for item in raw.split(",") if item.strip()]


def _pick_vibe_value(values: List[str], index: int, default: str) -> str:
    if not values:
        return default
    if index < len(values):
        return values[index]
    return values[-1]

def _wait_ready(
    host: str,
    port: int,
    timeout_sec: int = 60,
    proc: Optional[subprocess.Popen] = None,
    max_retries: int = 5,
    retry_wait: int = 240,
) -> Dict[str, Any]:
    url_local = f"http://127.0.0.1:{port}/info"
    last_err = None
    headers = {}
    token = os.environ.get("ENV_WORKER_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    session = requests.Session()
    session.trust_env = False
    for attempt in range(max(1, max_retries)):
        deadline = time.time() + timeout_sec
        while time.time() < deadline:
            if proc is not None and proc.poll() is not None:
                raise RuntimeError(f"env_worker exited: code={proc.returncode}")
            try:
                r = session.get(url_local, headers=headers, timeout=5)
                if r.status_code == 200:
                    info = r.json()
                    info["worker_host"] = host
                    info["worker_port"] = port
                    return info
                last_err = f"status={r.status_code}"
            except Exception as e:
                logging.warning("env_worker readiness probe failed %s:%s err=%s", host, port, e)
                last_err = str(e)
            time.sleep(1.0)
        if attempt < max_retries - 1:
            logging.warning(
                f"env_worker {host}:{port} not ready after {timeout_sec}s "
                f"(attempt {attempt + 1}/{max_retries}), sleep {retry_wait}s then retry..."
            )
            time.sleep(retry_wait)
    raise RuntimeError(f"env_worker {host}:{port} not ready: {last_err}")


def _is_port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.3)
            return s.connect_ex((host, port)) == 0
    except PermissionError:
        logging.warning("Port probe permission denied host=%s port=%s, treating as unknown/free", host, port)
        return False
    except Exception as e:
        logging.exception("Port probe failed host=%s port=%s", host, port)
        return False


def _find_available_port(start_port: int, used_ports: set, max_tries: int = 1000) -> int:
    port = start_port
    tries = 0
    while tries < max_tries:
        if port not in used_ports and not _is_port_in_use(port):
            return port
        port += 1
        tries += 1
    raise RuntimeError(f"no available port found starting from {start_port}")


def main():
    parser = argparse.ArgumentParser(description="在节点侧按数量拉起多个 env_worker，每进程一个 DesktopEnv，并输出其 IP/端口")
    parser.add_argument("--count", type=int, required=True, help="在本节点需要启动的 DesktopEnv/VM 数量")
    parser.add_argument("--provider", default="libvirt")
    parser.add_argument("--os-type", default="deepin")
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--screen-width", type=int, default=int(os.environ.get("SCREEN_WIDTH", 1920)))
    parser.add_argument("--screen-height", type=int, default=int(os.environ.get("SCREEN_HEIGHT", 1080)))
    parser.add_argument("--enable-proxy", action="store_true")
    parser.add_argument("--cache-dir", default="cache")
    parser.add_argument("--base-port", type=int, default=int(os.environ.get("ENV_WORKER_BASE_PORT", "8300")))
    parser.add_argument(
        "--spawn-concurrency",
        type=int,
        default=_read_int_env("ENV_WORKER_SPAWN_CONCURRENCY", 6),
        help="Maximum concurrent env_worker startups per node",
    )
    parser.add_argument(
        "--spawn-stagger-seconds",
        type=float,
        default=_read_float_env("ENV_WORKER_SPAWN_STAGGER_SECONDS", 0.2),
        help="Delay between env_worker spawns to reduce startup contention",
    )
    args = parser.parse_args()

    log_file = os.environ.get('WORKER_LOG_FILE')
    try:
        handlers = [logging.StreamHandler()]
        if log_file:
            Path(log_file).parent.mkdir(parents=True, exist_ok=True)
            handlers.append(logging.FileHandler(log_file, encoding='utf-8'))
        logging.basicConfig(level=logging.INFO,
                            format='%(asctime)s %(levelname)s %(message)s',
                            handlers=handlers)
        logging.info(f"worker start: count={args.count} provider={args.provider} os_type={args.os_type} headless={args.headless}")
    except Exception as e:
        logging.error(f"worker start failed: {e}")
        
        

    node_host = os.environ.get("NODE_HOST") or os.uname().nodename
    node_ip = os.environ.get("NODE_IP") or os.environ.get("ENV_WORKER_HOST", "127.0.0.1")
    results: List[Dict[str, Any]] = []
    allocated_ports = set()
    worker_plans: List[Dict[str, Any]] = []

    provider_name = str(args.provider or "libvirt").strip().lower()
    vm_prefix = get_conf('libvirt', 'vm_prefix') if provider_name == "libvirt" else "vibe"
    sudo_password = get_conf('libvirt', 'sudo_password') or "password"
    planned_vnc_ports: List[Optional[int]] = [None] * args.count
    if provider_name == "libvirt" and args.count > 0:
        try:
            planned = reserve_available_vnc_ports(
                count=args.count,
                start_port=int(get_conf('libvirt', 'base_vnc_port')),
                client_password=sudo_password,
                owner=f"worker-batch:{os.getpid()}",
            )
            planned_vnc_ports = [int(p) for p in planned]
            logging.info(f"pre-reserved {len(planned_vnc_ports)} VNC ports: {planned_vnc_ports}")
        except Exception as e:
            logging.error(f"Failed to pre-reserve VNC ports for count={args.count}: {e}")
            raise

    vibe_app_types = _read_csv_env("VIBE_APP_TYPES")
    vibe_base_urls = _read_csv_env("VIBE_BASE_URLS")
    default_vibe_app_type = str(os.environ.get("VIBE_APP_TYPE", "wechat") or "wechat").strip() or "wechat"
    default_vibe_base_url = str(os.environ.get("VIBE_BASE_URL", "http://127.0.0.1:8765") or "http://127.0.0.1:8765").strip()

    for i in range(args.count):
        desired_port = args.base_port + i
        port = _find_available_port(desired_port, allocated_ports)
        if port != desired_port:
            logging.warning(f"port {desired_port} busy, moved to {port}")
        allocated_ports.add(port)
        vm_name = f"{vm_prefix}-{i+1}"
        vibe_app_type = _pick_vibe_value(vibe_app_types, i, default_vibe_app_type)
        vibe_base_url = _pick_vibe_value(vibe_base_urls, i, default_vibe_base_url)
        python_exe = None
        venv_dir = os.environ.get("VIRTUAL_ENV")
        if venv_dir:
            cand = Path(venv_dir) / "bin" / "python"
            if cand.exists():
                python_exe = str(cand)
        if not python_exe:
            python_exe = "python3"
        cmd = [
            python_exe, "-m", "desktop_env.env_worker",
            "--provider", provider_name,
            "--os-type", args.os_type,
            "--cache-dir", args.cache_dir,
            "--screen-width", str(args.screen_width),
            "--screen-height", str(args.screen_height),
            "--port", str(port),
        ]
        if provider_name == "libvirt":
            cmd.extend(["--path-to-vm", vm_name])
        planned_vnc_port = planned_vnc_ports[i] if i < len(planned_vnc_ports) else None
        if planned_vnc_port is not None:
            cmd.extend(["--vnc-port", str(planned_vnc_port)])
        if args.headless:
            cmd.append("--headless")
        if args.enable_proxy:
            cmd.append("--enable-proxy")
        env_vars = os.environ.copy()
        env_vars.setdefault("ENV_WORKER_HOST", "0.0.0.0")
        if provider_name == "vibe":
            env_vars["VIBE_APP_TYPE"] = vibe_app_type
            env_vars["VIBE_BASE_URL"] = vibe_base_url
        worker_log_file = os.environ.get("WORKER_LOG_FILE")
        if worker_log_file:
            try:
                Path(worker_log_file).parent.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                logging.error(f"create worker log dir failed: {e}")
            stdout = open(worker_log_file, "a", encoding="utf-8")
            stderr = stdout
        else:
            stdout = None
            stderr = None
        worker_plans.append(
            {
                "cmd": cmd,
                "port": port,
                "env": env_vars,
                "stdout": stdout,
                "stderr": stderr,
            }
        )

    ready_timeout = int(os.environ.get("ENV_WORKER_READY_TIMEOUT", "60"))
    ready_max_retries = int(os.environ.get("ENV_WORKER_READY_MAX_RETRIES", "5"))
    ready_retry_wait = int(os.environ.get("ENV_WORKER_READY_RETRY_WAIT", "240"))
    spawn_concurrency = max(1, int(args.spawn_concurrency))
    spawn_stagger_seconds = max(0.0, float(args.spawn_stagger_seconds))
    logging.info(
        f"worker spawn controls: concurrency={spawn_concurrency} stagger={spawn_stagger_seconds}s"
    )

    with ThreadPoolExecutor(max_workers=spawn_concurrency) as ex:
        future_meta: Dict[Any, Dict[str, Any]] = {}

        def _consume_done(done_set) -> None:
            for fut in done_set:
                meta = future_meta.pop(fut, {})
                try:
                    info = fut.result()
                    info["node_host"] = node_host
                    info["node_ip"] = node_ip
                    results.append(info)
                except Exception as e:
                    logging.exception("env_worker startup future failed port=%s", meta.get("port"))
                    results.append(
                        {
                            "error": str(e),
                            "worker_host": node_ip,
                            "worker_port": meta.get("port"),
                            "node_ip": node_ip,
                        }
                    )

        for plan in worker_plans:
            while len(future_meta) >= spawn_concurrency:
                done, _ = wait(list(future_meta.keys()), return_when=FIRST_COMPLETED)
                _consume_done(done)

            p = subprocess.Popen(
                plan["cmd"],
                env=plan["env"],
                stdout=plan["stdout"],
                stderr=plan["stderr"],
            )
            port = int(plan["port"])
            logging.info(f"spawned env_worker pid={p.pid} port={port}")
            fut = ex.submit(
                _wait_ready,
                host=node_ip,
                port=port,
                timeout_sec=ready_timeout,
                proc=p,
                max_retries=ready_max_retries,
                retry_wait=ready_retry_wait,
            )
            future_meta[fut] = {"port": port, "pid": p.pid}
            if spawn_stagger_seconds > 0:
                time.sleep(spawn_stagger_seconds)

        while future_meta:
            done, _ = wait(list(future_meta.keys()), return_when=FIRST_COMPLETED)
            _consume_done(done)

    print(json.dumps({
        "node_host": node_host,
        "node_ip": node_ip,
        "workers": results
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()

from typing import Dict, Any

from .base import RLAdapter


class ARealAdapter(RLAdapter):
    def __init__(self):
        super().__init__()

    def parse(self, output: str, extras: Dict[str, Any]) -> Dict[str, Any]:
        """Return raw model output for downstream logging without GUI-specific parsing."""
        merged_extras = dict(extras or {})
        return {
            "raw_output": output if isinstance(output, str) else "",
            "extras": merged_extras,
        }

    def wrap_observation(self, observation: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(observation, dict):
            return {"screenshot_b64": "", "done": False, "fail": False}

        wrapped = dict(observation)
        wrapped["screenshot_b64"] = wrapped.get("screenshot_b64") or ""

        if "done" not in wrapped:
            wrapped["done"] = False
        if "fail" not in wrapped:
            wrapped["fail"] = False
        if "info" in observation:
            wrapped["info"] = observation.get("info")

        return wrapped

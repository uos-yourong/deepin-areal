"""Slime framework adapter for lightweight parse/wrap utilities."""
from __future__ import annotations

from typing import Any

from .base import RLAdapter


class SlimeAdapter(RLAdapter):
    """
    Lightweight adapter for Slime framework.

    This adapter intentionally keeps only two responsibilities:
    - parse model raw output for optional logging
    - wrap controller/worker observations into a stable shape
    """

    def __init__(self):
        super().__init__()

    def parse(self, output: str, extras: dict[str, Any]) -> dict[str, Any]:
        """
        Keep raw output for optional logging/trajectory metadata.

        Args:
            output: Raw model output text
            extras: Additional metadata

        Returns:
            Dictionary with raw output and extras
        """
        return {
            "raw_output": output if isinstance(output, str) else "",
            "extras": dict(extras or {}),
        }

    def wrap_observation(self, observation: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(observation, dict):
            return {"screenshot_b64": "", "done": False, "fail": False}

        wrapped = dict(observation)
        wrapped["screenshot_b64"] = wrapped.get("screenshot_b64") or ""
        if "done" not in wrapped:
            wrapped["done"] = False
        if "fail" not in wrapped:
            wrapped["fail"] = False
        return wrapped

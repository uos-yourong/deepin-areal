from typing import Dict, Any, List
import base64


class RLAdapter:
    def __init__(self):
        pass

    def to_actions(self, output: str, extras: Dict[str, Any]) -> List[Dict[str, Any]]:
        raise NotImplementedError

    def parse(self, output: str, extras: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    def format_observation(self, screenshot_bytes: bytes | None, meta: Dict[str, Any]) -> Dict[str, Any]:
        obs_b64 = None
        if screenshot_bytes:
            obs_b64 = base64.b64encode(screenshot_bytes).decode("ascii")
        return {"screenshot_b64": obs_b64}

    def wrap_observation(self, obs: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "screenshot_b64": obs.get("screenshot_b64"),
            "accessibility_tree": obs.get("accessibility_tree"),
            "terminal": obs.get("terminal"),
            "last_mouse": obs.get("last_mouse"),
        }

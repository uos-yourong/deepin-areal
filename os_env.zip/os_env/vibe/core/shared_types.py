"""Shared Types - 所有模块共享的核心数据类型定义

本模块定义了动作、观测、奖励、任务等核心数据类型。
所有类型设计兼容 OpenAI Gym/Gymnasium 接口。
"""

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple, Union
from enum import Enum, auto
import numpy as np


# ============ 动作类型定义 ============


class ActionType(Enum):
    """动作类型"""

    MOUSE = auto()
    KEYBOARD = auto()
    SYSTEM = auto()  # reset, wait, 等系统动作


class MouseActionType(Enum):
    """鼠标动作子类型"""

    MOVE = auto()
    CLICK = auto()
    DOUBLE_CLICK = auto()
    RIGHT_CLICK = auto()
    DRAG = auto()
    SCROLL = auto()


class KeyboardActionType(Enum):
    """键盘动作子类型"""

    KEY_PRESS = auto()
    KEY_RELEASE = auto()
    KEY_SEQUENCE = auto()
    HOTKEY = auto()
    TYPE_TEXT = auto()


@dataclass
class SystemAction:
    """系统动作。

    Attributes:
        action: 系统动作名，例如 switch_app
        target_app: 目标应用名（当前主要用于 switch_app）
        reset_task: 是否在切换后重置目标应用任务状态
    """

    action: str
    target_app: Optional[str] = None
    reset_task: bool = False


@dataclass
class Coordinate:
    """坐标 - 使用相对窗口的归一化坐标 [0.0, 1.0]

    归一化坐标的优势:
    1. 不同窗口大小下保持一致性
    2. 便于模型的泛化
    3. 训练时可配合数据增强

    Attributes:
        x: 水平位置 [0.0, 1.0]，0=left, 1=right
        y: 垂直位置 [0.0, 1.0]，0=top, 1=bottom
    """

    x: float
    y: float

    def __post_init__(self):
        """确保坐标在有效范围内"""
        self.x = max(0.0, min(1.0, self.x))
        self.y = max(0.0, min(1.0, self.y))

    def to_absolute(self, window_width: int, window_height: int) -> Tuple[int, int]:
        """转换为绝对像素坐标

        Args:
            window_width: 窗口宽度（像素）
            window_height: 窗口高度（像素）

        Returns:
            (x_pixel, y_pixel) 绝对坐标
        """
        return (int(self.x * window_width), int(self.y * window_height))

    @classmethod
    def from_absolute(
        cls, x_pixel: int, y_pixel: int, window_width: int, window_height: int
    ) -> "Coordinate":
        """从绝对像素坐标创建归一化坐标

        Args:
            x_pixel: 水平像素位置
            y_pixel: 垂直像素位置
            window_width: 窗口宽度
            window_height: 窗口高度

        Returns:
            Coordinate 归一化坐标
        """
        return cls(
            x=x_pixel / window_width if window_width > 0 else 0.0,
            y=y_pixel / window_height if window_height > 0 else 0.0,
        )


@dataclass
class MouseAction:
    """鼠标动作

    Attributes:
        subtype: 鼠标动作类型
        coordinate: 目标坐标
        button: 按键类型 (left/right/middle)
        delta: 滚动距离（用于SCROLL）
        end_coordinate: 拖拽终点（用于DRAG）
        duration: 动画持续时间（秒）
    """

    subtype: MouseActionType
    coordinate: Coordinate
    button: str = "left"
    delta: int = 0
    end_coordinate: Optional[Coordinate] = None
    duration: float = 0.1


@dataclass
class KeyboardAction:
    """键盘动作

    Attributes:
        subtype: 键盘动作类型
        key: 单个按键（用于PRESS/RELEASE）
        keys: 按键列表（用于SEQUENCE/HOTKEY）
        text: 文本内容（用于TYPE_TEXT）
        interval: 按键间隔（秒）
    """

    subtype: KeyboardActionType
    key: Optional[str] = None
    keys: List[str] = field(default_factory=list)
    text: Optional[str] = None
    interval: float = 0.01


@dataclass
class Action:
    """统一动作封装

    与现有actions.py的兼容转换在ActionConverter中实现

    Attributes:
        type: 动作大类
        mouse_action: 鼠标动作详情（当type=MOUSE时）
        keyboard_action: 键盘动作详情（当type=KEYBOARD时）
        timestamp: 动作时间戳
    """

    type: ActionType
    mouse_action: Optional[MouseAction] = None
    keyboard_action: Optional[KeyboardAction] = None
    system_action: Optional[SystemAction] = None
    timestamp: float = field(default_factory=lambda: time.time())

    def __post_init__(self):
        """验证动作一致性"""
        if self.type == ActionType.MOUSE and self.mouse_action is None:
            raise ValueError("MOUSE action requires mouse_action")
        if self.type == ActionType.KEYBOARD and self.keyboard_action is None:
            raise ValueError("KEYBOARD action requires keyboard_action")
        if self.type == ActionType.SYSTEM and self.system_action is None:
            self.system_action = SystemAction(action="noop")
        if self.type == ActionType.SYSTEM and self.system_action is not None:
            self.system_action.action = str(self.system_action.action or "noop")


# ============ 观测定义 ============


@dataclass
class Observation:
    """观测

    注：实际训练中，模型通过外部截图系统获取观测。
    此处的screenshot主要用于调试或备用场景。

    Attributes:
        screenshot: RGB数组 [H, W, 3]，范围[0, 255]
        timestamp: 观测时间戳
        _internal_state: 内部状态（调试用，模型不应使用）
    """

    screenshot: Optional[np.ndarray] = None
    timestamp: float = field(default_factory=lambda: time.time())

    # 调试专用 - 模型训练时不应访问
    _internal_state: Optional[Dict] = field(default=None, repr=False)


# ============ 奖励定义 ============


@dataclass
class RewardComponents:
    """奖励分解 - 用于调试和分析

    Attributes:
        base: 基础奖励
        progress: 阶段性进度奖励
        efficiency: 动作效率奖励（如快速完成）
        penalties: 惩罚项（错误动作、超时等）
        terminal: 终局奖励（成功/失败）
    """

    base: float = 0.0
    progress: float = 0.0
    efficiency: float = 0.0
    penalties: float = 0.0
    terminal: float = 0.0
    hooks: float = 0.0

    @property
    def total(self) -> float:
        """计算总奖励"""
        return (
            self.base
            + self.progress
            + self.efficiency
            + self.penalties
            + self.terminal
            + self.hooks
        )

    def to_dict(self) -> Dict[str, float]:
        """转换为字典"""
        return {
            "base": self.base,
            "progress": self.progress,
            "efficiency": self.efficiency,
            "penalties": self.penalties,
            "terminal": self.terminal,
            "hooks": self.hooks,
            "total": self.total,
        }


# ============ 任务定义 ============


class TaskType(Enum):
    """任务类型"""

    # IM类任务
    OPEN_CONVERSATION = "open_conversation"
    SEARCH_AND_OPEN = "search_and_open"
    SEARCH_GROUP = "search_group"
    SEND_TEXT_MESSAGE = "send_text_message"
    SEND_FILE = "send_file"
    FORWARD_MESSAGE = "forward_message"
    REPLY_TO_MESSAGE = "reply_to_message"
    DELETE_MESSAGE = "delete_message"
    PIN_CONVERSATION = "pin_conversation"
    SEARCH_MESSAGE = "search_message"

    # 多媒体与内容任务
    SEARCH_MUSIC = "search_music"
    PLAY_SONG = "play_song"
    PAUSE_PLAYBACK = "pause_playback"
    OPEN_PLAYLIST = "open_playlist"

    # 邮件任务
    OPEN_FOLDER = "open_folder"
    OPEN_MAIL = "open_mail"
    MARK_AS_READ = "mark_as_read"
    REPLY_MAIL = "reply_mail"

    # 通用任务
    DEFAULT = "default"
    CUSTOM = "custom"

    # 系统动作任务
    SWITCH_APP = "switch_app"


@dataclass
class TaskConfig:
    """任务配置

    定义一个训练任务的完整配置，包括初始状态、目标、奖励等。

    Attributes:
        task_type: 任务类型标识
        difficulty: 难度等级 1-5
        description: 自然语言任务描述
        initial_state_config: 初始状态配置
        target: 任务目标参数
        success_conditions: 成功条件列表
        failure_conditions: 失败条件列表
        max_steps: 最大步数限制
        reward_config: 奖励配置
        randomization: 随机化配置
    """

    task_type: Union[TaskType, str]
    difficulty: int = 1
    description: str = ""
    initial_state_config: Dict[str, Any] = field(default_factory=dict)
    target: Dict[str, Any] = field(default_factory=dict)
    success_conditions: List[Dict] = field(default_factory=list)
    failure_conditions: List[Dict] = field(default_factory=list)
    max_steps: int = 50
    reward_config: Dict[str, float] = field(
        default_factory=lambda: {
            "success_reward": 10.0,
            "failure_penalty": -5.0,
            "step_penalty": -0.01,
        }
    )
    hook_rules: List[Dict[str, Any]] = field(default_factory=list)
    randomization: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """确保难度在有效范围"""
        self.difficulty = max(1, min(5, self.difficulty))
        # 统一task_type为TaskType枚举
        if isinstance(self.task_type, str):
            try:
                self.task_type = TaskType(self.task_type)
            except ValueError:
                # 保留自定义字符串类型
                pass


# ============ 状态定义 ============


@dataclass
class WindowState:
    """窗口状态"""

    x: int = 0
    y: int = 0
    width: int = 1200
    height: int = 800
    focused: bool = True
    minimized: bool = False

    @property
    def size(self) -> Tuple[int, int]:
        """获取窗口尺寸"""
        return (self.width, self.height)


@dataclass
class ApplicationState:
    """应用状态基类

    所有应用状态的基类，定义通用状态字段。
    子类应继承并扩展特定于应用的状态。

    Attributes:
        window: 窗口状态
        current_view: 当前视图/页面标识
        focused_element_id: 当前焦点元素ID
        timestamp: 状态时间戳
        step_count: 当前episode的步数
    """

    window: WindowState = field(default_factory=WindowState)
    current_view: str = "main"
    focused_element_id: Optional[str] = None
    timestamp: float = field(default_factory=lambda: time.time())
    step_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典

        使用dataclasses.asdict递归转换所有字段。
        """
        import dataclasses

        return dataclasses.asdict(self)

    def copy(self) -> "ApplicationState":
        """创建状态的深拷贝"""
        import copy

        return copy.deepcopy(self)


# ============ 动作转换器 ============


class ActionConverter:
    """动作格式转换器

    处理现有系统 action dict 与 Vibe Action 对象之间的转换。
    """

    @staticmethod
    def from_gym_action(gym_action: Dict[str, Any]) -> Action:
        """从 Gym 格式 action dict 转换为 Vibe Action

        适配现有 actions.py 的格式:
        {
            "action_type": "mouse|keyboard",
            "move_type": "move|click|double_click|...",
            "coordinate": [x, y],  # 归一化坐标 [0,1]
            "button": "left|right|middle",
            ...
        }

        Args:
            gym_action: Gym格式的动作字典

        Returns:
            Action Vibe动作对象
        """
        action_type = gym_action.get("action_type", "mouse")

        if action_type == "mouse":
            return ActionConverter._parse_mouse_action(gym_action)
        elif action_type == "keyboard":
            return ActionConverter._parse_keyboard_action(gym_action)
        elif action_type == "system":
            return ActionConverter._parse_system_action(gym_action)
        elif action_type in {"wait", "noop"}:
            return Action(type=ActionType.SYSTEM, system_action=SystemAction(action="noop"))
        else:
            # 默认兼容旧写法，按系统动作入参
            return Action(type=ActionType.SYSTEM, system_action=SystemAction(action=str(action_type)))

    @staticmethod
    def _parse_system_action(gym_action: Dict[str, Any]) -> Action:
        """解析系统动作"""
        action = str(gym_action.get("action", "noop"))
        target_app = gym_action.get("target_app")
        if target_app is not None:
            target_app = str(target_app)
        else:
            target_app = gym_action.get("app")
            if target_app is not None:
                target_app = str(target_app)

        reset_task = gym_action.get("reset_task", False)
        if isinstance(reset_task, str):
            reset_task = reset_task.lower() in {"1", "true", "yes", "on"}

        return Action(
            type=ActionType.SYSTEM,
            system_action=SystemAction(
                action=action,
                target_app=target_app,
                reset_task=bool(reset_task),
            ),
        )

    @staticmethod
    def _parse_mouse_action(gym_action: Dict[str, Any]) -> Action:
        """解析鼠标动作"""
        move_type_str = gym_action.get("move_type", "move").upper()

        # 处理命名差异 (如 double_click vs DOUBLE_CLICK)
        move_type_map = {
            "MOVE": MouseActionType.MOVE,
            "CLICK": MouseActionType.CLICK,
            "DOUBLE_CLICK": MouseActionType.DOUBLE_CLICK,
            "DOUBLECLICK": MouseActionType.DOUBLE_CLICK,
            "RIGHT_CLICK": MouseActionType.RIGHT_CLICK,
            "RIGHTCLICK": MouseActionType.RIGHT_CLICK,
            "DRAG": MouseActionType.DRAG,
            "SCROLL": MouseActionType.SCROLL,
        }

        subtype = move_type_map.get(move_type_str, MouseActionType.MOVE)

        # 解析坐标
        coord = gym_action.get("coordinate", [0.0, 0.0])
        if isinstance(coord, (list, tuple)) and len(coord) >= 2:
            coordinate = Coordinate(x=float(coord[0]), y=float(coord[1]))
        else:
            coordinate = Coordinate(x=0.0, y=0.0)

        # 解析拖拽终点（如果有）
        end_coord = None
        if subtype == MouseActionType.DRAG:
            end_coord_raw = gym_action.get("end_coordinate") or gym_action.get(
                "coordinate2"
            )
            if isinstance(end_coord_raw, (list, tuple)) and len(end_coord_raw) >= 2:
                end_coord = Coordinate(
                    x=float(end_coord_raw[0]), y=float(end_coord_raw[1])
                )

        return Action(
            type=ActionType.MOUSE,
            mouse_action=MouseAction(
                subtype=subtype,
                coordinate=coordinate,
                button=gym_action.get("button", "left"),
                delta=gym_action.get("delta", 0),
                end_coordinate=end_coord,
                duration=gym_action.get("duration", 0.1),
            ),
        )

    @staticmethod
    def _parse_keyboard_action(gym_action: Dict[str, Any]) -> Action:
        """解析键盘动作"""
        kb_type = gym_action.get("key_type", "type")

        if kb_type == "type":
            return Action(
                type=ActionType.KEYBOARD,
                keyboard_action=KeyboardAction(
                    subtype=KeyboardActionType.TYPE_TEXT,
                    text=gym_action.get("text", ""),
                ),
            )
        elif kb_type == "press":
            return Action(
                type=ActionType.KEYBOARD,
                keyboard_action=KeyboardAction(
                    subtype=KeyboardActionType.KEY_PRESS, key=gym_action.get("key", "")
                ),
            )
        elif kb_type == "hotkey":
            keys = gym_action.get("keys", [])
            if isinstance(keys, str):
                keys = keys.split("+")
            return Action(
                type=ActionType.KEYBOARD,
                keyboard_action=KeyboardAction(
                    subtype=KeyboardActionType.HOTKEY, keys=keys
                ),
            )
        else:
            # 默认按序列处理
            keys = gym_action.get("keys", [])
            if not keys and gym_action.get("key"):
                keys = [gym_action["key"]]
            return Action(
                type=ActionType.KEYBOARD,
                keyboard_action=KeyboardAction(
                    subtype=KeyboardActionType.KEY_SEQUENCE,
                    keys=keys if isinstance(keys, list) else [str(keys)],
                ),
            )

    @staticmethod
    def to_gym_action(action: Action) -> Dict[str, Any]:
        """将 Vibe Action 转换为 Gym 格式

        用于与现有系统兼容的输出。

        Args:
            action: Vibe动作对象

        Returns:
            Gym格式的动作字典
        """
        if action.type == ActionType.MOUSE and action.mouse_action:
            ma = action.mouse_action
            gym_action = {
                "action_type": "mouse",
                "move_type": ma.subtype.name.lower(),
                "coordinate": [ma.coordinate.x, ma.coordinate.y],
                "button": ma.button,
            }
            if ma.subtype == MouseActionType.SCROLL:
                gym_action["delta"] = ma.delta
            if ma.subtype == MouseActionType.DRAG and ma.end_coordinate:
                gym_action["end_coordinate"] = [
                    ma.end_coordinate.x,
                    ma.end_coordinate.y,
                ]
            return gym_action

        elif action.type == ActionType.KEYBOARD and action.keyboard_action:
            ka = action.keyboard_action

            if ka.subtype == KeyboardActionType.TYPE_TEXT:
                return {
                    "action_type": "keyboard",
                    "key_type": "type",
                    "text": ka.text or "",
                }
            elif ka.subtype == KeyboardActionType.KEY_PRESS:
                return {
                    "action_type": "keyboard",
                    "key_type": "press",
                    "key": ka.key or "",
                }
            elif ka.subtype == KeyboardActionType.HOTKEY:
                return {
                    "action_type": "keyboard",
                    "key_type": "hotkey",
                    "keys": ka.keys,
                }
            else:
                return {
                    "action_type": "keyboard",
                    "key_type": "sequence",
                    "keys": ka.keys,
                }

        if action.type == ActionType.SYSTEM and action.system_action is not None:
            return {
                "action_type": "system",
                "action": action.system_action.action,
                "target_app": action.system_action.target_app,
                "reset_task": bool(action.system_action.reset_task),
            }

        return {"action_type": "system"}

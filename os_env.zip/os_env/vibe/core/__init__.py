"""Vibe Core - 核心抽象层

提供所有仿真应用的基类和共享类型定义。
"""

from vibe.core.shared_types import (
    Action,
    ActionType,
    MouseAction,
    MouseActionType,
    KeyboardAction,
    KeyboardActionType,
    Coordinate,
    Observation,
    RewardComponents,
    TaskConfig,
    TaskType,
    ApplicationState,
    WindowState,
)

from vibe.core.base_application import BaseApplication
from vibe.core.chat_application import (
    ChatApplication,
    ChatApplicationState,
    Contact,
    Conversation,
    Message,
    ContactType,
    MessageType,
    MessageStatus,
    ChatTaskType,
)

__all__ = [
    # 基础类型
    "Action",
    "ActionType",
    "MouseAction",
    "MouseActionType",
    "KeyboardAction",
    "KeyboardActionType",
    "Coordinate",
    "Observation",
    "RewardComponents",
    "TaskConfig",
    "TaskType",
    "ApplicationState",
    "WindowState",
    # 核心类
    "BaseApplication",
    "ChatApplication",
    "ChatApplicationState",
    # IM数据类型
    "Contact",
    "Conversation",
    "Message",
    "ContactType",
    "MessageType",
    "MessageStatus",
    "ChatTaskType",
]

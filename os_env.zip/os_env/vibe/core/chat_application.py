"""Chat Application - IM Desktop Application Base Class

聊天软件抽象基类，定义联系人、会话、消息等IM特有概念。
继承自 BaseApplication，实现IM通用交互逻辑。
"""

from abc import abstractmethod
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import copy

from vibe.core.base_application import BaseApplication
from vibe.core.shared_types import (
    Action,
    ApplicationState,
    TaskConfig,
    RewardComponents,
    MouseAction,
    KeyboardAction,
    KeyboardActionType,
    Coordinate,
    WindowState,
    TaskType,
)


# ============ IM特有数据结构 ============


class ContactType(Enum):
    """联系人类型"""

    INDIVIDUAL = "individual"  # 个人
    GROUP = "group"  # 群组


class MessageType(Enum):
    """消息类型"""

    TEXT = "text"
    FILE = "file"
    IMAGE = "image"
    SYSTEM = "system"
    VOICE = "voice"
    VIDEO = "video"


class MessageStatus(Enum):
    """消息状态"""

    SENDING = "sending"  # 发送中
    SENT = "sent"  # 已发送
    DELIVERED = "delivered"  # 已送达
    READ = "read"  # 已读
    FAILED = "failed"  # 发送失败


@dataclass
class Contact:
    """联系人

    Attributes:
        id: 唯一标识
        name: 显示名称
        avatar_url: 头像URL或可生成的标识符
        type: 联系人类型（个人/群组）
        status: 在线状态 (online/offline/away/mobile)
        is_pinned: 是否置顶
        is_muted: 是否免打扰
    """

    id: str
    name: str
    avatar_url: Optional[str] = None
    type: ContactType = ContactType.INDIVIDUAL
    status: str = "offline"
    is_pinned: bool = False
    is_muted: bool = False


@dataclass
class Message:
    """消息

    Attributes:
        id: 唯一标识
        conversation_id: 所属会话ID
        sender_id: 发送者ID
        sender_name: 发送者显示名称
        type: 消息类型
        content: 内容字典（根据type不同结构不同）
            - TEXT: {"text": str}
            - FILE: {"filename": str, "size": int, "url": str}
            - IMAGE: {"url": str, "width": int, "height": int}
            - SYSTEM: {"text": str}
        timestamp: 发送时间
        status: 消息状态
    """

    id: str
    conversation_id: str
    sender_id: str
    sender_name: str
    type: MessageType
    content: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.now)
    status: MessageStatus = MessageStatus.SENDING


@dataclass
class Conversation:
    """会话

    Attributes:
        id: 唯一标识
        contact_id: 关联联系人ID
        display_name: 显示名称
        contact_type: 联系人类型
        avatar_url: 头像URL
        last_message_preview: 最后一条消息预览文本
        last_message_timestamp: 最后一条消息时间
        unread_count: 未读消息数
        is_pinned: 是否置顶
        is_muted: 是否免打扰
        messages: 消息列表（当前加载的）
    """

    id: str
    contact_id: str
    display_name: str
    contact_type: ContactType
    avatar_url: Optional[str] = None
    last_message_preview: str = ""
    last_message_timestamp: Optional[datetime] = None
    unread_count: int = 0
    is_pinned: bool = False
    is_muted: bool = False
    messages: List[Message] = field(default_factory=list)


@dataclass
class ChatWindowState:
    """聊天窗口特有状态

    表示主聊天区域的输入和操作状态。

    Attributes:
        input_text: 输入框当前文本
        input_cursor_pos: 光标位置
        input_has_attachment: 是否有附件
        attached_file: 附件信息
        scroll_offset_messages: 消息列表滚动偏移
        selected_message_id: 当前选中的消息ID
        is_recording_voice: 是否正在录制语音
    """

    input_text: str = ""
    input_cursor_pos: int = 0
    input_has_attachment: bool = False
    attached_file: Optional[Dict[str, Any]] = None
    scroll_offset_messages: int = 0
    selected_message_id: Optional[str] = None
    is_recording_voice: bool = False


@dataclass
class OverlayState:
    """浮层状态（右键菜单、弹窗等）"""

    context_menu: Optional[Dict[str, Any]] = None
    modal: Optional[Dict[str, Any]] = None
    toasts: List[Dict[str, Any]] = field(default_factory=list)
    tooltip: Optional[Dict[str, Any]] = None


@dataclass
class ChatApplicationState(ApplicationState):
    """聊天应用状态 - 扩展基础应用状态

    在 ApplicationState 基础上添加IM特有状态。

    Attributes:
        # 继承自 ApplicationState:
        # - window: WindowState
        # - current_view: str
        # - focused_element_id: str
        # - timestamp: float
        # - step_count: int

        contacts: 联系人列表
        contacts_scroll_offset: 联系人列表滚动偏移

        conversations: 会话列表
        conversations_scroll_offset: 会话列表滚动偏移
        selected_conversation_id: 选中的会话ID
        selected_conversation_index: 选中的会话列表下标（0 开始）

        current_conversation: 当前打开的会话对象
        chat_window: 聊天窗口状态（输入框等）

        search_query: 搜索框内容
        search_results: 搜索结果
        search_selected_index: 搜索结果选中项

        overlays: 浮层状态
    """

    # 联系人
    contacts: List[Contact] = field(default_factory=list)
    contacts_scroll_offset: int = 0

    # 会话
    conversations: List[Conversation] = field(default_factory=list)
    conversations_scroll_offset: int = 0
    selected_conversation_id: Optional[str] = None
    selected_conversation_index: Optional[int] = None

    # 最近发送内容（Hook 用）
    last_sent_text: Optional[str] = None

    # 当前会话
    current_conversation: Optional[Conversation] = None
    chat_window: ChatWindowState = field(default_factory=ChatWindowState)

    # 搜索
    search_query: str = ""
    search_results: List[Dict[str, Any]] = field(default_factory=list)
    search_selected_index: Optional[int] = None

    # 浮层
    overlays: OverlayState = field(default_factory=OverlayState)


# ============ IM特有任务类型 ============


class ChatTaskType(Enum):
    """IM任务类型枚举"""

    OPEN_CONVERSATION = "open_conversation"
    SEARCH_GROUP = "search_group"
    SEARCH_AND_OPEN = "search_and_open"
    SEND_TEXT_MESSAGE = "send_text_message"
    SEND_FILE = "send_file"
    FORWARD_MESSAGE = "forward_message"
    REPLY_TO_MESSAGE = "reply_to_message"
    DELETE_MESSAGE = "delete_message"
    PIN_CONVERSATION = "pin_conversation"
    SEARCH_MESSAGE = "search_message"


class ChatApplication(BaseApplication):
    """聊天软件抽象基类

    职责:
    1. 管理IM特有数据结构（联系人、会话、消息）
    2. 实现IM通用交互逻辑（打开会话、发送消息等）
    3. 提供IM任务的成功判定和奖励计算
    4. 定义IM特有的界面状态和交互

    子类需实现:
    - 具体UI渲染（微信风格、QQ风格等）
    - 特有交互组件（朋友圈、群等级等）
    - 视觉配置和主题

    Attributes:
        _current_user_id: 当前用户ID
        _current_user_name: 当前用户显示名
    """

    # 支持的视图
    VIEWS = ["main", "chat", "search", "contacts", "settings", "profile"]

    def __init__(
        self,
        window_title: str = "ChatApp",
        window_size: Tuple[int, int] = (1200, 800),
        debug_mode: bool = False,
        **kwargs,
    ):
        super().__init__(window_title, window_size, debug_mode, **kwargs)

        # IM特有配置
        self._current_user_id = kwargs.get("user_id", "self")
        self._current_user_name = kwargs.get("user_name", "Me")

        # 布局配置（子类可覆盖）
        self._layout_config = {
            "sidebar_width": 64,
            "conversation_list_width": 280,
            "min_conversation_item_height": 60,
        }

    def _init_subclass(self, **kwargs) -> None:
        """子类初始化钩子"""
        pass

    # ==================== 数据生成接口 ====================

    @abstractmethod
    def generate_contacts(self, count: int, seed: int) -> List[Contact]:
        """生成联系人列表

        子类实现具体的联系人数据生成逻辑。

        Args:
            count: 联系人数量
            seed: 随机种子

        Returns:
            联系人列表
        """
        pass

    @abstractmethod
    def generate_conversations(
        self, contacts: List[Contact], seed: int
    ) -> List[Conversation]:
        """生成会话列表

        根据联系人列表生成会话数据。

        Args:
            contacts: 联系人列表
            seed: 随机种子

        Returns:
            会话列表
        """
        pass

    @abstractmethod
    def generate_messages(
        self, conversation: Conversation, count: int, seed: int
    ) -> List[Message]:
        """生成消息历史

        为指定会话生成消息记录。

        Args:
            conversation: 目标会话
            count: 消息数量
            seed: 随机种子

        Returns:
            消息列表
        """
        pass

    # ==================== IM核心操作接口 ====================

    def open_conversation(self, conversation_id: str) -> bool:
        """打开指定会话

        公用接口，内部调用子类实现。

        Args:
            conversation_id: 会话ID

        Returns:
            是否成功打开
        """
        if not isinstance(self._state, ChatApplicationState):
            return False

        return self._on_open_conversation(conversation_id)

    @abstractmethod
    def _on_open_conversation(self, conversation_id: str) -> bool:
        """子类实现：打开会话的具体逻辑"""
        pass

    def search_contacts(self, query: str) -> List[Contact]:
        """搜索联系人/会话

        Args:
            query: 搜索关键词

        Returns:
            匹配的联系人列表
        """
        return self._on_search_contacts(query)

    @abstractmethod
    def _on_search_contacts(self, query: str) -> List[Contact]:
        """子类实现：搜索逻辑"""
        pass

    def send_message(
        self,
        conversation_id: str,
        content: str,
        msg_type: MessageType = MessageType.TEXT,
    ) -> bool:
        """发送消息

        Args:
            conversation_id: 目标会话ID
            content: 消息内容
            msg_type: 消息类型

        Returns:
            是否成功发送
        """
        return self._on_send_message(conversation_id, content, msg_type)

    def _on_send_message(
        self, conversation_id: str, content: str, msg_type: MessageType
    ) -> bool:
        """默认实现：发送消息逻辑

        子类可覆盖，或直接使用此默认实现。
        """        
        if not isinstance(self._state, ChatApplicationState):
            return False

        # 创建新消息
        new_msg = Message(
            id=f"msg_{conversation_id}_{self._step_count}_{self._rng.randint(1000, 9999)}",
            conversation_id=conversation_id,
            sender_id=self._current_user_id,
            sender_name=self._current_user_name,
            type=msg_type,
            content=self._create_message_content(content, msg_type),
            timestamp=datetime.now(),
            status=MessageStatus.SENT,
        )

        # 添加到会话
        for conv in self._state.conversations:
            if conv.id == conversation_id:
                conv.messages.append(new_msg)
                conv.last_message_preview = self._get_message_preview(new_msg)
                conv.last_message_timestamp = new_msg.timestamp
                self._state.last_sent_text = content

                # 如果当前打开着这个会话，也要更新current_conversation
                if (
                    self._state.current_conversation
                    and self._state.current_conversation.id == conversation_id
                ):
                    self._state.current_conversation.messages.append(new_msg)

                return True

        return False

    def _create_message_content(
        self, content: str, msg_type: MessageType
    ) -> Dict[str, Any]:
        """创建消息内容字典"""
        if msg_type == MessageType.TEXT:
            return {"text": content}
        elif msg_type == MessageType.FILE:
            return {
                "filename": content,
                "size": self._rng.randint(1024, 10485760),  # 1KB - 10MB
                "url": f"file://{content}",
            }
        elif msg_type == MessageType.IMAGE:
            return {"url": content, "width": 800, "height": 600}
        else:
            return {"text": content}

    def _get_message_preview(self, message: Message) -> str:
        """获取消息预览文本"""
        if message.type == MessageType.TEXT:
            text = message.content.get("text", "")
            return text[:30] + "..." if len(text) > 30 else text
        elif message.type == MessageType.IMAGE:
            return "[图片]"
        elif message.type == MessageType.FILE:
            return f"[文件] {message.content.get('filename', '')}"
        elif message.type == MessageType.VOICE:
            return "[语音]"
        elif message.type == MessageType.SYSTEM:
            return message.content.get("text", "[系统消息]")
        else:
            return "[消息]"

    def forward_message(self, message_id: str, target_conversation_id: str) -> bool:
        """转发消息

        Args:
            message_id: 要转发的消息ID
            target_conversation_id: 目标会话ID

        Returns:
            是否成功转发
        """
        return self._on_forward_message(message_id, target_conversation_id)

    @abstractmethod
    def _on_forward_message(self, message_id: str, target_conversation_id: str) -> bool:
        """子类实现：转发逻辑"""
        pass

    # ==================== 动作处理实现 ====================

    def _on_mouse_action(self, mouse_action: MouseAction) -> Dict[str, Any]:
        """处理鼠标动作 - ChatApplication层实现通用IM交互识别"""
        if not isinstance(self._state, ChatApplicationState):
            return {"success": False, "message": "Invalid state", "effects": []}

        # 将物理坐标转换为UI元素
        element = self._hit_test(mouse_action.coordinate)

        if element is None:
            return {
                "success": False,
                "message": "No element at coordinate",
                "effects": [],
            }

        if self.debug_mode:
            print(
                f"[Mouse] Hit: {element.get('type', 'unknown')} at "
                f"({mouse_action.coordinate.x:.3f}, {mouse_action.coordinate.y:.3f})"
            )

        # 根据元素类型和鼠标动作类型执行相应逻辑
        result = self._handle_element_interaction(element, mouse_action)

        return result

    @abstractmethod
    def _hit_test(self, coordinate: Coordinate) -> Optional[Dict[str, Any]]:
        """测试坐标命中的UI元素

        子类实现具体的碰撞检测，返回元素信息字典:
        {
            "type": "conversation_item|message_item|button|input|...",
            "id": "element_id",
            "bounds": (x, y, width, height),
            "data": {},  # 额外数据
        }
        """
        pass

    @abstractmethod
    def _handle_element_interaction(
        self, element: Dict[str, Any], mouse_action: MouseAction
    ) -> Dict[str, Any]:
        """处理元素交互

        子类实现具体的交互逻辑。
        """
        pass

    def _on_keyboard_action(self, keyboard_action: KeyboardAction) -> Dict[str, Any]:
        """处理键盘动作 - ChatApplication层实现通用逻辑"""
        if not isinstance(self._state, ChatApplicationState):
            return {"success": False, "message": "Invalid state", "effects": []}

        # 检查是否处于可输入状态
        if self._state.chat_window.is_recording_voice:
            return {
                "success": False,
                "message": "Cannot type while recording",
                "effects": [],
            }

        # 分派到具体处理器
        if keyboard_action.subtype == KeyboardActionType.TYPE_TEXT:
            return self._handle_type_text(keyboard_action.text or "")

        elif keyboard_action.subtype == KeyboardActionType.KEY_PRESS:
            return self._handle_key_press(keyboard_action.key or "")

        elif keyboard_action.subtype == KeyboardActionType.KEY_SEQUENCE:
            # 顺序执行每个按键
            effects = []
            for key in keyboard_action.keys:
                result = self._handle_key_press(key)
                effects.extend(result.get("effects", []))
            return {"success": True, "message": "", "effects": effects}

        elif keyboard_action.subtype == KeyboardActionType.HOTKEY:
            return self._handle_hotkey(keyboard_action.keys)

        else:
            return {
                "success": False,
                "message": "Unknown keyboard action",
                "effects": [],
            }

    def _handle_type_text(self, text: str) -> Dict[str, Any]:
        """处理文本输入"""
        # 搜索态输入优先写入 search_query，保证 search_and_open 任务可闭环。
        if self._state.current_view == "search":
            self._state.search_query += text
            self._state.search_results = [
                {
                    "conversation_id": contact.id,
                    "display_name": contact.name,
                    "contact_type": contact.type.value,
                }
                for contact in self._on_search_contacts(self._state.search_query)
                if isinstance(contact, Contact)
            ]
            self._state.search_selected_index = (
                0
                if self._state.search_results
                else None
            )
            return {
                "success": True,
                "message": "",
                "effects": ["search_input_changed", "search_updated"],
            }

        self._state.chat_window.input_text += text
        self._state.chat_window.input_cursor_pos = len(
            self._state.chat_window.input_text
        )

        return {"success": True, "message": "", "effects": ["input_changed"]}

    def _handle_key_press(self, key: str) -> Dict[str, Any]:
        """处理按键"""
        key_lower = key.lower()

        # Enter: 发送消息（如果有内容且当前在聊天视图）
        if key_lower in ("return", "enter"):
            # 搜索视图：执行搜索并打开首个结果。
            if self._state.current_view == "search":
                if not self._state.search_query:
                    return {"success": True, "message": "Search query empty", "effects": []}

                if not self._state.search_results:
                    # 尝试用当前 query 实时刷新一次，减少输入与渲染不同步问题。
                    self._state.search_results = [
                        {
                            "conversation_id": contact.id,
                            "display_name": contact.name,
                            "contact_type": contact.type.value,
                        }
                        for contact in self._on_search_contacts(self._state.search_query)
                        if isinstance(contact, Contact)
                    ]

                if not self._state.search_results:
                    return {
                        "success": False,
                        "message": "No search result",
                        "effects": ["search_no_result"],
                    }

                first = self._state.search_results[0]
                if not isinstance(first, dict):
                    return {"success": False, "message": "Malformed search result", "effects": []}

                target_id = first.get("conversation_id")
                if not isinstance(target_id, str):
                    return {"success": False, "message": "Malformed search result", "effects": []}

                self._state.search_selected_index = 0
                success = self.open_conversation(target_id)
                if not success:
                    return {
                        "success": False,
                        "message": "Conversation not found",
                        "effects": ["search_open_failed"],
                    }

                return {
                    "success": True,
                    "message": "Search conversation opened",
                    "effects": ["search_opened", "conversation_opened"],
                }

            if (
                self._state.current_view == "chat"
                and self._state.current_conversation
                and self._state.chat_window.input_text.strip()
            ):
                success = self.send_message(
                    self._state.current_conversation.id,
                    self._state.chat_window.input_text,
                    MessageType.TEXT,
                )

                if success:
                    self._state.chat_window.input_text = ""
                    self._state.chat_window.input_cursor_pos = 0
                    return {
                        "success": True,
                        "message": "Message sent",
                        "effects": ["message_sent"],
                    }

            return {"success": True, "message": "", "effects": []}

        # Backspace: 删除字符
        elif key_lower == "backspace":
            if self._state.current_view == "search":
                if not self._state.search_query:
                    return {"success": True, "message": "", "effects": ["input_changed"]}

                self._state.search_query = self._state.search_query[:-1]
                self._state.search_results = [
                    {
                        "conversation_id": contact.id,
                        "display_name": contact.name,
                        "contact_type": contact.type.value,
                    }
                    for contact in self._on_search_contacts(self._state.search_query)
                    if isinstance(contact, Contact)
                ]
                self._state.search_selected_index = (
                    0 if self._state.search_results else None
                )
                return {"success": True, "message": "", "effects": ["search_input_changed", "search_updated"]}

            if (
                self._state.chat_window.input_text
                and self._state.chat_window.input_cursor_pos > 0
            ):
                pos = self._state.chat_window.input_cursor_pos
                text = self._state.chat_window.input_text
                self._state.chat_window.input_text = text[: pos - 1] + text[pos:]
                self._state.chat_window.input_cursor_pos -= 1
            return {"success": True, "message": "", "effects": ["input_changed"]}

        # Delete: 删除光标后字符
        elif key_lower == "delete":
            if self._state.chat_window.input_text:
                pos = self._state.chat_window.input_cursor_pos
                text = self._state.chat_window.input_text
                if pos < len(text):
                    self._state.chat_window.input_text = text[:pos] + text[pos + 1 :]
            return {"success": True, "message": "", "effects": ["input_changed"]}

        # Esc: 关闭弹窗/退出当前状态
        elif key_lower == "escape":
            if self._state.overlays.context_menu:
                self._state.overlays.context_menu = None
                return {"success": True, "message": "", "effects": ["menu_closed"]}
            if self._state.overlays.modal:
                self._state.overlays.modal = None
                return {"success": True, "message": "", "effects": ["modal_closed"]}
            return {"success": True, "message": "", "effects": []}

        # 普通字符输入
        else:
            # 只接受单字符按键（过滤功能键）
            if len(key) == 1 and key.isprintable():
                self._state.chat_window.input_text += key
                self._state.chat_window.input_cursor_pos = len(
                    self._state.chat_window.input_text
                )
                return {"success": True, "message": "", "effects": ["input_changed"]}

            return {"success": True, "message": "", "effects": []}

    def _handle_hotkey(self, keys: List[str]) -> Dict[str, Any]:
        """处理组合键"""
        # TODO: 实现常用快捷键，如 Ctrl+Enter 发送，Ctrl+A 全选等
        return {"success": True, "message": "Hotkey not implemented", "effects": []}

    def _on_step(
        self, action: Action, action_result: Dict[str, Any]
    ) -> ChatApplicationState:
        """状态更新 - 返回新状态"""
        # ChatApplication层只需复制当前状态
        # 具体状态变更在动作处理时已完成
        new_state = copy.deepcopy(self._state)
        new_state.step_count = self._step_count
        new_state.timestamp = action.timestamp
        return new_state

    # ==================== 视图状态管理 ====================

    def switch_view(self, view_name: str) -> bool:
        """切换视图

        Args:
            view_name: 视图名称

        Returns:
            是否成功切换
        """
        if view_name not in self.VIEWS:
            if self.debug_mode:
                print(f"[View] Unknown view: {view_name}")
            return False

        if isinstance(self._state, ChatApplicationState):
            old_view = self._state.current_view
            self._state.current_view = view_name

            if self.debug_mode:
                print(f"[View] Switched: {old_view} -> {view_name}")
            return True

        return False

    # ==================== 奖励计算特化 ====================

    def _compute_progress_reward(
        self, prev_state: ApplicationState, new_state: ApplicationState
    ) -> float:
        """计算IM类任务的进度奖励"""
        if not isinstance(prev_state, ChatApplicationState) or not isinstance(
            new_state, ChatApplicationState
        ):
            return 0.0

        reward = 0.0

        if self._current_task is None:
            return 0.0

        # 获取任务类型字符串
        task_type_str = (
            self._current_task.task_type.value
            if hasattr(self._current_task.task_type, "value")
            else str(self._current_task.task_type)
        )

        # 打开会话任务
        if task_type_str == ChatTaskType.OPEN_CONVERSATION.value:
            target_id = self._current_task.target.get("conversation_id")
            if (
                prev_state.selected_conversation_id != target_id
                and new_state.selected_conversation_id == target_id
            ):
                reward += 2.0

        # 发送消息任务
        elif task_type_str == ChatTaskType.SEND_TEXT_MESSAGE.value:
            target_content = self._current_task.target.get("content", "")
            target_conv = self._current_task.target.get("conversation_id")

            # 检查是否发送了正确内容
            if (
                new_state.current_conversation
                and new_state.current_conversation.id == target_conv
            ):
                for msg in new_state.current_conversation.messages[-5:]:
                    if (
                        msg.sender_id == self._current_user_id
                        and msg.content.get("text") == target_content
                    ):
                        reward += 3.0
                        break
                else:
                    # 发送了消息但内容不匹配
                    if (
                        new_state.current_conversation.messages
                        and new_state.current_conversation.messages[-1].sender_id
                        == self._current_user_id
                    ):
                        reward -= 1.0

        # 搜索并打开任务
        elif task_type_str == ChatTaskType.SEARCH_AND_OPEN.value:
            if (
                prev_state.current_view == "search"
                and new_state.current_view == "chat"
                and new_state.selected_conversation_id
            ):
                reward += 2.5
        elif task_type_str == ChatTaskType.SEARCH_GROUP.value:
            target_contact = self._current_task.target.get("target_contact") or self._current_task.target.get("contact_name")
            target_position = self._current_task.target.get("target_position")

            if new_state.current_view == "chat" and new_state.current_conversation:
                conv = new_state.current_conversation
                if conv.contact_type != ContactType.GROUP:
                    return 0.0
                if target_contact and conv.display_name == target_contact:
                    reward += 2.5
                elif target_position is not None and new_state.selected_conversation_index == target_position:
                    reward += 2.5

        # TODO: 其他任务类型的进度奖励

        return reward

    # ==================== 任务成功判定 ====================

    def _check_termination(self, state: ApplicationState) -> Tuple[bool, bool]:
        """检查IM类任务的终止条件"""
        if not isinstance(state, ChatApplicationState):
            return False, False

        if self._current_task is None:
            return False, False

        # 检查成功条件
        if self._check_task_success(state):
            return True, True

        # 检查失败条件
        if self._check_task_failure(state):
            return True, False

        return False, False

    def _check_task_success(self, state: ChatApplicationState) -> bool:
        """检查任务是否成功完成"""
        task_type_str = (
            self._current_task.task_type.value
            if hasattr(self._current_task.task_type, "value")
            else str(self._current_task.task_type)
        )

        # 打开会话任务
        if task_type_str == ChatTaskType.OPEN_CONVERSATION.value:
            target_id = self._current_task.target.get("conversation_id")
            return (
                state.current_view == "chat"
                and state.selected_conversation_id == target_id
            )

        # 发送消息任务
        elif task_type_str == ChatTaskType.SEND_TEXT_MESSAGE.value:
            target_content = self._current_task.target.get("content", "")
            target_conv = self._current_task.target.get("conversation_id")

            if (
                state.current_conversation
                and state.current_conversation.id == target_conv
            ):
                for msg in state.current_conversation.messages:
                    if (
                        msg.sender_id == self._current_user_id
                        and msg.content.get("text") == target_content
                    ):
                        return True
            return False

        # 搜索并打开任务
        elif task_type_str == ChatTaskType.SEARCH_AND_OPEN.value:
            target_contact = self._current_task.target.get("target_contact")
            if target_contact is None:
                target_contact = self._current_task.target.get("contact_name")
            if state.current_view == "chat" and state.current_conversation:
                return state.current_conversation.display_name == target_contact
            return False
        elif task_type_str == ChatTaskType.SEARCH_GROUP.value:
            target_contact = self._current_task.target.get("target_contact") or self._current_task.target.get("contact_name")
            target_position = self._current_task.target.get("target_position")

            if state.current_view != "chat" or state.current_conversation is None:
                return False

            if state.current_conversation.contact_type != ContactType.GROUP:
                return False
            if target_contact:
                return state.current_conversation.display_name == target_contact
            if target_position is not None:
                return state.selected_conversation_index == target_position
            return False

        # 默认检查配置文件中的条件
        return self._evaluate_config_conditions(
            self._current_task.success_conditions, state
        )

    def _check_task_failure(self, state: ChatApplicationState) -> bool:
        """检查任务是否失败"""
        # TODO: 实现具体的失败条件检查
        # 例如：发送到错误会话、删除了重要消息等
        return self._evaluate_config_conditions(
            self._current_task.failure_conditions, state
        )

    def _evaluate_config_conditions(
        self, conditions: List[Dict], state: ChatApplicationState
    ) -> bool:
        """评估配置中的条件列表"""
        if not conditions:
            return False

        for condition in conditions:
            if not self._evaluate_single_condition(condition, state):
                return False

        return True

    def _evaluate_single_condition(
        self, condition: Dict, state: ChatApplicationState
    ) -> bool:
        """评估单个条件"""
        condition_type = condition.get("type", "state_check")

        if condition_type == "state_check":
            field = condition.get("field", "")
            operator = condition.get("operator", "equals")
            value = condition.get("value")

            actual_value = self._get_nested_attr(state, field)

            if operator == "equals":
                return actual_value == value
            elif operator == "not_equals":
                return actual_value != value
            elif operator == "in":
                return (
                    actual_value in value if isinstance(value, (list, tuple)) else False
                )
            elif operator == "not_in":
                return (
                    actual_value not in value
                    if isinstance(value, (list, tuple))
                    else True
                )
            elif operator == "exists":
                return actual_value is not None

        elif condition_type == "message_exists":
            # 检查消息是否存在
            conv_id = condition.get("conversation_id")
            content_pattern = condition.get("content_pattern")
            # TODO: 实现消息内容匹配
            pass

        # 默认返回False（未满足）
        return False

    def _get_nested_attr(self, obj: Any, path: str) -> Any:
        """获取嵌套属性"""
        if not path:
            return None

        parts = path.split(".")
        current = obj

        for part in parts:
            if current is None:
                return None

            if isinstance(current, dict):
                current = current.get(part)
            elif hasattr(current, part):
                current = getattr(current, part)
            else:
                return None

        return current

    # ==================== 随机化 ====================

    def _on_randomization(self, config: Dict[str, Any]) -> None:
        """应用IM特有的随机化"""
        if not isinstance(self._state, ChatApplicationState):
            return

        level = config.get("level", "minimal")

        # 会话顺序随机化
        if config.get("shuffle_conversations", False) or level in [
            "standard",
            "aggressive",
        ]:
            # 保持置顶项在前，其他随机排序
            pinned = [c for c in self._state.conversations if c.is_pinned]
            others = [c for c in self._state.conversations if not c.is_pinned]
            self._rng.shuffle(others)
            self._state.conversations = pinned + others

        # 联系人顺序随机化
        if config.get("shuffle_contacts", False) or level == "aggressive":
            self._rng.shuffle(self._state.contacts)

        # 未读状态随机化
        if config.get("randomize_unread", False) or level == "aggressive":
            for conv in self._state.contacts:
                conv.unread_count = (
                    self._rng.randint(0, 10) if self._rng.random() < 0.3 else 0
                )

        # 初始滚动位置随机化
        if config.get("randomize_scroll", False) or level == "aggressive":
            max_conv_scroll = max(0, len(self._state.conversations) - 10)
            if max_conv_scroll > 0:
                self._state.conversations_scroll_offset = self._rng.randint(
                    0, max_conv_scroll
                )

        # 相似名称干扰
        if config.get("similar_names", False):
            # 确保目标联系人有相似名称的干扰项
            pass  # TODO: 在数据生成阶段处理

    # ==================== 调试接口 ====================

    def _on_get_legal_actions(self) -> List[Action]:
        """返回当前合法动作 - IM特化版"""
        # 这是一个简化实现，返回一些预定义的动作
        # 实际应用中可能需要根据当前状态动态生成
        from vibe.core.shared_types import ActionType, MouseAction, MouseActionType

        legal_actions = []

        if not isinstance(self._state, ChatApplicationState):
            return legal_actions

        # 总是可以移动鼠标
        legal_actions.append(
            Action(
                type=ActionType.MOUSE,
                mouse_action=MouseAction(
                    subtype=MouseActionType.MOVE, coordinate=Coordinate(x=0.5, y=0.5)
                ),
            )
        )

        # 根据当前视图添加特定动作
        if self._state.current_view == "main":
            # 可以点击查看会话
            for i, conv in enumerate(self._state.conversations[:10]):
                # 计算会话项的位置（简化版）
                y_pos = 0.1 + i * 0.1
                legal_actions.append(
                    Action(
                        type=ActionType.MOUSE,
                        mouse_action=MouseAction(
                            subtype=MouseActionType.CLICK,
                            coordinate=Coordinate(x=0.3, y=y_pos),
                        ),
                    )
                )

        elif self._state.current_view == "chat":
            # 可以点击输入框
            legal_actions.append(
                Action(
                    type=ActionType.MOUSE,
                    mouse_action=MouseAction(
                        subtype=MouseActionType.CLICK,
                        coordinate=Coordinate(x=0.7, y=0.9),
                    ),
                )
            )

        return legal_actions

    def get_contact_by_id(self, contact_id: str) -> Optional[Contact]:
        """根据ID获取联系人"""
        if not isinstance(self._state, ChatApplicationState):
            return None

        for contact in self._state.contacts:
            if contact.id == contact_id:
                return contact
        return None

    def get_conversation_by_id(self, conversation_id: str) -> Optional[Conversation]:
        """根据ID获取会话"""
        if not isinstance(self._state, ChatApplicationState):
            return None

        for conv in self._state.conversations:
            if conv.id == conversation_id:
                return conv
        return None

"""Base Application - Generic Desktop Application Interface

所有仿真应用的抽象基类，定义通用生命周期和动作处理接口。
与 OpenAI Gym/Gymnasium 环境接口兼容。
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Tuple, Optional, List
import time
import copy
import numpy as np
from dataclasses import dataclass

from vibe.core.shared_types import (
    Action,
    ActionType,
    MouseAction,
    KeyboardAction,
    Observation,
    RewardComponents,
    TaskConfig,
    ApplicationState,
    WindowState,
    ActionConverter,
)


class BaseApplication(ABC):
    """通用桌面应用抽象基类

    架构设计原则:
    1. 单一职责: 只关注应用本身，截图由外部系统负责
    2. 状态驱动: 所有界面变化由状态变化驱动
    3. 可观测性: 提供完整内部状态用于调试，但训练时模型不可见
    4. 可复现性: 支持随机种子控制，确保实验可复现

    职责范围:
    ✓ 应用生命周期 (initialize, reset, step, close)
    ✓ 标准动作处理 (鼠标, 键盘)
    ✓ 窗口状态和基础状态机
    ✓ 奖励计算框架
    ✓ 内部状态管理

    非职责 (由子类实现):
    ✗ 具体UI渲染
    ✗ 具体业务逻辑
    ✗ 具体任务定义

    Attributes:
        window_title: 应用窗口标题
        window_size: 窗口初始尺寸 (width, height)
        debug_mode: 是否开启调试模式
        _state: 当前应用状态
        _is_initialized: 是否已初始化
        _is_running: 是否正在运行
        _current_task: 当前任务配置
        _step_count: 当前episode步数
        _action_history: 动作历史记录
        _state_history: 状态历史记录
        _rng: 随机数生成器
    """

    def __init__(
        self,
        window_title: str = "VibeApp",
        window_size: Tuple[int, int] = (1200, 800),
        debug_mode: bool = False,
        **kwargs,
    ):
        """
        Args:
            window_title: 应用窗口标题
            window_size: 初始窗口大小 (width, height)
            debug_mode: 是否开启调试模式（影响日志和额外信息输出）
            **kwargs: 子类特定参数
        """
        self.window_title = window_title
        self.window_size = window_size
        self.debug_mode = debug_mode

        # 核心状态
        self._state: Optional[ApplicationState] = None
        self._is_initialized = False
        self._is_running = False
        self._current_task: Optional[TaskConfig] = None
        self._step_count = 0
        self._episode_start_time = 0.0

        # 历史记录
        self._action_history: List[Action] = []
        self._state_history: List[ApplicationState] = []

        # 随机化 - 使用numpy.RandomState以保证可复现性
        self._rng = np.random.RandomState()

        # 子类初始化
        self._init_subclass(**kwargs)

    def _init_subclass(self, **kwargs) -> None:
        """子类初始化钩子 - 子类可覆盖"""
        pass

    # ==================== 生命周期方法 ====================

    def initialize(self) -> bool:
        """初始化应用 - 启动GUI，准备运行

        这是应用启动的第一步。子类应在此方法中:
        1. 初始化GUI框架
        2. 创建窗口
        3. 准备渲染资源

        Returns:
            bool: 初始化是否成功
        """
        if self._is_initialized:
            if self.debug_mode:
                print(f"[{self.window_title}] Already initialized")
            return True

        if self.debug_mode:
            print(f"[{self.window_title}] Initializing...")

        try:
            success = self._on_initialize()
            if success:
                self._is_initialized = True
                self._is_running = True
                if self.debug_mode:
                    print(f"[{self.window_title}] Initialization successful")
            else:
                if self.debug_mode:
                    print(f"[{self.window_title}] Initialization failed")
            return success
        except Exception as e:
            if self.debug_mode:
                print(f"[{self.window_title}] Initialization error: {e}")
            return False

    @abstractmethod
    def _on_initialize(self) -> bool:
        """子类实现具体的初始化逻辑

        Returns:
            bool: 初始化是否成功
        """
        pass

    def reset(
        self,
        task_config: Optional[TaskConfig] = None,
        seed: Optional[int] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> Tuple[ApplicationState, Dict[str, Any]]:
        """重置环境到新episode

        这是训练的核心方法。每个episode开始时调用，将应用
        重置到指定任务的初始状态。

        Args:
            task_config: 任务配置，包含任务类型、初始状态等。
                        None时使用默认任务。
            seed: 随机种子，用于确保初始状态可复现。
            options: 额外选项，如初始状态覆盖、特殊配置等。

        Returns:
            Tuple of:
            - state: 初始应用状态（调试用，训练时不应直接发给模型）
            - info: 初始化信息，包含任务描述、窗口位置等

        Note:
            外部系统通过截图获取观测，此处返回的state仅用于
            调试和验证。
        """
        if not self._is_initialized:
            if not self.initialize():
                raise RuntimeError("Failed to initialize application")

        options = options or {}

        # 设置随机种子
        if seed is not None:
            self._rng = np.random.RandomState(seed)
            if self.debug_mode:
                print(f"[{self.window_title}] Random seed set: {seed}")

        # 重置历史
        self._action_history.clear()
        self._state_history.clear()
        self._step_count = 0
        self._episode_start_time = time.time()

        # 保存任务配置
        self._current_task = task_config or self._create_default_task()
        if self.debug_mode:
            task_type = (
                self._current_task.task_type.value
                if isinstance(self._current_task.task_type, type)
                and hasattr(self._current_task.task_type, "value")
                else str(self._current_task.task_type)
            )
            print(
                f"[{self.window_title}] Task: {task_type}, "
                f"Difficulty: {self._current_task.difficulty}"
            )

        # 执行子类特定的reset，生成初始状态
        try:
            state = self._on_reset(self._current_task, options)
            self._state = state
        except Exception as e:
            if self.debug_mode:
                print(f"[{self.window_title}] Reset error: {e}")
            raise

        # 应用随机化
        if self._current_task.randomization:
            self._apply_randomization(self._current_task.randomization)
        elif options.get("randomization"):
            self._apply_randomization(options["randomization"])

        # 记录初始状态
        self._state_history.append(state.copy())

        # 渲染初始状态到屏幕
        try:
            self.render()
        except Exception as e:
            if self.debug_mode:
                print(f"[{self.window_title}] Initial render warning: {e}")

        # 构建返回信息
        info = self._create_reset_info()

        return state, info

    @abstractmethod
    def _on_reset(
        self, task_config: TaskConfig, options: Dict[str, Any]
    ) -> ApplicationState:
        """子类实现具体的reset逻辑

        此方法必须:
        1. 创建并返回初始状态对象
        2. 根据task_config设置初始视图和数据
        3. 应用options中的特殊配置

        Args:
            task_config: 任务配置
            options: 额外选项

        Returns:
            ApplicationState: 初始状态对象
        """
        pass

    def _create_default_task(self) -> TaskConfig:
        """创建默认任务

        当不提供task_config时使用。子类可覆盖以定义应用默认行为。

        Returns:
            TaskConfig: 默认任务配置
        """
        return TaskConfig(
            task_type="default",
            description="Default exploration task",
            max_steps=50,
            reward_config={
                "success_reward": 10.0,
                "failure_penalty": -5.0,
                "step_penalty": -0.01,
            },
        )

    def step(
        self, action: Action
    ) -> Tuple[
        ApplicationState,  # 新状态
        RewardComponents,  # 奖励分解
        bool,  # done
        bool,  # truncated
        Dict[str, Any],  # info
    ]:
        """执行动作，推进环境状态

        这是训练循环的核心方法。每个训练步骤调用一次。

        执行流程:
        1. 验证动作
        2. 保存当前状态（用于奖励计算）
        3. 执行动作并获取结果
        4. 更新状态
        5. 记录历史
        6. 检查终止条件
        7. 计算奖励
        8. 渲染新状态

        Args:
            action: 动作对象，包含动作类型和参数

        Returns:
            Tuple of:
            - state: 新应用状态
            - reward_components: 奖励分解（调试用）
            - done: 是否完成（成功或失败）
            - truncated: 是否截断（如达到最大步数）
            - info: 附加信息

        Raises:
            RuntimeError: 如果应用未运行
        """
        if not self._is_running:
            raise RuntimeError(
                f"Application '{self.window_title}' not running. Call reset() first."
            )

        self._step_count += 1
        action.timestamp = time.time()

        if self.debug_mode:
            action_type = (
                action.type.name if hasattr(action.type, "name") else str(action.type)
            )
            print(f"[{self.window_title}] Step {self._step_count}: {action_type}")

        # 保存动作前状态用于奖励计算
        prev_state = self._state.copy() if self._state else None

        # 执行动作
        try:
            action_result = self._execute_action(action)
        except Exception as e:
            if self.debug_mode:
                print(f"[{self.window_title}] Action execution error: {e}")
            action_result = {"success": False, "message": str(e), "effects": []}

        # 更新状态
        try:
            new_state = self._on_step(action, action_result)
            self._state = new_state
        except Exception as e:
            if self.debug_mode:
                print(f"[{self.window_title}] State update error: {e}")
            raise

        # 记录历史
        self._action_history.append(action)
        self._state_history.append(new_state.copy())

        # 检查终止条件
        try:
            done, success = self._check_termination(new_state)
        except Exception as e:
            if self.debug_mode:
                print(f"[{self.window_title}] Termination check error: {e}")
            done, success = False, False

        # 检查是否达到最大步数
        max_steps = self._current_task.max_steps if self._current_task else 50
        truncated = self._step_count >= max_steps

        if truncated and not done:
            done = True  # 截断也算终止

        # 计算奖励
        try:
            reward_components = self._compute_reward(
                prev_state, action, new_state, done, success
            )
        except Exception as e:
            if self.debug_mode:
                print(f"[{self.window_title}] Reward calculation error: {e}")
            reward_components = RewardComponents()

        # 渲染
        try:
            self.render()
        except Exception as e:
            if self.debug_mode:
                print(f"[{self.window_title}] Render warning: {e}")

        # 构建信息
        info = self._create_step_info(action, action_result, success)

        return new_state, reward_components, done, truncated, info

    def _execute_action(self, action: Action) -> Dict[str, Any]:
        """派遣并执行动作

        根据动作类型分派到对应的处理器。

        Args:
            action: 动作对象

        Returns:
            动作执行结果字典:
            - success: bool, 是否成功执行
            - message: str, 描述信息或错误信息
            - effects: List[str], 副作用列表（如状态变更）
        """
        result = {"success": True, "message": "", "effects": []}

        try:
            if action.type == ActionType.MOUSE and action.mouse_action:
                result = self._handle_mouse_action(action.mouse_action)
            elif action.type == ActionType.KEYBOARD and action.keyboard_action:
                result = self._handle_keyboard_action(action.keyboard_action)
            elif action.type == ActionType.SYSTEM:
                result = self._handle_system_action(action)
            else:
                result = {
                    "success": False,
                    "message": f"Invalid action type: {action.type}",
                    "effects": [],
                }
        except Exception as e:
            result = {"success": False, "message": str(e), "effects": []}

        return result

    def _handle_mouse_action(self, mouse_action: MouseAction) -> Dict[str, Any]:
        """处理鼠标动作

        调用子类实现的处理逻辑。

        Args:
            mouse_action: 鼠标动作详情

        Returns:
            执行结果字典
        """
        return self._on_mouse_action(mouse_action)

    @abstractmethod
    def _on_mouse_action(self, mouse_action: MouseAction) -> Dict[str, Any]:
        """子类必须实现：处理鼠标动作

        此方法是动作处理的核心，子类需要:
        1. 将物理坐标映射到UI元素
        2. 根据元素类型和动作类型执行相应逻辑
        3. 更新相关状态

        Args:
            mouse_action: 鼠标动作详情

        Returns:
            执行结果字典
        """
        pass

    def _handle_keyboard_action(
        self, keyboard_action: KeyboardAction
    ) -> Dict[str, Any]:
        """处理键盘动作

        Args:
            keyboard_action: 键盘动作详情

        Returns:
            执行结果字典
        """
        return self._on_keyboard_action(keyboard_action)

    @abstractmethod
    def _on_keyboard_action(self, keyboard_action: KeyboardAction) -> Dict[str, Any]:
        """子类必须实现：处理键盘动作

        实现键盘输入、快捷键等逻辑。

        Args:
            keyboard_action: 键盘动作详情

        Returns:
            执行结果字典
        """
        pass

    def _handle_system_action(self, action: Action) -> Dict[str, Any]:
        """处理系统动作

        如wait、nop等。

        Args:
            action: 动作对象

        Returns:
            执行结果字典
        """
        return {"success": True, "message": "System action executed", "effects": []}

    @abstractmethod
    def _on_step(
        self, action: Action, action_result: Dict[str, Any]
    ) -> ApplicationState:
        """子类实现：执行动作后的状态更新

        此方法应根据动作执行结果返回新状态。
        重要：必须返回新状态对象，不要直接修改self._state！

        Args:
            action: 执行的动作
            action_result: 动作执行结果

        Returns:
            新的应用状态
        """
        pass

    def close(self) -> None:
        """关闭应用，释放资源

        应在训练结束时调用，释放所有资源。
        """
        if self._is_running:
            if self.debug_mode:
                print(f"[{self.window_title}] Closing...")
            try:
                self._on_close()
            except Exception as e:
                if self.debug_mode:
                    print(f"[{self.window_title}] Close error: {e}")
            finally:
                self._is_running = False
                self._is_initialized = False

    @abstractmethod
    def _on_close(self) -> None:
        """子类实现具体的关闭逻辑

        释放GUI资源、清理内存等。
        """
        pass

    # ==================== 状态与终止检查 ====================

    @abstractmethod
    def _check_termination(self, state: ApplicationState) -> Tuple[bool, bool]:
        """检查是否满足终止条件

        基于当前任务配置检查成功/失败条件。

        Args:
            state: 当前应用状态

        Returns:
            Tuple of (done, success):
            - done: 是否终止（成功或失败）
            - success: 是否成功（True=成功, False=失败）
        """
        pass

    # ==================== 奖励计算 ====================

    def _compute_reward(
        self,
        prev_state: Optional[ApplicationState],
        action: Action,
        new_state: ApplicationState,
        done: bool,
        success: bool,
    ) -> RewardComponents:
        """计算奖励

        奖励组成:
        1. base: 基础奖励（通常为0）
        2. progress: 阶段性进度奖励（子类实现）
        3. efficiency: 效率奖励（如快速完成）
        4. penalties: 惩罚（错误动作、时间惩罚等）
        5. terminal: 终局奖励（成功/失败）

        Args:
            prev_state: 动作前状态
            action: 执行的动作
            new_state: 动作后状态
            done: 是否终止
            success: 是否成功

        Returns:
            RewardComponents: 奖励分解
        """
        components = RewardComponents()

        # 基础步数惩罚
        step_penalty = (
            -0.01
            if self._current_task is None
            else self._current_task.reward_config.get("step_penalty", -0.01)
        )
        components.penalties = step_penalty

        # 终局奖励
        if done:
            if success:
                components.terminal = (
                    self._current_task.reward_config.get("success_reward", 10.0)
                    if self._current_task
                    else 10.0
                )
            else:
                components.terminal = (
                    self._current_task.reward_config.get("failure_penalty", -5.0)
                    if self._current_task
                    else -5.0
                )

        # 进度奖励 - 子类实现
        try:
            if prev_state is not None:
                progress_reward = self._compute_progress_reward(prev_state, new_state)
                components.progress = progress_reward
        except Exception as e:
            if self.debug_mode:
                print(f"[{self.window_title}] Progress reward error: {e}")

        return components

    @abstractmethod
    def _compute_progress_reward(
        self, prev_state: ApplicationState, new_state: ApplicationState
    ) -> float:
        """子类实现：计算进度奖励

        根据任务进度计算中间奖励。例如：
        - 成功打开目标会话：+2
        - 开始输入正确内容：+1
        - 完成部分任务目标：+N

        Args:
            prev_state: 动作前状态
            new_state: 动作后状态

        Returns:
            进度奖励值（可正可负）
        """
        pass

    # ==================== 渲染 ====================

    @abstractmethod
    def render(self, mode: str = "human") -> Optional[np.ndarray]:
        """渲染当前状态到屏幕或返回数组

        Args:
            mode:
                - "human": 显示在屏幕上（默认）
                - "rgb_array": 返回RGB numpy数组

        Returns:
            如果 mode="rgb_array"，返回RGB数组 [H, W, 3]
            否则返回 None
        """
        pass

    # ==================== 随机化框架 ====================

    def _apply_randomization(self, randomization_config: Dict[str, Any]) -> None:
        """应用随机化配置

        子类可覆盖此方法以添加特定随机化逻辑。

        Args:
            randomization_config: 随机化配置字典
        """
        randomization_level = randomization_config.get("level", "minimal")

        if randomization_level == "none":
            return

        # 窗口位置随机化（如果配置允许）
        if randomization_config.get("window_position", False):
            if self._state and isinstance(self._state, ApplicationState):
                margin = 50
                max_x = 1920 - self.window_size[0] - margin  # 假设1920x1080屏幕
                max_y = 1080 - self.window_size[1] - margin
                self._state.window.x = self._rng.randint(margin, max(max_x, margin))
                self._state.window.y = self._rng.randint(margin, max(max_y, margin))

        # 调用子类特定的随机化
        try:
            self._on_randomization(randomization_config)
        except Exception as e:
            if self.debug_mode:
                print(f"[{self.window_title}] Randomization error: {e}")

    def _on_randomization(self, config: Dict[str, Any]) -> None:
        """子类实现具体的随机化逻辑

        Args:
            config: 随机化配置
        """
        pass

    # ==================== 信息创建 ====================

    def _create_reset_info(self) -> Dict[str, Any]:
        """创建reset返回的info"""
        info = {
            "task_type": "default",
            "task_description": "",
            "difficulty": 1,
            "max_steps": 50,
            "window_title": self.window_title,
            "window_size": self.window_size,
            "provider": "simulation",
        }

        if self._current_task:
            task_type_str = (
                self._current_task.task_type.value
                if hasattr(self._current_task.task_type, "value")
                else str(self._current_task.task_type)
            )
            info["task_type"] = task_type_str
            info["task_description"] = self._current_task.description
            info["difficulty"] = self._current_task.difficulty
            info["max_steps"] = self._current_task.max_steps

        if self._state:
            info["window_position"] = (self._state.window.x, self._state.window.y)
            info["window_size"] = (self._state.window.width, self._state.window.height)

        return info

    def _create_step_info(
        self, action: Action, action_result: Dict[str, Any], success: bool
    ) -> Dict[str, Any]:
        """创建step返回的info"""
        return {
            "step_count": self._step_count,
            "action_valid": action_result.get("success", True),
            "action_message": action_result.get("message", ""),
            "action_effects": action_result.get("effects", []),
            "success": success,
            "elapsed_time": time.time() - self._episode_start_time,
        }

    # ==================== 调试接口 ====================

    def get_state(self) -> Optional[ApplicationState]:
        """获取当前内部状态 - 仅用于调试

        Warning:
            训练系统不应将此状态直接提供给模型！
            模型只应通过截图观察环境。
        """
        return self._state.copy() if self._state else None

    def get_legal_actions(self) -> List[Action]:
        """获取当前合法动作列表 - 用于调试或辅助训练

        Returns:
            合法动作列表
        """
        try:
            return self._on_get_legal_actions()
        except Exception as e:
            if self.debug_mode:
                print(f"[{self.window_title}] Get legal actions error: {e}")
            return []

    @abstractmethod
    def _on_get_legal_actions(self) -> List[Action]:
        """子类实现：返回当前状态下所有合法动作

        Returns:
            合法动作列表
        """
        pass

    def get_state_history(self) -> List[ApplicationState]:
        """获取状态历史 - 调试用"""
        return [s.copy() for s in self._state_history]

    def get_action_history(self) -> List[Action]:
        """获取动作历史 - 调试用"""
        return self._action_history.copy()

    def get_step_count(self) -> int:
        """获取当前步数"""
        return self._step_count

    def get_task_config(self) -> Optional[TaskConfig]:
        """获取当前任务配置"""
        return self._current_task

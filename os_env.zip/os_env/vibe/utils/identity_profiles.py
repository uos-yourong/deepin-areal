"""身份素材来源与回退机制.

作用：
- 提供可复现的联系人/群名样本（避免张三、李四等占位名称）
- 提供可选的在线抓取入口（如 Random User API）
- 在线抓取失败时自动回退到本地静态样本池
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple
import hashlib
import json
import random
import urllib.error
import urllib.parse
import urllib.request


@dataclass(frozen=True)
class ContactIdentity:
    """联系人/群组身份结构。"""

    name: str
    contact_type: str  # individual | group
    avatar_url: str
    source: str = "builtin"


_DEFAULT_INDIVIDUALS = (
    "张伟",
    "王芳",
    "李静",
    "刘晨",
    "陈婷",
    "周楠",
    "赵敏",
    "黄磊",
    "孙琳",
    "王珊",
    "吴磊",
    "马超",
    "刘洋",
    "赵雷",
    "周洋",
    "梁婷",
    "李晨",
    "孙俪",
    "邢卓",
    "韩旭",
    "朱晨",
    "林佳",
    "杨阳",
    "任涛",
    "赵悦",
    "陈晨",
    "许敏",
    "程明",
    "周宇",
    "吴刚",
    "宋瑶",
    "王涛",
    "高楠",
    "林晨",
    "何晓",
    "郭涛",
    "许宁",
    "江涛",
    "汪雨",
    "顾晨",
    "方婷",
    "唐晓",
)

_DEFAULT_GROUPS = (
    "项目组",
    "研发部",
    "产品组",
    "设计中心",
    "客服小组",
    "市场部",
    "财务组",
    "销售团队",
    "HR 团队",
    "周会资料同步群",
    "架构讨论群",
    "产品研发协作群",
    "前端体验群",
    "后端值班群",
    "品牌物料群",
    "版本发布群",
    "风控策略群",
    "运营素材组",
    "设计评审群",
    "测试回归群",
    "项目复盘群",
)


def _slugify(name: str) -> str:
    """将中文名字转为稳定可复用的 avatar 标识符片段。"""
    normalized = "".join(ch for ch in name.strip().lower() if ch.isalnum())
    if normalized:
        return normalized
    digest = hashlib.sha1(name.encode("utf-8")).hexdigest()[:12]
    return digest


def _builtin_library() -> List[ContactIdentity]:
    """返回内置身份库。"""
    profiles: List[ContactIdentity] = []
    for name in _DEFAULT_INDIVIDUALS:
        profiles.append(
            ContactIdentity(
                name=name,
                contact_type="individual",
                avatar_url=f"avatar://person/{_slugify(name)}",
                source="builtin",
            )
        )
    for name in _DEFAULT_GROUPS:
        profiles.append(
            ContactIdentity(
                name=name,
                contact_type="group",
                avatar_url=f"avatar://group/{_slugify(name)}",
                source="builtin",
            )
        )
    return profiles


def _fetch_remote_profiles(seed: int, count: int) -> List[ContactIdentity]:
    """可选的在线抓取：默认从 randomuser.me 抓取真实姓名样本。

    当网络不可用或接口不可达时，返回空列表并回退内置池。
    """
    endpoint = "https://randomuser.me/api/"
    query = urllib.parse.urlencode(
        {
            "results": str(count),
            "seed": str(seed),
            "nat": "cn",
            "inc": "name,picture",
            "noinfo": "true",
        }
    )
    url = f"{endpoint}?{query}"
    req = urllib.request.Request(url, headers={"User-Agent": "vibe-identity-pool/1.0"})

    try:
        with urllib.request.urlopen(req, timeout=1.5) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, ValueError, TimeoutError):
        return []
    except Exception:
        return []

    raw_results = payload.get("results")
    if not isinstance(raw_results, list):
        return []

    profiles = []
    for item in raw_results:
        name_block = item.get("name") if isinstance(item, dict) else None
        picture_block = item.get("picture") if isinstance(item, dict) else None
        if not isinstance(name_block, dict):
            continue
        first = str(name_block.get("first", "")).strip()
        last = str(name_block.get("last", "")).strip()
        if not first and not last:
            continue
        full_name = f"{first} {last}".strip()
        avatar = ""
        if isinstance(picture_block, dict):
            avatar = str(picture_block.get("thumbnail", "") or picture_block.get("medium", "")).strip()
        profiles.append(
            ContactIdentity(
                name=full_name,
                contact_type="individual",
                avatar_url=avatar or f"avatar://person/{_slugify(full_name)}",
                source="remote",
            )
        )
    return profiles


def load_identity_profiles(
    count: int,
    seed: int = 0,
    include_remote: bool = False,
) -> List[ContactIdentity]:
    """加载身份素材。

    参数:
        count: 期望返回的数量
        seed: 随机种子
        include_remote: 是否尝试拉取在线样本（默认关闭，保持可控与隐私）
    """
    if count <= 0:
        return []

    if include_remote:
        remote = _fetch_remote_profiles(seed=seed, count=count)
        if remote:
            return remote[:count]

    pool = list(_builtin_library())
    rng = random.Random(seed)
    rng.shuffle(pool)
    return pool[:count]


def identity_library_to_tuples(
    count: int,
    seed: int = 0,
    include_remote: bool = False,
) -> List[Tuple[str, str, str]]:
    """以兼容格式返回 `[(name, contact_type, avatar_url)]`。"""
    return [
        (item.name, item.contact_type, item.avatar_url)
        for item in load_identity_profiles(count=count, seed=seed, include_remote=include_remote)
    ]

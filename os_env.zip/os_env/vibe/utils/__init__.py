"""Vibe 工具库。"""

from .identity_profiles import (
    ContactIdentity,
    load_identity_profiles,
    identity_library_to_tuples,
)

__all__ = [
    "ContactIdentity",
    "load_identity_profiles",
    "identity_library_to_tuples",
]


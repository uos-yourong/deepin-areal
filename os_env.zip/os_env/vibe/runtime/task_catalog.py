"""Task Catalog Utilities

提供基于应用能力清单的“可逆任务生成”能力：
- 训练器可以按 app/task/difficulty 约束抽取可用任务模板
- 支持可复现实验的可重放采样
- 输出符合 `TaskConfig` 与 `vibe_config` 的任务负载

职责边界：
- 应用能力仍在 `app_manifests` 中定义
- 本模块只做策略选择与任务组装，不关心 UI 或动作执行
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence
import random

from vibe.core.shared_types import TaskConfig
from vibe.runtime import app_manifests


@dataclass(frozen=True)
class TaskCatalogSelection:
    """一次任务采样的标准结果。"""

    app_type: str
    task_type: str
    template_id: str
    payload: Dict[str, Any]
    task_config: TaskConfig


def _filter_templates(
    app_type: str, task_type: Optional[str], difficulty: Optional[int]
) -> List[Any]:
    templates = app_manifests.get_default_task_templates(app_type, task_type)
    if difficulty is None:
        return list(templates)

    result = [
        t
        for t in templates
        if int(t.difficulty or 1) == int(difficulty)
    ]
    return result


def list_available_tasks(
    app_types: Optional[Sequence[str]] = None,
    task_types: Optional[Sequence[str]] = None,
    difficulty: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """按条件列举可用任务清单（可直接用于离线索引或回放）。"""
    candidates = []
    target_apps = app_types or app_manifests.list_app_types()
    for app_type in target_apps:
        for item in app_manifests.get_default_task_templates(app_type):
            if task_types and item.task_type not in task_types:
                continue
            if difficulty is not None and item.difficulty != difficulty:
                continue
            candidates.append(app_manifests.to_task_dict(item) | {"app_type": app_type})
    return candidates


def build_switch_task_payload(
    source_app: str,
    target_app: str,
    difficulty: int = 1,
) -> Dict[str, Any]:
    """构造跨应用切换任务模板负载。

    用于“同一条指令链条内执行应用切换”场景的显式任务定义。
    """
    payload = {
        "instruction_id": f"{source_app}_switch_to_{target_app}",
        "task_type": "switch_app",
        "instruction_text": f"从 {source_app} 切换到 {target_app}",
        "target": {"target_app": target_app},
        "difficulty": int(difficulty or 1),
        "max_steps": 20,
        "reward": {"success_reward": 2.5, "failure_penalty": -2.0, "step_penalty": -0.01},
        "hook_rules": [
            {
                "name": f"{source_app}_switch_to_{target_app}",
                "event": "app_effect",
                "event_name": "active_app_changed",
                "when": {
                    "field": "active_app",
                    "op": "eq",
                    "value": target_app,
                    "scope": "state",
                },
                "reward": 2.5,
                "done": True,
                "once": True,
            }
        ],
    }
    payload["app_type"] = source_app
    return payload


def build_switch_vibe_config(
    source_app: str,
    target_app: str,
    difficulty: int = 1,
    seed: Optional[int] = None,
) -> Dict[str, Any]:
    """构建用于 os_env/vibe 入口的 switch_app 任务配置。"""
    task_payload = build_switch_task_payload(
        source_app=source_app,
        target_app=target_app,
        difficulty=difficulty,
    )
    task_payload["seed"] = seed
    return {
        "vibe_config": {
            "active_app": source_app,
            "task": task_payload,
            "data_generation": {"seed": seed},
        }
    }


def sample_task_template(
    app_type: str,
    task_type: Optional[str] = None,
    difficulty: Optional[int] = None,
    seed: Optional[int] = None,
) -> Optional[TaskCatalogSelection]:
    """在某应用能力空间内抽样一个任务模板并生成 `TaskConfig`。"""
    templates = _filter_templates(app_type, task_type, difficulty)
    if not templates:
        return None

    rng = random.Random(seed)
    template = templates[rng.randrange(len(templates))]
    payload = app_manifests.to_task_dict(template)
    task_config = TaskConfig(
        task_type=payload["task_type"],
        difficulty=payload["difficulty"],
        description=payload["description"],
        initial_state_config=payload.get("initial_state_config", {}),
        target=payload["target"],
        success_conditions=payload.get("success_conditions", []),
        failure_conditions=payload.get("failure_conditions", []),
        max_steps=payload["max_steps"],
        reward_config=payload.get("reward", {}),
        hook_rules=payload.get("hook_rules", []),
        randomization=payload.get("randomization", {}),
    )
    return TaskCatalogSelection(
        app_type=app_type,
        task_type=payload["task_type"],
        template_id=payload["instruction_id"],
        payload=payload,
        task_config=task_config,
    )


def build_vibe_task_payload(
    app_type: str,
    task_type: Optional[str] = None,
    difficulty: Optional[int] = None,
    seed: Optional[int] = None,
    target_overrides: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """生成可直接注入 `vibe_config` 的任务对象。

    - target_overrides: 覆盖模板中可变字段（如固定联系人索引）
    """
    selection = sample_task_template(app_type, task_type, difficulty, seed)
    if selection is None:
        return None

    task_payload = selection.payload.copy()
    if target_overrides:
        merged_target = dict(task_payload.get("target") or {})
        merged_target.update(target_overrides)
        task_payload["target"] = merged_target

    task_payload["seed"] = seed
    task_payload["app_type"] = app_type
    return task_payload


def build_vibe_multi_app_sequence(
    source_app: str,
    target_app: str,
    source_task_type: Optional[str] = None,
    source_task_target: Optional[Dict[str, Any]] = None,
    source_task_difficulty: Optional[int] = None,
    seed: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """生成“先在源应用完成任务，再切换到目标应用”的两步指令序列。

    返回用于 RL 的指令列表，便于在 `task_config/apps` 结构中直接拼装。
    """
    sequence: List[Dict[str, Any]] = []

    source_task = (
        build_vibe_task_payload(
            app_type=source_app,
            task_type=source_task_type,
            difficulty=source_task_difficulty,
            seed=seed,
            target_overrides=source_task_target,
        )
        or {}
    )
    if source_task:
        source_task["app_type"] = source_app
        sequence.append({"app_type": source_app, "task": source_task})

    sequence.append(
        {
            "app_type": source_app,
            "task": build_switch_task_payload(
                source_app=source_app,
                target_app=target_app,
                difficulty=1,
            ),
        }
    )
    return sequence


def build_vibe_config(
    app_type: str,
    task_type: Optional[str] = None,
    difficulty: Optional[int] = None,
    seed: Optional[int] = None,
    target_overrides: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """生成符合 os_env 上游 `vibe_config` 的标准 payload。"""
    task_payload = build_vibe_task_payload(
        app_type=app_type,
        task_type=task_type,
        difficulty=difficulty,
        seed=seed,
        target_overrides=target_overrides,
    )
    if task_payload is None:
        return None

    return {
        "vibe_config": {
            "active_app": app_type,
            "task": task_payload,
            "data_generation": {"seed": seed},
        }
    }


def sample_task_space(
    app_types: Sequence[str],
    task_types: Optional[Sequence[str]] = None,
    difficulty: Optional[int] = None,
    limit: int = 1,
    seed: Optional[int] = None,
) -> List[TaskCatalogSelection]:
    """跨应用采样一组任务（用于 curriculum/batch）"""
    selections: List[TaskCatalogSelection] = []
    if not app_types or limit <= 0:
        return selections

    total = max(1, int(limit))
    rng = random.Random(seed)
    task_type_list = list(task_types) if task_types else []
    for idx in range(total):
        app_type = app_types[rng.randrange(len(app_types))]
        selected = sample_task_template(
            app_type=app_type,
            task_type=(task_type_list[rng.randrange(len(task_type_list))] if task_type_list else None),
            difficulty=difficulty,
            seed=(seed or 0) + idx,
        )
        if selected:
            selections.append(selected)
    return selections

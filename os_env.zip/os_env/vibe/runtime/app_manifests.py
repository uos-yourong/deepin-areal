"""应用能力清单与指令模板

该模块把应用能力定义从代码中抽离到配置文件 `app_manifests.yaml`。
作用：
- 定义每个 vibe 应用的任务空间（task_templates）
- 统一管理 hook 规则（用于奖励/终止判定）
- 为上游 `task_catalog` 与 `desktop_env_provider` 提供统一读取接口

目标：新增 app 时改配置文件，不改核心管理链路；
新增 hook 时统一配置化，不改执行器逻辑。
"""

from __future__ import annotations

import logging
import os
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

try:
    import yaml
except Exception:  # pragma: no cover - 在极少数环境无PyYAML时降级
    yaml = None


@dataclass(frozen=True)
class InstructionTemplate:
    """单条可训练指令模板"""

    instruction_id: str
    app_type: str
    task_type: str
    instruction_text: str
    target: Dict[str, Any]
    difficulty: int = 1
    max_steps: int = 50
    reward_config: Dict[str, float] = field(
        default_factory=lambda: {
            "success_reward": 8.0,
            "failure_penalty": -2.0,
            "step_penalty": -0.01,
        }
    )
    initial_state_config: Dict[str, Any] = field(default_factory=dict)
    success_conditions: List[Dict[str, Any]] = field(default_factory=list)
    failure_conditions: List[Dict[str, Any]] = field(default_factory=list)
    hook_rules: List[Dict[str, Any]] = field(default_factory=list)


@dataclass(frozen=True)
class AppManifest:
    """应用清单（可序列化）"""

    app_type: str
    app_name: str
    capabilities: tuple
    task_types: tuple
    task_templates: List[InstructionTemplate]
    metadata: Dict[str, Any] = field(default_factory=dict)


def _normalize_manifest_target_value(raw: Any) -> Any:
    """标准化目标参数，便于占位符与数字字符串比较。"""

    if isinstance(raw, str):
        raw = raw.strip()
        if raw.isdigit():
            return int(raw)
    return raw


def _resolve_template(template: Dict[str, Any], target: Dict[str, Any]) -> Dict[str, Any]:
    """将 template 中的占位符使用 target 进行替换。

    占位符格式："{field}"，仅做 str.format。
    """

    def _render_value(raw: Any) -> Any:
        if isinstance(raw, str):
            try:
                return raw.format(**target)
            except Exception:
                return raw

        if isinstance(raw, list):
            return [_render_value(item) for item in raw]

        if isinstance(raw, dict):
            return {key: _render_value(value) for key, value in raw.items()}

        return raw

    rendered: Dict[str, Any] = {}
    for key, value in template.items():
        rendered[key] = _render_value(value)
    return rendered


def _build_hook_rules(raw_rules: List[Dict[str, Any]], target: Dict[str, Any]) -> List[Dict[str, Any]]:
    """根据目标参数渲染 Hook 规则。"""

    return [
        deepcopy(_resolve_template(rule, target))
        for rule in raw_rules
        if isinstance(rule, dict)
    ]


def _coerce_conditions(raw_conditions: Any) -> List[Dict[str, Any]]:
    """规范化条件列表，过滤掉非法字段。"""

    if not isinstance(raw_conditions, list):
        return []

    normalized = []
    for item in raw_conditions:
        if not isinstance(item, dict):
            continue
        normalized_item = {str(k): v for k, v in item.items()}
        if "field" in normalized_item or "type" in normalized_item or "name" in normalized_item:
            normalized.append(normalized_item)
    return normalized


def _coerce_initial_state(raw_state: Any) -> Dict[str, Any]:
    if not isinstance(raw_state, dict):
        return {}
    return {str(k): _normalize_manifest_target_value(v) for k, v in raw_state.items()}


def _derive_success_conditions_from_hooks(hook_rules: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """未显式声明 success_conditions 时，从 hook 的 when 字段自动推导。"""

    conditions: List[Dict[str, Any]] = []
    for rule in hook_rules or []:
        when = rule.get("when") if isinstance(rule, dict) else None
        if not isinstance(when, dict):
            continue
        if not when.get("field"):
            continue

        field = when.get("field")
        op = when.get("op", "eq")
        value = when.get("value")
        scope = when.get("scope", "state")

        conditions.append(
            {
                "type": "state",
                "field": field,
                "operator": op,
                "op": op,
                "value": _normalize_manifest_target_value(value),
                "scope": scope,
            }
        )

    return conditions


def _instruction_to_task_template(item: Dict[str, Any], app_type: str) -> InstructionTemplate:
    """从字典构建 InstructionTemplate。"""

    reward_config = item.get("reward_config", item.get("reward", {}))
    if not isinstance(reward_config, dict):
        reward_config = {}

    hook_rules = item.get("hook_rules", [])
    if not isinstance(hook_rules, list):
        hook_rules = []

    initial_state_config = _coerce_initial_state(item.get("initial_state_config", {}))
    success_conditions = _coerce_conditions(item.get("success_conditions", []))
    failure_conditions = _coerce_conditions(item.get("failure_conditions", []))
    if not success_conditions:
        success_conditions = _derive_success_conditions_from_hooks(hook_rules)

    return InstructionTemplate(
        instruction_id=str(item.get("instruction_id", f"{app_type}_baseline")),
        app_type=app_type,
        task_type=str(item.get("task_type", "default")),
        instruction_text=str(item.get("instruction_text", "")),
        target=_normalize_dict(item.get("target", {})),
        difficulty=int(item.get("difficulty", 1) or 1),
        max_steps=int(item.get("max_steps", 50) or 50),
        reward_config=reward_config,
        initial_state_config=initial_state_config,
        success_conditions=success_conditions,
        failure_conditions=failure_conditions,
        hook_rules=hook_rules,
    )


def _build_manifest(app_type: str, config: Dict[str, Any]) -> AppManifest:
    """将字典配置转为 AppManifest 对象。"""

    instructions_key = config.get("instructions", config.get("tasks", []))
    if not isinstance(instructions_key, list):
        instructions_key = []

    task_types = config.get("task_types", [])
    capabilities = config.get("capabilities", [])

    return AppManifest(
        app_type=app_type,
        app_name=str(config.get("app_name", app_type)),
        capabilities=tuple(capabilities),
        task_types=tuple(task_types),
        task_templates=[
            _instruction_to_task_template(item, app_type) for item in instructions_key
            if isinstance(item, dict)
        ],
        metadata=config.get("metadata", {}),
    )


def _normalize_dict(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    return {str(k): _normalize_manifest_target_value(v) for k, v in value.items()}


def _normalize_instruction_target(target: Dict[str, Any]) -> Dict[str, Any]:
    """对模板/任务 target 做可复用的规范化。"""

    return {key: _normalize_manifest_target_value(value) for key, value in (target or {}).items()}


def _resolve_manifest_path() -> Path:
    """返回配置文件绝对路径，允许环境变量覆盖。"""

    explicit_path = os.environ.get("VIBE_APP_MANIFEST_PATH")
    if explicit_path:
        p = Path(explicit_path).expanduser()
        if p.exists():
            return p
        logging.warning("VIBE_APP_MANIFEST_PATH=%s 不存在，回退到默认路径", p)

    return Path(__file__).resolve().parent / "app_manifests.yaml"


def _coerce_tuple(value: Any, default: tuple = ()) -> tuple:
    if not value:
        return default
    if isinstance(value, tuple):
        return value
    if isinstance(value, str):
        return tuple(item.strip() for item in value.split(",") if item.strip())
    if isinstance(value, (list, set)):
        return tuple(value)
    return tuple([value])


def _load_yaml_manifests() -> Optional[Dict[str, AppManifest]]:
    if yaml is None:
        logging.warning("PyYAML 不可用，使用内置 fallback 应用清单")
        return None

    manifest_path = _resolve_manifest_path()
    if not manifest_path.exists():
        logging.warning("应用清单文件缺失: %s，使用内置 fallback", manifest_path)
        return None

    try:
        with manifest_path.open("r", encoding="utf-8") as handle:
            raw = yaml.safe_load(handle) or {}
    except Exception as e:
        logging.error("解析应用清单失败: %s，回退到内置清单", e)
        return None

    apps_raw = raw.get("apps") if isinstance(raw, dict) else None
    if not isinstance(apps_raw, dict):
        logging.error("应用清单格式异常：未检测到 apps 映射，回退到内置清单")
        return None

    result = {}
    for app_type, config in apps_raw.items():
        if not isinstance(config, dict):
            continue
        config = dict(config)
        config["capabilities"] = _coerce_tuple(config.get("capabilities"), ())
        config["task_types"] = _coerce_tuple(config.get("task_types"), ())
        result[app_type] = _build_manifest(app_type, config)

    if not result:
        logging.warning("应用清单解析为空，回退到内置清单")
        return None

    return result


def _fallback_manifests() -> Dict[str, AppManifest]:
    """构建内置 fallback 清单（用于配置异常场景）。"""

    return _default_manifests()


def _default_manifests() -> Dict[str, AppManifest]:
    """构建默认清单（内部私有 fallback）。"""

    raw_manifests = {
        "wechat": {
            "app_name": "WeChat Simulator",
            "capabilities": (
                "open_conversation",
                "search_and_open",
                "send_text_message",
                "switch_app",
            ),
            "task_types": (
                "open_conversation",
                "search_and_open",
                "send_text_message",
                "switch_app",
            ),
            "instructions": [
                {
                    "instruction_id": "wechat_switch_to_qq",
                    "task_type": "switch_app",
                    "instruction_text": "切换到QQ",
                    "target": {"target_app": "qq"},
                    "max_steps": 20,
                    "hook_rules": [
                        {
                            "name": "wechat_switch_to_qq",
                            "event": "app_effect",
                            "event_name": "active_app_changed",
                            "when": {
                                "field": "active_app",
                                "op": "eq",
                                "value": "qq",
                                "scope": "state",
                            },
                            "reward": 2.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "wechat_switch_to_mail",
                    "task_type": "switch_app",
                    "instruction_text": "切换到邮箱",
                    "target": {"target_app": "mail"},
                    "max_steps": 20,
                    "hook_rules": [
                        {
                            "name": "wechat_switch_to_mail",
                            "event": "app_effect",
                            "event_name": "active_app_changed",
                            "when": {
                                "field": "active_app",
                                "op": "eq",
                                "value": "mail",
                                "scope": "state",
                            },
                            "reward": 2.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "wechat_open_conv_0",
                    "task_type": "open_conversation",
                    "instruction_text": "打开第1个会话",
                    "target": {"target_position": 0},
                    "max_steps": 40,
                    "hook_rules": [
                        {
                            "name": "wechat_open_conv_0",
                            "event": "app_effect",
                            "event_name": "conversation_opened",
                            "when": {
                                "field": "selected_conversation_index",
                                "op": "eq",
                                "value": 0,
                                "scope": "state",
                            },
                            "reward": 4.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "wechat_send_fixed",
                    "task_type": "send_text_message",
                    "instruction_text": "向当前会话发送固定内容",
                    "target": {
                        "target_position": 0,
                        "content": "已收到，稍后回复。",
                    },
                    "max_steps": 50,
                    "hook_rules": [
                        {
                            "name": "wechat_send_fixed",
                            "event": "app_effect",
                            "event_name": "message_sent",
                            "when": {
                                "field": "last_sent_text",
                                "op": "eq",
                                "value": "已收到，稍后回复。",
                                "scope": "state",
                            },
                            "reward": 6.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
            ],
            "metadata": {
                "login_required": True,
                "requires_social_graph": True,
            },
        },
        "qq": {
            "app_name": "QQ Simulator",
            "capabilities": (
                "open_conversation",
                "search_and_open",
                "send_text_message",
                "switch_app",
            ),
            "task_types": (
                "open_conversation",
                "search_and_open",
                "send_text_message",
                "switch_app",
            ),
            "instructions": [
                {
                    "instruction_id": "qq_switch_to_wechat",
                    "task_type": "switch_app",
                    "instruction_text": "切换到微信",
                    "target": {"target_app": "wechat"},
                    "max_steps": 20,
                    "hook_rules": [
                        {
                            "name": "qq_switch_to_wechat",
                            "event": "app_effect",
                            "event_name": "active_app_changed",
                            "when": {
                                "field": "active_app",
                                "op": "eq",
                                "value": "wechat",
                                "scope": "state",
                            },
                            "reward": 2.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "qq_open_conv_0",
                    "task_type": "open_conversation",
                    "instruction_text": "打开QQ第1个会话",
                    "target": {"target_position": 0},
                    "max_steps": 40,
                    "hook_rules": [
                        {
                            "name": "qq_open_conv_0",
                            "event": "app_effect",
                            "event_name": "conversation_opened",
                            "when": {
                                "field": "selected_conversation_index",
                                "op": "eq",
                                "value": 0,
                                "scope": "state",
                            },
                            "reward": 4.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
            ],
            "metadata": {
                "login_required": True,
                "requires_social_graph": True,
            },
        },
        "qqmusic": {
            "app_name": "QQMusic Simulator",
            "capabilities": (
                "search_music",
                "play_song",
                "pause_playback",
                "open_playlist",
                "switch_app",
            ),
            "task_types": (
                "search_music",
                "play_song",
                "pause_playback",
                "open_playlist",
                "switch_app",
            ),
            "instructions": [
                {
                    "instruction_id": "qqmusic_switch_to_wechat",
                    "task_type": "switch_app",
                    "instruction_text": "切换到微信",
                    "target": {"target_app": "wechat"},
                    "max_steps": 20,
                    "hook_rules": [
                        {
                            "name": "qqmusic_switch_to_wechat",
                            "event": "app_effect",
                            "event_name": "active_app_changed",
                            "when": {
                                "field": "active_app",
                                "op": "eq",
                                "value": "wechat",
                                "scope": "state",
                            },
                            "reward": 2.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "qqmusic_search_song_1",
                    "task_type": "search_music",
                    "instruction_text": "搜索歌曲《夜曲》",
                    "target": {"query": "夜曲"},
                    "max_steps": 35,
                    "hook_rules": [
                        {
                            "name": "qqmusic_search_ok",
                            "event": "app_effect",
                            "event_name": "search_complete",
                            "when": {
                                "field": "search_query",
                                "op": "eq",
                                "value": "夜曲",
                                "scope": "state",
                            },
                            "reward": 3.0,
                            "done": True,
                            "once": False,
                        }
                    ],
                },
                {
                    "instruction_id": "qqmusic_play_song_1",
                    "task_type": "play_song",
                    "instruction_text": "播放歌曲《夜曲》",
                    "target": {"song_id": "song_yequ"},
                    "max_steps": 45,
                    "hook_rules": [
                        {
                            "name": "qqmusic_play_ok",
                            "event": "app_effect",
                            "event_name": "playback_started",
                            "when": {
                                "field": "active_song_id",
                                "op": "eq",
                                "value": "song_yequ",
                                "scope": "state",
                            },
                            "reward": 5.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
            ],
            "metadata": {
                "login_required": False,
            },
        },
        "mail": {
            "app_name": "Mail Simulator",
            "capabilities": (
                "open_folder",
                "open_mail",
                "mark_as_read",
                "reply_mail",
                "switch_app",
            ),
            "task_types": (
                "open_folder",
                "open_mail",
                "mark_as_read",
                "reply_mail",
                "switch_app",
            ),
            "instructions": [
                {
                    "instruction_id": "mail_switch_to_wechat",
                    "task_type": "switch_app",
                    "instruction_text": "切换到微信",
                    "target": {"target_app": "wechat"},
                    "max_steps": 20,
                    "hook_rules": [
                        {
                            "name": "mail_switch_to_wechat",
                            "event": "app_effect",
                            "event_name": "active_app_changed",
                            "when": {
                                "field": "active_app",
                                "op": "eq",
                                "value": "wechat",
                                "scope": "state",
                            },
                            "reward": 2.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "mail_open_inbox",
                    "task_type": "open_folder",
                    "instruction_text": "打开 INBOX 文件夹",
                    "target": {"folder": "INBOX"},
                    "max_steps": 30,
                    "hook_rules": [
                        {
                            "name": "mail_open_inbox",
                            "event": "app_effect",
                            "event_name": "folder_opened",
                            "when": {
                                "field": "current_folder",
                                "op": "eq",
                                "value": "INBOX",
                                "scope": "state",
                            },
                            "reward": 3.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
            ],
            "metadata": {
                "login_required": True,
            },
        },
        "wework": {
            "app_name": "WeWork Simulator",
            "capabilities": (
                "open_conversation",
                "send_text_message",
                "search_group",
                "switch_app",
            ),
            "task_types": (
                "open_conversation",
                "search_group",
                "send_text_message",
                "switch_app",
            ),
            "instructions": [
                {
                    "instruction_id": "wework_switch_to_wechat",
                    "task_type": "switch_app",
                    "instruction_text": "切换到微信",
                    "target": {"target_app": "wechat"},
                    "max_steps": 20,
                    "hook_rules": [
                        {
                            "name": "wework_switch_to_wechat",
                            "event": "app_effect",
                            "event_name": "active_app_changed",
                            "when": {
                                "field": "active_app",
                                "op": "eq",
                                "value": "wechat",
                                "scope": "state",
                            },
                            "reward": 2.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "wework_open_conv_0",
                    "task_type": "open_conversation",
                    "instruction_text": "打开企业微信第1个会话",
                    "target": {"target_position": 0},
                    "max_steps": 40,
                    "hook_rules": [
                        {
                            "name": "wework_open_conv_0",
                            "event": "app_effect",
                            "event_name": "conversation_opened",
                            "when": {
                                "field": "selected_conversation_index",
                                "op": "eq",
                                "value": 0,
                                "scope": "state",
                            },
                            "reward": 4.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "wework_search_group_00",
                    "task_type": "search_group",
                    "instruction_text": "搜索并打开群组“研发部”",
                    "target": {"target_contact": "研发部"},
                    "max_steps": 50,
                    "hook_rules": [
                        {
                            "name": "wework_search_group_00",
                            "event": "app_effect",
                            "event_name": "search_opened",
                            "when": {
                                "field": "current_conversation.display_name",
                                "op": "eq",
                                "value": "研发部",
                                "scope": "state",
                            },
                            "reward": 3.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
            ],
            "metadata": {
                "login_required": True,
                "org_tree_required": True,
            },
        },
        "tencentmeeting": {
            "app_name": "Tencent Meeting Simulator",
            "capabilities": (
                "open_conversation",
                "search_and_open",
                "send_text_message",
                "switch_app",
            ),
            "task_types": (
                "open_conversation",
                "search_and_open",
                "send_text_message",
                "switch_app",
            ),
            "instructions": [
                {
                    "instruction_id": "tencentmeeting_switch_to_wechat",
                    "task_type": "switch_app",
                    "instruction_text": "切换到微信",
                    "target": {"target_app": "wechat"},
                    "max_steps": 20,
                    "hook_rules": [
                        {
                            "name": "tencentmeeting_switch_to_wechat",
                            "event": "app_effect",
                            "event_name": "active_app_changed",
                            "when": {
                                "field": "active_app",
                                "op": "eq",
                                "value": "wechat",
                                "scope": "state",
                            },
                            "reward": 2.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "tencentmeeting_switch_to_qqmusic",
                    "task_type": "switch_app",
                    "instruction_text": "切换到QQ音乐",
                    "target": {"target_app": "qqmusic"},
                    "max_steps": 20,
                    "hook_rules": [
                        {
                            "name": "tencentmeeting_switch_to_qqmusic",
                            "event": "app_effect",
                            "event_name": "active_app_changed",
                            "when": {
                                "field": "active_app",
                                "op": "eq",
                                "value": "qqmusic",
                                "scope": "state",
                            },
                            "reward": 2.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "tencentmeeting_open_conv_0",
                    "task_type": "open_conversation",
                    "instruction_text": "打开第1个会话",
                    "target": {"target_position": 0},
                    "max_steps": 40,
                    "hook_rules": [
                        {
                            "name": "tencentmeeting_open_conv_0",
                            "event": "app_effect",
                            "event_name": "conversation_opened",
                            "when": {
                                "field": "selected_conversation_index",
                                "op": "eq",
                                "value": 0,
                                "scope": "state",
                            },
                            "reward": 4.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "tencentmeeting_search_contact_01",
                    "task_type": "search_and_open",
                    "instruction_text": "搜索并打开“王磊”",
                    "target": {"target_contact": "王磊"},
                    "max_steps": 50,
                    "hook_rules": [
                        {
                            "name": "tencentmeeting_search_contact_01",
                            "event": "app_effect",
                            "event_name": "search_opened",
                            "when": {
                                "field": "current_conversation.display_name",
                                "op": "eq",
                                "value": "王磊",
                                "scope": "state",
                            },
                            "reward": 3.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
                {
                    "instruction_id": "tencentmeeting_send_fixed",
                    "task_type": "send_text_message",
                    "instruction_text": "向当前会话发送“收到”",
                    "target": {"target_position": 0, "content": "收到"},
                    "max_steps": 55,
                    "hook_rules": [
                        {
                            "name": "tencentmeeting_send_fixed",
                            "event": "app_effect",
                            "event_name": "message_sent",
                            "when": {
                                "field": "last_sent_text",
                                "op": "eq",
                                "value": "收到",
                                "scope": "state",
                            },
                            "reward": 6.0,
                            "done": True,
                            "once": True,
                        }
                    ],
                },
            ],
            "metadata": {
                "login_required": True,
            },
        },
    }

    return {
        app_type: _build_manifest(app_type, config)
        for app_type, config in raw_manifests.items()
    }


def _load_manifests() -> Dict[str, AppManifest]:
    """加载配置并返回应用清单，失败则 fallback。"""

    loaded = _load_yaml_manifests()
    if loaded:
        return loaded
    return _fallback_manifests()


APP_MANIFESTS = _load_manifests()


def reload_manifests() -> Dict[str, AppManifest]:
    """重新读取清单文件（用于热更新测试或运行期更新）。"""

    global APP_MANIFESTS
    APP_MANIFESTS = _load_manifests()
    return APP_MANIFESTS


def list_manifests() -> Iterable[AppManifest]:
    """返回全部应用清单。"""

    return APP_MANIFESTS.values()


def list_app_types() -> List[str]:
    """返回全部 app_type。"""

    return list(APP_MANIFESTS.keys())


def get_manifest(app_type: str) -> Optional[AppManifest]:
    """获取某应用 manifest。"""

    return APP_MANIFESTS.get(app_type)


def get_default_task_templates(app_type: str, task_type: Optional[str] = None) -> List[InstructionTemplate]:
    """按 task_type 获取默认指令模板。"""

    manifest = get_manifest(app_type)
    if manifest is None:
        return []
    if task_type is None:
        return list(manifest.task_templates)
    return [t for t in manifest.task_templates if t.task_type == task_type]


def get_instruction_template(app_type: str, instruction_id: str) -> Optional[InstructionTemplate]:
    """按 instruction_id 获取模板。"""

    if not instruction_id:
        return None
    manifest = get_manifest(app_type)
    if manifest is None:
        return None
    for template in manifest.task_templates:
        if template.instruction_id == instruction_id:
            return template
    return None


def resolve_template_for_payload(
    app_type: str, task_payload: Dict[str, Any]
) -> Optional[InstructionTemplate]:
    """按 payload 推断最合适的模板。

    优先级:
    1. instruction_id 明确命中
    2. task_type 唯一匹配
    3. 任务类型 + task目标字段全匹配（简单近似）
    """

    manifest = get_manifest(app_type)
    if manifest is None:
        return None

    instruction_id = task_payload.get("instruction_id")
    if instruction_id:
        direct = get_instruction_template(app_type, instruction_id)
        if direct:
            return direct

    task_type = task_payload.get("task_type") or task_payload.get("type")
    if not task_type:
        return None

    templates = [t for t in manifest.task_templates if t.task_type == task_type]
    if len(templates) == 1:
        return templates[0]

    target = _normalize_instruction_target(task_payload.get("target", {}))
    for template in templates:
        template_target = _normalize_instruction_target(template.target)
        if not template_target:
            continue
        if all(key in target and target[key] == template_target[key] for key in template_target):
            return template

    return templates[0] if templates else None


def build_task_payload_from_template(template: InstructionTemplate, override: Dict[str, Any]) -> Dict[str, Any]:
    """用模板与外部覆盖字段构建可转 TaskConfig 的 dict。"""

    merged_target = {
        **template.target,
        **_normalize_instruction_target(override.get("target", {})),
    }

    # 覆盖模板自带字段
    return {
        "instruction_id": template.instruction_id,
        "task_type": override.get("task_type", template.task_type),
        "description": override.get("description", template.instruction_text),
        "difficulty": override.get("difficulty", template.difficulty),
        "max_steps": override.get("max_steps", template.max_steps),
        "target": merged_target,
        "reward": override.get("reward", template.reward_config),
        "hook_rules": override.get("hook_rules", _build_hook_rules(template.hook_rules, merged_target)),
        "success_conditions": override.get(
            "success_conditions",
            template.success_conditions,
        ),
        "failure_conditions": override.get(
            "failure_conditions",
            template.failure_conditions,
        ),
        "initial_state_config": override.get(
            "initial_state_config",
            template.initial_state_config,
        ),
        "randomization": override.get("randomization", {}),
    }


def get_default_hooks(
    app_type: str, task_type: str, target: Optional[Dict[str, Any]] = None
) -> List[Dict[str, Any]]:
    """按任务类型返回默认 hook 规则。

    允许使用 instruction_template 中配置的占位符（如 {target_position}）。
    """

    templates = get_default_task_templates(app_type, task_type)
    if not templates:
        return []

    # 按指令模板聚合 hook，适合于“无自定义 hook”场景时默认启用。
    rules: List[Dict[str, Any]] = []
    resolved_target = target or {}

    for template in templates:
        if not template.hook_rules:
            continue
        rules.extend(_build_hook_rules(template.hook_rules, resolved_target))

    return rules


def to_task_dict(template: InstructionTemplate) -> Dict[str, Any]:
    """将 InstructionTemplate 转为 TaskConfig 友好的字典。"""

    return {
        "instruction_id": template.instruction_id,
        "task_type": template.task_type,
        "difficulty": template.difficulty,
        "max_steps": template.max_steps,
        "description": template.instruction_text,
        "target": template.target,
        "initial_state_config": template.initial_state_config,
        "success_conditions": template.success_conditions,
        "failure_conditions": template.failure_conditions,
        "reward": template.reward_config,
        "hook_rules": template.hook_rules,
    }


def list_instruction_templates(app_type: Optional[str] = None) -> List[Dict[str, Any]]:
    """返回可序列化的指令模板。"""

    templates: List[Dict[str, Any]] = []
    if app_type is None:
        iterable = APP_MANIFESTS.values()
    else:
        manifest = get_manifest(app_type)
        iterable = [manifest] if manifest else []

    for manifest in iterable:
        for template in manifest.task_templates:
            templates.append(
                {
                    "app_type": manifest.app_type,
                    "app_name": manifest.app_name,
                    **to_task_dict(template),
                }
            )

    return templates

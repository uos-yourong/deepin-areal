"""Session Manager

运行时会话管理层：协调 VM 服务、应用实例生命周期、钩子引擎。
对外只暴露 "单环境可控" 的高层接口，屏蔽上层具体 app 实现细节。
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from vibe.core.base_application import BaseApplication
from vibe.core.shared_types import Action, ActionType, RewardComponents, TaskConfig, ActionConverter
from vibe.runtime.app_registry import VibeAppRegistry
from vibe.runtime.vm_service import VmService
from vibe.runtime.hook_engine import HookEngine
from vibe.runtime import app_manifests


@dataclass
class RuntimeSession:
    """会话上下文"""

    session_id: str
    app_type: str
    app: BaseApplication


class VibeSessionManager:
    """vibe 会话管理器"""

    def __init__(
        self,
        app_registry: Optional[VibeAppRegistry] = None,
        vm_service: Optional[VmService] = None,
    ):
        self._app_registry = app_registry or VibeAppRegistry()
        self._app_registry.bootstrap()
        self._vm_service = vm_service or VmService()
        self._hook_engine = HookEngine()
        self._active: Optional[RuntimeSession] = None

    @property
    def available_apps(self):
        return self._app_registry.list_app_types()

    @property
    def active_session(self) -> Optional[RuntimeSession]:
        """当前活动会话"""
        return self._active

    def list_apps(self):
        """返回当前 registry 中的 app 清单"""
        return self._app_registry.list_specs()

    def start_session(
        self,
        app_type: str,
        app_config: Optional[Dict[str, Any]] = None,
    ) -> RuntimeSession:
        """创建并初始化一个运行时会话"""
        if self._active is not None:
            self.close_session()

        app_conf = dict(app_config or {})
        vm = self._vm_service.start(app_type, metadata={"app_type": app_type})
        app = self._app_registry.build_app(app_type, **app_conf)

        if not app.initialize():
            raise RuntimeError(f"Failed to initialize app '{app_type}'")

        self._active = RuntimeSession(session_id=vm.session_id, app_type=app_type, app=app)
        return self._active

    def close_session(self) -> None:
        """关闭当前会话"""
        if self._active is None:
            return

        try:
            self._active.app.close()
        finally:
            self._vm_service.stop(self._active.session_id)
            self._active = None

    def ensure_session(self, app_type: str, app_config: Optional[Dict[str, Any]]):
        """如果当前会话不存在，按 app_type 拉起；否则复用"""
        if self._active and self._active.app_type == app_type:
            return self._active
        return self.start_session(app_type, app_config=app_config)

    def reset_active(
        self,
        app_type: str,
        task_config: TaskConfig,
        app_config: Optional[Dict[str, Any]] = None,
        seed: Optional[int] = None,
        options: Optional[Dict[str, Any]] = None,
    ):
        """重置当前会话到新任务"""
        task_config.hook_rules = list(task_config.hook_rules or [])
        if not task_config.hook_rules:
            task_type_str = (
                task_config.task_type.value
                if hasattr(task_config.task_type, "value")
                else str(task_config.task_type)
            )
            default_rules = app_manifests.get_default_hooks(
                app_type, task_type_str, task_config.target
            )
            if default_rules:
                task_config.hook_rules = default_rules

        self.start_session(app_type, app_config=app_config)
        self._hook_engine.reset()
        options = options or {}
        if seed is not None:
            options["seed"] = seed
        state, app_info = self._active.app.reset(task_config, seed=seed, options=options)
        return state, app_info

    def step_active(
        self, action: Dict[str, Any]
    ) -> Tuple[Any, RewardComponents, bool, bool, Dict[str, Any]]:
        """执行一步动作，返回状态、奖励、终止信息与可追踪事件"""
        if self._active is None:
            raise RuntimeError("No active runtime session. Call reset_active first.")

        app = self._active.app

        # 转换动作
        try:
            vibe_action = ActionConverter.from_gym_action(action)
        except Exception:
            # 兜底：非法动作转为系统动作，保持 step 可执行
            vibe_action = Action(type=ActionType.SYSTEM)

        if vibe_action.type == ActionType.SYSTEM and vibe_action.system_action is not None:
            if vibe_action.system_action.action.lower() == "switch_app":
                return self._handle_switch_action(vibe_action)

        pre_state = app.get_state()
        pre_state_dict = self._to_state_dict(pre_state, self._active.app_type if self._active else app.__class__.__name__)

        state, reward_components, done, truncated, step_info = app.step(vibe_action)

        post_state = app.get_state()
        post_state_dict = self._to_state_dict(post_state, self._active.app_type if self._active else app.__class__.__name__)

        # 当前任务可为空，默认构造 default，避免 hook 引擎报错
        task = app.get_task_config() or TaskConfig(task_type="default")
        hook_reward, hook_matches, terminal_signal = self._hook_engine.evaluate(
            task=task,
            state_before=pre_state_dict,
            state_after=post_state_dict,
            action=vibe_action,
            step_info=step_info,
            step_count=app.get_step_count(),
        )

        reward_components.hooks += hook_reward

        if terminal_signal:
            done = True

        step_info = {
            **step_info,
            "hook_trace": [
                {
                    "rule": m.rule_name,
                    "event": m.event.name,
                    "reward": m.reward,
                    "done": m.done,
                    "payload": m.event.payload,
                }
                for m in hook_matches
            ],
            "reward_events": [
                {
                    "rule": m.rule_name,
                    "reward": m.reward,
                    "event_type": m.event.event_type,
                    "event_name": m.event.name,
                    "done": m.done,
                }
                for m in hook_matches
            ],
            "terminal_signal": terminal_signal,
        }

        return state, reward_components, done, truncated, step_info

    @staticmethod
    def _to_state_dict(state_obj: Any, active_app: str) -> Dict[str, Any]:
        """将任意状态转为 hook 可消费字典，并注入 active_app。"""
        if state_obj is None:
            return {"active_app": active_app}

        state_dict = state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}
        if not isinstance(state_dict, dict):
            state_dict = {}
        state_dict["active_app"] = active_app
        return state_dict

    def _handle_switch_action(self, action: Action) -> Tuple[Any, RewardComponents, bool, bool, Dict[str, Any]]:
        """处理系统切应用动作的会话级逻辑。"""
        if self._active is None:
            raise RuntimeError("No active runtime session. Call reset_active first.")

        previous_app = self._active.app_type
        app = self._active.app
        source_task = app.get_task_config() or TaskConfig(task_type="default")
        task = self._build_switch_task(previous_app, action)
        pre_state = app.get_state()
        pre_state_dict = self._to_state_dict(pre_state, previous_app)
        source_step_count = app.get_step_count()

        target_app = action.system_action.target_app if action.system_action else None
        if not target_app:
            target_app = previous_app
        target_app = str(target_app).strip().lower()

        if target_app not in self._app_registry.list_app_types():
            action_result = {
                "success": False,
                "message": f"Unsupported target app: {target_app}",
                "effects": [
                    {
                        "type": "system_effect",
                        "name": "active_app_unsupported",
                        "target_app": target_app,
                    }
                ],
            }
            step_info = {
                "action_effects": action_result["effects"],
                "action_valid": False,
                "action_message": action_result["message"],
            }
            reward_components = RewardComponents()
            hook_reward, hook_matches, terminal_signal = self._hook_engine.evaluate(
                task=task,
                state_before=pre_state_dict,
                state_after=pre_state_dict,
                action=action,
                step_info=step_info,
                step_count=source_step_count + 1,
            )
            reward_components.hooks += hook_reward
            return (
                pre_state,
                reward_components,
                bool(terminal_signal),
                False,
                {
                    **step_info,
                    "hook_trace": [
                        {
                            "rule": m.rule_name,
                            "event": m.event.name,
                            "reward": m.reward,
                            "done": m.done,
                            "payload": m.event.payload,
                        }
                        for m in hook_matches
                    ],
                    "reward_events": [
                        {
                            "rule": m.rule_name,
                            "reward": m.reward,
                            "event_type": m.event.event_type,
                            "event_name": m.event.name,
                            "done": m.done,
                        }
                        for m in hook_matches
                    ],
                    "terminal_signal": terminal_signal,
                },
            )

        if target_app == previous_app:
            post_state = pre_state
            post_state_dict = self._to_state_dict(post_state, previous_app)
            action_result = {
                "success": True,
                "message": "already active",
                "effects": [
                    {
                        "type": "system_effect",
                        "name": "active_app_unchanged",
                        "target_app": target_app,
                    }
                ],
            }
            post_return_state = post_state
        else:
            reset_task = bool(action.system_action and action.system_action.reset_task)

            self.close_session()
            self.start_session(target_app, app_config={})
            post_return_state = self._active.app.get_state()
            if reset_task and hasattr(self._active.app, "reset"):
                try:
                    reset_task_config = TaskConfig(task_type="default")
                    self._active.app.reset(
                        task_config=reset_task_config,
                        seed=source_task.initial_state_config.get("seed"),
                        options=source_task.initial_state_config,
                    )
                    post_return_state = self._active.app.get_state()
                except Exception:
                    post_return_state = post_return_state

            if post_return_state is None:
                # 不依赖应用是否在 reset 后立即有状态，至少保证 active_app 可判定
                post_return_state = pre_state

            post_state_dict = self._to_state_dict(post_return_state, target_app)
            action_result = {
                "success": True,
                "message": f"switch app {previous_app} -> {target_app}",
                "effects": [
                    {
                        "type": "system_effect",
                        "name": "active_app_changed",
                        "from_app": previous_app,
                        "to_app": target_app,
                    }
                ],
            }

            if self._active is not None:
                post_state = self._active.app.get_state()
            else:
                post_state = post_return_state
            if post_state is None:
                post_state = post_return_state
            post_state_dict = self._to_state_dict(post_state, target_app)

        step_info = {
            "action_effects": action_result["effects"],
            "action_valid": action_result["success"],
            "action_message": action_result["message"],
            "system_action": {
                "action": action.system_action.action if action.system_action else "switch_app",
                "target_app": target_app,
                "reset_task": bool(action.system_action and action.system_action.reset_task),
            },
        }
        hook_reward, hook_matches, terminal_signal = self._hook_engine.evaluate(
            task=task,
            state_before=pre_state_dict,
            state_after=post_state_dict,
            action=action,
            step_info=step_info,
            step_count=source_step_count + 1,
        )

        reward_components = RewardComponents()
        reward_components.hooks += hook_reward
        done = bool(terminal_signal)
        truncated = False

        return (
            post_return_state,
            reward_components,
            done,
            truncated,
            {
                **step_info,
                "hook_trace": [
                    {
                        "rule": m.rule_name,
                        "event": m.event.name,
                        "reward": m.reward,
                        "done": m.done,
                        "payload": m.event.payload,
                    }
                    for m in hook_matches
                ],
                "reward_events": [
                    {
                        "rule": m.rule_name,
                        "reward": m.reward,
                        "event_type": m.event.event_type,
                        "event_name": m.event.name,
                        "done": m.done,
                    }
                    for m in hook_matches
                ],
                "terminal_signal": terminal_signal,
            },
        )

    @staticmethod
    def _fallback_switch_hook_rules(source_app: str, target_app: str) -> List[Dict[str, Any]]:
        """当 manifest 缺失 switch hook 时，提供最小可用回退规则。"""
        return [
            {
                "name": f"{source_app}_switch_to_{target_app}",
                "event": "app_effect",
                "event_name": "active_app_changed",
                "when": {
                    "field": "active_app",
                    "op": "eq",
                    "value": target_app,
                    "scope": "state",
                },
                "reward": 2.5,
                "done": True,
                "once": True,
            }
        ]

    def _build_switch_task(self, source_app: str, action: Action) -> TaskConfig:
        """生成专用的 switch_app 任务配置，用于 hook 评估。"""
        target_app = action.system_action.target_app if action.system_action else None
        if not target_app:
            target_app = source_app
        target_app = str(target_app).strip().lower()

        target = {"target_app": target_app}
        hook_rules = app_manifests.get_default_hooks(
            source_app, "switch_app", target
        )
        if not hook_rules:
            hook_rules = self._fallback_switch_hook_rules(source_app, target_app)

        return TaskConfig(
            task_type="switch_app",
            target=target,
            description=f"switch {source_app} -> {target_app}",
            max_steps=20,
            reward_config={"success_reward": 2.5, "failure_penalty": -2.0, "step_penalty": -0.01},
            hook_rules=hook_rules,
            initial_state_config={},
        )

"""Vibe Runtime Core

按层级拆分：
- app_registry: 应用发现与注册
- vm_service: 会话/VM 生命周期
- hook_engine: 规则奖励引擎
- session_manager: 上层管理入口
"""

from vibe.runtime.app_registry import VibeAppRegistry, VibeAppSpec
from vibe.runtime.vm_service import VmRuntimeSession, VmService
from vibe.runtime.session_manager import VibeSessionManager, RuntimeSession
from vibe.runtime.hook_engine import HookEngine, HookEvent, HookMatch
from vibe.runtime import task_catalog

__all__ = [
    "VibeAppRegistry",
    "VibeAppSpec",
    "VmRuntimeSession",
    "VmService",
    "VibeSessionManager",
    "RuntimeSession",
    "HookEngine",
    "HookEvent",
    "HookMatch",
    "task_catalog",
]

"""VM Service

当前版本先提供“控制平面服务”的骨架接口，方便后续接入真实虚拟机环境。
现阶段不直接启动真实 VM，仅保持生命周期可追踪与幂等性。
"""

import uuid
from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class VmRuntimeSession:
    """VM 会话元信息"""

    session_id: str
    app_type: str
    mode: str = "local_simulation"
    status: str = "initialized"
    metadata: dict = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class VmService:
    """VM 服务抽象层（管理 session 的生命周期）"""

    def __init__(self):
        self._sessions: Dict[str, VmRuntimeSession] = {}

    def start(self, app_type: str, metadata: Optional[dict] = None) -> VmRuntimeSession:
        """启动一个运行时会话（预留真实 VM 场景）"""
        session = VmRuntimeSession(
            session_id=str(uuid.uuid4()),
            app_type=app_type,
            status="running",
            metadata=metadata or {},
        )
        self._sessions[session.session_id] = session
        return session

    def stop(self, session_id: str) -> bool:
        """停止并移除会话"""
        session = self._sessions.pop(session_id, None)
        if session is None:
            return False
        session.status = "stopped"
        return True

    def get(self, session_id: str) -> Optional[VmRuntimeSession]:
        """获取会话信息"""
        return self._sessions.get(session_id)

    def list_sessions(self):
        """列出全部会话"""
        return list(self._sessions.values())

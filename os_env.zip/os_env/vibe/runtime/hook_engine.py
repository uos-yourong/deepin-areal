"""Hook Engine

事件驱动的规则奖励引擎。
任务侧定义 `hook_rules`，按事件匹配后给出增量奖励与终止信号。
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from vibe.core.shared_types import Action, ActionType, TaskConfig


@dataclass
class HookEvent:
    """规则匹配事件"""

    event_type: str
    name: str
    payload: dict
    step: int = 0


@dataclass
class HookMatch:
    """规则命中记录"""

    rule_name: str
    event: HookEvent
    reward: float
    done: bool = False


def _match_operator(left: Any, op: str, right: Any) -> bool:
    if op in ("equals", "eq", "=="):
        return left == right
    if op in ("not_equals", "ne", "!="):
        return left != right
    if op in ("contains",):
        try:
            return right in left
        except TypeError:
            return False
    if op == "in":
        if isinstance(right, (list, tuple, set)):
            return left in right
        return False
    if op == "not_in":
        if isinstance(right, (list, tuple, set)):
            return left not in right
        return True
    return False


class HookEngine:
    """规则引擎

    规则字段建议（示例）：
    {
      "event": "app_effect",
      "name": "conversation_opened",
      "event_name": "conversation_opened",
      "when": {"field": "selected_conversation_id", "op": "eq", "value": "xxx", "scope": "state"},
      "reward": 5.0,
      "done": true
    }
    """

    def __init__(self):
        self._last_triggered_once = set()

    def reset(self) -> None:
        """清空会话级别钩子状态"""
        self._last_triggered_once.clear()

    @staticmethod
    def _get_nested(state_dict: dict, field_path: str) -> Any:
        """按 path 获取字段值"""
        if not field_path:
            return None
        parts = field_path.split(".")
        cur = state_dict
        for part in parts:
            if cur is None:
                return None
            if isinstance(cur, dict):
                cur = cur.get(part)
            else:
                cur = getattr(cur, part, None)
        return cur

    @staticmethod
    def _to_dict(value: Any) -> Dict[str, Any]:
        if hasattr(value, "to_dict"):
            try:
                return value.to_dict()
            except Exception:
                return {}
        if isinstance(value, dict):
            return value
        return {}

    @staticmethod
    def _normalize_effect(effect: Any) -> Dict[str, Any]:
        """将 action_effect 统一为字典结构。"""
        if isinstance(effect, dict):
            return effect
        if isinstance(effect, str):
            return {"name": effect}
        return {"name": str(effect)}

    def evaluate(
        self,
        task: TaskConfig,
        state_before: Optional[Dict[str, Any]],
        state_after: Optional[Dict[str, Any]],
        action: Action,
        step_info: Dict[str, Any],
        step_count: int,
    ) -> (float, List[HookMatch], bool):
        """执行规则匹配"""
        rules = task.hook_rules or []
        events: List[HookEvent] = []
        matches: List[HookMatch] = []

        # 1) 基础事件：动作事件
        action_type = action.type.name.lower() if hasattr(action, "type") else "unknown"
        action_payload = {
            "action_type": action_type,
            "action_valid": step_info.get("action_valid"),
        }
        if action.type == ActionType.MOUSE and action.mouse_action:
            action_payload["mouse_subtype"] = action.mouse_action.subtype.name.lower()
            action_payload["coordinate"] = {
                "x": action.mouse_action.coordinate.x,
                "y": action.mouse_action.coordinate.y,
            }
        elif action.type == ActionType.KEYBOARD and action.keyboard_action:
            action_payload["keyboard_subtype"] = action.keyboard_action.subtype.name.lower()
            action_payload["key"] = action.keyboard_action.key
            action_payload["text"] = action.keyboard_action.text

        events.append(
            HookEvent(
                event_type="action_fired",
                name="action_fired",
                payload=action_payload,
                step=step_count,
            )
        )

        # 2) 基础事件：应用动作效果
        for effect in step_info.get("action_effects", []) or []:
            normalized = HookEngine._normalize_effect(effect)
            event_type = normalized.get("type") or normalized.get("event_type") or "app_effect"
            name = str(normalized.get("name", ""))
            events.append(
                HookEvent(
                    event_type=str(event_type),
                    name=str(name),
                    payload={"raw": effect, **HookEngine._to_dict(normalized)},
                    step=step_count,
                )
            )

        # 3) 状态变更事件
        before = state_before or {}
        after = state_after or {}
        for key in set(before.keys()) | set(after.keys()):
            if before.get(key) != after.get(key):
                events.append(
                    HookEvent(
                        event_type="state_changed",
                        name=f"{key}_changed",
                        payload={"field": key, "before": before.get(key), "after": after.get(key)},
                        step=step_count,
                    )
                )

        total = 0.0
        terminal = False
        for rule in rules:
            rule_name = rule.get("name", rule.get("event", "hook_rule"))
            reward = float(rule.get("reward", 0.0))
            done_flag = bool(rule.get("done", False))
            once = bool(rule.get("once", False))
            target_event = rule.get("event")
            target_name = rule.get("event_name")
            when = rule.get("when", {})
            matched = False

            for event in events:
                if target_event and event.event_type != target_event:
                    continue
                if target_name and event.name != target_name:
                    continue

                # 当 event 满足 when 条件时命中
                if not when:
                    matched = True
                else:
                    field = when.get("field") or when.get("state_field")
                    op = when.get("op", "eq")
                    value = when.get("value")
                    scope = when.get("scope", "always")

                    target_dict = after if scope == "state" else event.payload
                    if field and _match_operator(self._get_nested(target_dict, field), op, value):
                        matched = True
                    else:
                        matched = False

                if matched:
                    signature = f"{rule_name}:{event.event_type}:{event.name}:{event.step}"
                    if once and signature in self._last_triggered_once:
                        continue

                    matches.append(
                        HookMatch(rule_name=rule_name, event=event, reward=reward, done=done_flag)
                    )
                    total += reward
                    if once:
                        self._last_triggered_once.add(signature)
                    if done_flag:
                        terminal = True
                    break

        return total, matches, terminal

"""Application Registry

这个模块负责维护可用的 vibe 应用清单。原则是：
- 不直接在上层硬编码 app_type -> 类映射
- 新增应用只需在 registry 注册，不改动管理层主逻辑
- 统一记录每个应用的元信息（名称、类别、默认配置）
"""

from dataclasses import dataclass
from typing import Dict, Optional, Type

from vibe.core.base_application import BaseApplication
from importlib import import_module


@dataclass(frozen=True)
class VibeAppSpec:
    """应用清单条目"""

    app_type: str
    app_name: str
    app_class: Type[BaseApplication]
    capabilities: tuple = ()
    manifest: dict = None

    def __post_init__(self):
        if self.manifest is None:
            object.__setattr__(self, "manifest", {})


class VibeAppRegistry:
    """应用注册中心"""

    def __init__(self):
        self._apps: Dict[str, VibeAppSpec] = {}

    def register(self, spec: VibeAppSpec) -> None:
        """注册一个应用清单"""
        self._apps[spec.app_type] = spec

    def get(self, app_type: str) -> Optional[VibeAppSpec]:
        """按 app_type 获取应用清单"""
        return self._apps.get(app_type)

    def list_app_types(self):
        """返回已注册应用类型列表"""
        return list(self._apps.keys())

    def list_specs(self):
        """返回可序列化的应用清单"""
        return {
            app_type: {
                "app_name": spec.app_name,
                "capabilities": list(spec.capabilities),
                "manifest": dict(spec.manifest or {}),
            }
            for app_type, spec in self._apps.items()
        }

    def require(self, app_type: str) -> VibeAppSpec:
        """按 app_type 获取应用清单，不存在时报错"""
        spec = self.get(app_type)
        if spec is None:
            raise ValueError(
                f"Unsupported app type: {app_type}. "
                f"Supported types: {', '.join(self.list_app_types())}"
            )
        return spec

    def build_app(self, app_type: str, **app_config):
        """按 app_type 创建应用实例"""
        spec = self.require(app_type)
        return spec.app_class(**app_config)

    def bootstrap(self) -> None:
        """加载默认内置应用"""
        from vibe.runtime import app_manifests

        builtin_apps = {
            "wechat": ("vibe.apps.wechat_simulator", "WeChatSimulator"),
            "qq": ("vibe.apps.qq_simulator", "QQSimulator"),
            "qqmusic": ("vibe.apps.qqmusic_simulator", "QQMusicSimulator"),
            "mail": ("vibe.apps.mail_simulator", "MailSimulator"),
            "wework": ("vibe.apps.wework_simulator", "WeWorkSimulator"),
            "dingtalk": ("vibe.apps.chat_alias_simulators", "DingTalkSimulator"),
            "feishu": ("vibe.apps.chat_alias_simulators", "FeishuSimulator"),
            "tencentmeeting": ("vibe.apps.chat_alias_simulators", "TencentMeetingSimulator"),
            "telegram": ("vibe.apps.chat_alias_simulators", "TelegramSimulator"),
            "slack": ("vibe.apps.chat_alias_simulators", "SlackSimulator"),
            "discord": ("vibe.apps.chat_alias_simulators", "DiscordSimulator"),
        }

        for app_type, (module_name, class_name) in builtin_apps.items():
            try:
                module = import_module(module_name)
                app_class = getattr(module, class_name)
            except Exception:
                # 兼容性：某些模块在部署场景下可能缺失时跳过，不中断系统
                continue

            manifest = app_manifests.get_manifest(app_type)
            capabilities = ("chat", "search", "message")
            app_name = app_type
            metadata = {}
            if manifest:
                capabilities = manifest.capabilities
                app_name = manifest.app_name
                metadata = {
                    "manifest_task_types": list(manifest.task_types),
                    **manifest.metadata,
                }

            self.register(
                VibeAppSpec(
                    app_type=app_type,
                    app_name=app_name,
                    app_class=app_class,
                    capabilities=tuple(capabilities),
                    manifest=metadata,
                )
            )

"""WeChat Simulator

基于 ChatApplication 的微信风格仿真应用。
实现微信特有的UI组件和交互逻辑。
"""

from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import random

from vibe.utils.identity_profiles import identity_library_to_tuples
from vibe.core.chat_application import (
    ChatApplication,
    ChatApplicationState,
    ChatWindowState,
    Contact,
    Conversation,
    Message,
    ContactType,
    MessageType,
    MessageStatus,
)
from vibe.core.shared_types import TaskConfig, MouseAction, KeyboardAction, Coordinate


class WeChatSimulator(ChatApplication):
    """微信仿真器

    特点:
    - 微信绿色主题 (#07C160)
    - 左侧导航栏（微信、通讯录、收藏、我）
    - 中间会话列表
    - 右侧聊天区域
    - 支持置顶、免打扰、未读标记等特性

    示例用法:
        >>> app = WeChatSimulator(debug_mode=True)
        >>> app.initialize()
        >>> state, info = app.reset(task_config=task)
        >>> action = Action(...)  # 创建动作
        >>> new_state, reward, done, truncated, info = app.step(action)
    """

    # 微信主题色
    THEME = {
        "primary_color": "#07C160",  # 微信绿
        "primary_hover": "#06AE56",  # 悬停绿
        "sidebar_bg": "#2E2E2E",  # 侧边栏深灰
        "sidebar_selected": "#3E3E3E",  # 侧边栏选中
        "list_bg": "#FFFFFF",  # 列表白
        "list_hover": "#E9E9E9",  # 列表悬停灰
        "list_selected": "#C6C6C6",  # 列表选中灰
        "chat_bg": "#F5F5F5",  # 聊天区背景
        "message_self": "#95EC69",  # 自己消息气泡
        "message_other": "#FFFFFF",  # 对方消息气泡
        "text_primary": "#000000",  # 主文字
        "text_secondary": "#999999",  # 次要文字
    }

    def __init__(self, **kwargs):
        """
        Args:
            **kwargs: 传递给父类的参数
                - window_title: 窗口标题（默认"WeChat (Simulation)"）
                - window_size: 窗口尺寸（默认(1200, 800)）
                - debug_mode: 调试模式
                - user_id: 当前用户ID
                - user_name: 当前用户名
        """
        kwargs.setdefault("window_title", "WeChat (Simulation)")
        super().__init__(**kwargs)

        # 微信特有配置
        self._sidebar_items = [
            {"id": "chat", "icon": "chat", "label": "微信"},
            {"id": "contacts", "icon": "contacts", "label": "通讯录"},
            {"id": "favorites", "icon": "fav", "label": "收藏"},
            {"id": "me", "icon": "me", "label": "我"},
        ]

    # ==================== 生命周期 ====================

    def _on_initialize(self) -> bool:
        """初始化微信UI

        实际实现时，这里应该:
        1. 初始化GUI框架（Qt/GTK等）
        2. 创建主窗口
        3. 设置窗口标题和尺寸
        4. 初始化渲染资源

        Returns:
            bool: 初始化是否成功
        """
        if self.debug_mode:
            print(f"[WeChat] Initializing UI...")

        # TODO: 实现实际的GUI初始化
        # 目前返回True表示初始化成功
        return True

    def _on_reset(
        self, task_config: TaskConfig, options: Dict[str, Any]
    ) -> ChatApplicationState:
        """重置微信状态

        根据task_config生成初始状态，包括:
        - 联系人列表
        - 会话列表
        - 消息历史
        - 根据任务设置初始视图

        Args:
            task_config: 任务配置
            options: 额外选项

        Returns:
            ChatApplicationState: 初始状态
        """
        state = ChatApplicationState()

        # 生成随机数据
        seed = options.get("seed", self._rng.randint(0, 100000))
        num_contacts = options.get("num_contacts", 20)

        # 生成联系人（支持从配置开关切换是否使用在线抓取）
        use_remote_identities = options.get("include_remote_profiles", options.get("identity_include_remote", False))
        if isinstance(use_remote_identities, str):
            use_remote_identities = use_remote_identities.lower() in {"1", "true", "yes", "on", "y"}
        state.contacts = self.generate_contacts(
            count=num_contacts,
            seed=seed,
            include_remote=bool(use_remote_identities),
        )

        # 生成会话（基于部分联系人）
        state.conversations = self.generate_conversations(state.contacts, seed + 1)

        # 为每个会话生成消息历史
        for conv in state.conversations:
            num_messages = self._rng.randint(5, 30)
            conv.messages = self.generate_messages(conv, num_messages, seed + 2)
            if conv.messages:
                last_msg = conv.messages[-1]
                conv.last_message_preview = self._get_message_preview(last_msg)
                conv.last_message_timestamp = last_msg.timestamp

        # 根据任务配置设置初始视图
        initial_view = task_config.initial_state_config.get("view", "main")
        if initial_view in self.VIEWS:
            state.current_view = initial_view
        else:
            state.current_view = "main"

        # 设置窗口状态
        state.window = self._create_window_state(options)

        # 初始化聊天窗口
        state.chat_window = ChatWindowState()

        if self.debug_mode:
            print(
                f"[WeChat] Reset complete: {len(state.contacts)} contacts, "
                f"{len(state.conversations)} conversations"
            )

        return state

    def _create_window_state(self, options: Dict[str, Any]):
        """创建窗口状态"""
        from vibe.core.shared_types import WindowState

        window = WindowState(
            width=self.window_size[0],
            height=self.window_size[1],
        )

        # 如果指定了位置
        if "window_x" in options:
            window.x = options["window_x"]
        if "window_y" in options:
            window.y = options["window_y"]

        return window

    # ==================== 数据生成 ====================

    def generate_contacts(
        self,
        count: int,
        seed: int,
        include_remote: bool = False,
    ) -> List[Contact]:
        """生成微信风格的联系人

        使用稳定样本池生成真实名称联系人，并按种子可复现地注入轻量扰动。

        Args:
            count: 联系人数量
            seed: 随机种子

        Returns:
            联系人列表
        """
        rng = random.Random(seed)
        raw_profiles = identity_library_to_tuples(
            count=count,
            seed=seed,
            include_remote=include_remote,
        )
        if not raw_profiles:
            raw_profiles = identity_library_to_tuples(
                count=count,
                seed=seed,
                include_remote=False,
            )

        contacts = []
        used_names = set()
        if count <= 0:
            return contacts

        for index, (name, contact_type, avatar_url) in enumerate(raw_profiles):
            if name in used_names:
                continue
            if len(contacts) >= count:
                break
            parsed_type = (
                ContactType.INDIVIDUAL
                if contact_type == "individual"
                else ContactType.GROUP
            )

            contacts.append(
                Contact(
                    id=f"contact_{index}",
                    name=name,
                    avatar_url=avatar_url,
                    type=parsed_type,
                    status=rng.choice(["online", "offline", "away", "mobile"]),
                    is_pinned=rng.random() < 0.1,
                    is_muted=rng.random() < 0.15,
                )
            )
            used_names.add(name)

        if len(contacts) < count:
            fallback_profiles = identity_library_to_tuples(
                count=count * 2,
                seed=seed + 17,
                include_remote=False,
            )
            fallback_pointer = 0
            fallback_limit = len(fallback_profiles) if fallback_profiles else 0
            while len(contacts) < count and fallback_profiles:
                if fallback_pointer >= max(1, fallback_limit * 3):
                    break
                profile = fallback_profiles[fallback_pointer % len(fallback_profiles)]
                fallback_pointer += 1
                name = profile[0]
                if name in used_names:
                    continue

                parsed_type = (
                    ContactType.INDIVIDUAL
                    if profile[1] == "individual"
                    else ContactType.GROUP
                )
                contacts.append(
                    Contact(
                        id=f"contact_{len(contacts)}",
                        name=name,
                        avatar_url=profile[2],
                        type=parsed_type,
                        status=rng.choice(["online", "offline", "away", "mobile"]),
                        is_pinned=rng.random() < 0.1,
                        is_muted=rng.random() < 0.15,
                    )
                )
                used_names.add(name)

        if len(contacts) < count:
            fallback_source = identity_library_to_tuples(
                count=count,
                seed=seed + 31,
                include_remote=False,
            )
            fallback_len = len(fallback_source)
            for idx in range(count - len(contacts)):
                if fallback_len == 0:
                    break
                fallback_index = idx % fallback_len
                name, contact_type, avatar_url = fallback_source[fallback_index]

                parsed_type = (
                    ContactType.INDIVIDUAL
                    if contact_type == "individual"
                    else ContactType.GROUP
                )
                contacts.append(
                    Contact(
                        id=f"contact_{len(contacts)}",
                        name=name,
                        avatar_url=avatar_url,
                        type=parsed_type,
                        status=rng.choice(["online", "offline", "away", "mobile"]),
                        is_pinned=rng.random() < 0.1,
                        is_muted=rng.random() < 0.15,
                    )
                )
                used_names.add(name)

        return contacts

    def generate_conversations(
        self, contacts: List[Contact], seed: int
    ) -> List[Conversation]:
        """生成会话列表

        基于联系人生成会话，80%的联系人会有活跃会话。

        Args:
            contacts: 联系人列表
            seed: 随机种子

        Returns:
            会话列表（已按置顶和时间排序）
        """
        random.seed(seed)

        # 80%的联系人有活跃会话
        num_conversations = int(len(contacts) * 0.8)
        selected_contacts = random.sample(contacts, num_conversations)

        conversations = []
        for contact in selected_contacts:
            conv = Conversation(
                id=f"conv_{contact.id}",
                contact_id=contact.id,
                display_name=contact.name,
                contact_type=contact.type,
                avatar_url=contact.avatar_url,
                unread_count=random.randint(0, 5) if random.random() < 0.3 else 0,
                is_pinned=contact.is_pinned,
                is_muted=contact.is_muted,
            )
            conversations.append(conv)

        # 排序：置顶项在前，其次按最后消息时间倒序
        conversations.sort(
            key=lambda x: (
                not x.is_pinned,  # True(1)在后，False(0)在前
                -(
                    x.last_message_timestamp.timestamp()
                    if x.last_message_timestamp
                    else 0
                ),
            )
        )

        return conversations

    def generate_messages(
        self, conversation: Conversation, count: int, seed: int
    ) -> List[Message]:
        """生成消息历史

        Args:
            conversation: 目标会话
            count: 消息数量
            seed: 随机种子

        Returns:
            消息列表
        """
        random.seed(seed)

        messages = []
        base_time = datetime.now() - timedelta(hours=random.randint(1, 72))

        # 消息模板
        text_templates = [
            "在吗？",
            "明天下午{time}开会",
            "好的，收到了",
            "这个方案我觉得可以",
            "帮我看一下这个文件",
            "谢谢！",
            "[图片]",
            "[文件] {filename}",
            "在忙吗？",
            "晚上一起吃饭？",
            "项目进度怎么样了？",
            "文件发你邮箱了",
            "稍等一下",
            "明天见",
            "收到，马上处理",
        ]

        for i in range(count):
            # 40%消息是自己发的
            is_self = random.random() < 0.4
            sender_id = self._current_user_id if is_self else conversation.contact_id
            sender_name = (
                self._current_user_name if is_self else conversation.display_name
            )

            # 选择模板并填充
            template = random.choice(text_templates)
            content_text = template.format(
                time=f"{random.randint(9, 18)}:{random.choice(['00', '30'])}",
                filename=f"报告{random.randint(1, 10)}.pdf",
            )

            # 确定消息类型
            if "[图片]" in content_text:
                msg_type = MessageType.IMAGE
            elif "[文件]" in content_text:
                msg_type = MessageType.FILE
            else:
                msg_type = MessageType.TEXT

            # 消息状态
            if is_self:
                status = random.choice(
                    [MessageStatus.SENT, MessageStatus.DELIVERED, MessageStatus.READ]
                )
            else:
                status = MessageStatus.READ

            msg = Message(
                id=f"msg_{conversation.id}_{i}",
                conversation_id=conversation.id,
                sender_id=sender_id,
                sender_name=sender_name,
                type=msg_type,
                content=self._create_message_content(content_text, msg_type),
                timestamp=base_time + timedelta(minutes=i * random.randint(3, 20)),
                status=status,
            )
            messages.append(msg)

        return messages

    # ==================== 交互处理 ====================

    def _on_open_conversation(self, conversation_id: str) -> bool:
        """打开会话的具体实现"""
        if not isinstance(self._state, ChatApplicationState):
            return False

        # 查找会话
        for index, conv in enumerate(self._state.conversations):
            if conv.id == conversation_id:
                # 更新状态
                self._state.selected_conversation_id = conversation_id
                self._state.selected_conversation_index = index
                self._state.current_conversation = conv
                self._state.current_view = "chat"

                # 清除未读
                conv.unread_count = 0

                # 重置输入框
                self._state.chat_window = ChatWindowState()

                if self.debug_mode:
                    print(f"[WeChat] Opened conversation: {conv.display_name}")

                return True

        if self.debug_mode:
            print(f"[WeChat] Conversation not found: {conversation_id}")

        return False

    def _on_search_contacts(self, query: str) -> List[Contact]:
        """搜索联系人/会话"""
        if not isinstance(self._state, ChatApplicationState):
            return []

        query = query.lower()
        results = []

        # 搜索联系人
        for contact in self._state.contacts:
            if query in contact.name.lower():
                results.append(contact)

        # 搜索会话（基于联系人）
        for conv in self._state.conversations:
            if query in conv.display_name.lower():
                # 找到对应的联系人
                for contact in self._state.contacts:
                    if contact.id == conv.contact_id:
                        if contact not in results:
                            results.append(contact)
                        break

        return results

    def _on_forward_message(self, message_id: str, target_conversation_id: str) -> bool:
        """转发消息"""
        if not isinstance(self._state, ChatApplicationState):
            return False

        # 查找原消息
        original_msg = None
        if self._state.current_conversation:
            for msg in self._state.current_conversation.messages:
                if msg.id == message_id:
                    original_msg = msg
                    break

        if not original_msg:
            return False

        # 查找目标会话
        target_conv = None
        for conv in self._state.conversations:
            if conv.id == target_conversation_id:
                target_conv = conv
                break

        if not target_conv:
            return False

        # 创建转发消息
        forwarded_msg = Message(
            id=f"msg_forwarded_{self._step_count}",
            conversation_id=target_conversation_id,
            sender_id=self._current_user_id,
            sender_name=self._current_user_name,
            type=original_msg.type,
            content=original_msg.content.copy(),
            timestamp=datetime.now(),
            status=MessageStatus.SENT,
        )

        # 添加到目标会话
        target_conv.messages.append(forwarded_msg)
        target_conv.last_message_preview = self._get_message_preview(forwarded_msg)
        target_conv.last_message_timestamp = forwarded_msg.timestamp

        return True

    def _hit_test(self, coordinate: Coordinate) -> Optional[Dict[str, Any]]:
        """坐标碰撞检测

        将归一化坐标映射到UI元素。

        微信布局:
        - 左侧导航栏: x=[0.0, 0.05]
        - 会话列表: x=[0.05, 0.28]
        - 聊天区域: x=[0.28, 1.0]
        """
        x, y = coordinate.x, coordinate.y

        if not isinstance(self._state, ChatApplicationState):
            return None

        # 左侧导航栏
        if x < 0.05:
            item_index = int(y * 4)  # 4个导航项
            if 0 <= item_index < len(self._sidebar_items):
                return {
                    "type": "sidebar_item",
                    "id": self._sidebar_items[item_index]["id"],
                    "bounds": (0, item_index * 0.25, 0.05, 0.25),
                }
            return None

        # 会话列表区域
        elif x < 0.28:
            if self._state.current_view == "main":
                # 会话列表项
                item_height = 0.1  # 每个会话占10%高度
                item_index = int((y - 0.1) / item_height)  # 0.1偏移是给搜索框

                if item_index >= 0 and item_index < len(self._state.conversations):
                    conv = self._state.conversations[item_index]
                    return {
                        "type": "conversation_item",
                        "id": conv.id,
                        "contact_id": conv.contact_id,
                        "name": conv.display_name,
                        "bounds": (
                            0.05,
                            0.1 + item_index * item_height,
                            0.23,
                            item_height,
                        ),
                    }

                # 搜索框区域
                if y < 0.1:
                    return {
                        "type": "search_box",
                        "id": "search",
                        "bounds": (0.05, 0.0, 0.23, 0.1),
                    }

            return None

        # 聊天区域
        else:
            if self._state.current_view == "chat":
                # 消息区域
                if y < 0.85:
                    return {
                        "type": "message_area",
                        "id": "messages",
                        "bounds": (0.28, 0.0, 0.72, 0.85),
                    }

                # 输入框
                elif y < 0.92:
                    return {
                        "type": "input_box",
                        "id": "input",
                        "text": self._state.chat_window.input_text,
                        "bounds": (0.28, 0.85, 0.72, 0.07),
                    }

                # 发送按钮
                else:
                    return {
                        "type": "send_button",
                        "id": "send",
                        "enabled": bool(self._state.chat_window.input_text.strip()),
                        "bounds": (0.85, 0.92, 0.15, 0.08),
                    }

            return None

    def _handle_element_interaction(
        self, element: Dict[str, Any], mouse_action: MouseAction
    ) -> Dict[str, Any]:
        """处理元素交互"""
        element_type = element.get("type", "")
        element_id = element.get("id", "")

        if mouse_action.subtype.name == "CLICK":
            if element_type == "conversation_item":
                # 点击会话项 - 打开会话
                success = self.open_conversation(element_id)
                return {
                    "success": success,
                    "message": f"Opened conversation: {element.get('name', '')}"
                    if success
                    else "Failed to open",
                    "effects": ["conversation_opened"] if success else [],
                }

            elif element_type == "sidebar_item":
                # 点击导航项
                if element_id == "chat":
                    self.switch_view("main")
                    return {"success": True, "message": "", "effects": ["view_changed"]}
                elif element_id == "contacts":
                    self.switch_view("contacts")
                    return {"success": True, "message": "", "effects": ["view_changed"]}

            elif element_type == "search_box":
                # 点击搜索框 - 切换到搜索视图
                self.switch_view("search")
                return {
                    "success": True,
                    "message": "",
                    "effects": ["view_changed", "focus_search"],
                }

            elif element_type == "send_button":
                # 点击发送按钮
                if (
                    self._state.current_conversation
                    and self._state.chat_window.input_text.strip()
                ):
                    success = self.send_message(
                        self._state.current_conversation.id,
                        self._state.chat_window.input_text,
                        MessageType.TEXT,
                    )

                    if success:
                        self._state.chat_window.input_text = ""
                        self._state.chat_window.input_cursor_pos = 0
                        return {
                            "success": True,
                            "message": "Message sent",
                            "effects": ["message_sent"],
                        }

                return {"success": False, "message": "Nothing to send", "effects": []}

            elif element_type == "input_box":
                # 点击输入框 - 聚焦
                return {"success": True, "message": "", "effects": ["focus_input"]}

        # 其他鼠标动作类型（双击、右键等）
        return {"success": True, "message": "", "effects": []}

    # ==================== 渲染 ====================

    def render(self, mode: str = "human") -> Optional[Any]:
        """渲染微信UI

        TODO: 实现实际的GUI渲染

        Args:
            mode: "human" 显示在屏幕上，"rgb_array" 返回数组

        Returns:
            根据mode返回不同结果
        """
        if mode == "human":
            # 更新GUI显示
            # TODO: 实现实际渲染
            if self.debug_mode and self._step_count % 10 == 0:
                print(
                    f"[WeChat] Render step {self._step_count}, view: {self._state.current_view if self._state else 'none'}"
                )
            return None

        elif mode == "rgb_array":
            # 返回RGB数组
            # TODO: 实现屏幕截图/渲染
            import numpy as np

            return np.zeros(
                (self.window_size[1], self.window_size[0], 3), dtype=np.uint8
            )

        return None

    # ==================== 关闭 ====================

    def _on_close(self) -> None:
        """关闭应用"""
        if self.debug_mode:
            print(f"[WeChat] Closing...")
        # TODO: 清理GUI资源

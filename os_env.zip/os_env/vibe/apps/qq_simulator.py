"""QQ Simulator

QQ PC 客户端的轻量仿真实现。
这里不复制微信 UI 代码，仅复用 ChatApplication 的 IM 行为骨架，
并通过标题和元信息区分应用类型，方便 hook 与任务映射。
"""

from vibe.apps.wechat_simulator import WeChatSimulator


class QQSimulator(WeChatSimulator):
    """QQ 仿真器"""

    def __init__(self, **kwargs):
        kwargs.setdefault("window_title", "QQ (Simulation)")
        super().__init__(**kwargs)


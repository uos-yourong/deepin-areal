"""Alias Chat Simulators.

为常见 PC 聊天软件提供“能力复用式”实现。
这些应用不改变微信主 UI（wechat 模拟器不改），
仅复用其行为骨架与状态机，便于在同一套 hook 规则体系下扩展多应用。
"""

from vibe.apps.wechat_simulator import WeChatSimulator


class DingTalkSimulator(WeChatSimulator):
    """DingTalk (Simulation)"""

    def __init__(self, **kwargs):
        kwargs.setdefault("window_title", "DingTalk (Simulation)")
        super().__init__(**kwargs)


class FeishuSimulator(WeChatSimulator):
    """Feishu (Lark) (Simulation)"""

    def __init__(self, **kwargs):
        kwargs.setdefault("window_title", "Feishu (Simulation)")
        super().__init__(**kwargs)


class TelegramSimulator(WeChatSimulator):
    """Telegram (Simulation)"""

    def __init__(self, **kwargs):
        kwargs.setdefault("window_title", "Telegram (Simulation)")
        super().__init__(**kwargs)


class SlackSimulator(WeChatSimulator):
    """Slack (Simulation)"""

    def __init__(self, **kwargs):
        kwargs.setdefault("window_title", "Slack (Simulation)")
        super().__init__(**kwargs)


class DiscordSimulator(WeChatSimulator):
    """Discord (Simulation)"""

    def __init__(self, **kwargs):
        kwargs.setdefault("window_title", "Discord (Simulation)")
        super().__init__(**kwargs)


class TencentMeetingSimulator(WeChatSimulator):
    """Tencent Meeting (Simulation)"""

    def __init__(self, **kwargs):
        kwargs.setdefault("window_title", "Tencent Meeting (Simulation)")
        super().__init__(**kwargs)


class NetEaseMusicSimulator(WeChatSimulator):
    """网易云音乐（规则化）"""

    def __init__(self, **kwargs):
        kwargs.setdefault("window_title", "网易云音乐 (Simulation)")
        super().__init__(**kwargs)

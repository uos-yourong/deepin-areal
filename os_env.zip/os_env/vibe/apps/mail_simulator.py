"""Mail Simulator

邮箱仿真器（规则任务版）：
支持 open_folder / open_mail / mark_as_read / reply_mail 的行为钩子检测。
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from vibe.core.base_application import BaseApplication
from vibe.core.shared_types import (
    Action,
    ActionType,
    ApplicationState,
    Coordinate,
    KeyboardAction,
    KeyboardActionType,
    MouseAction,
    MouseActionType,
    TaskConfig,
    WindowState,
)


@dataclass
class MailItem:
    mail_id: str
    sender: str
    subject: str
    content: str
    is_read: bool = False


@dataclass
class MailState(ApplicationState):
    folders: List[str] = field(default_factory=lambda: ["INBOX", "工作", "通知", "垃圾箱"])
    current_folder: str = "INBOX"
    mail_ids: List[str] = field(default_factory=list)
    mail_dict: Dict[str, MailItem] = field(default_factory=dict)
    current_mail_id: Optional[str] = None
    current_mail_read: Optional[bool] = None
    current_mail_content: Optional[str] = None
    selected_mail_index: Optional[int] = None
    reply_mode: bool = False
    reply_sent: bool = False
    reply_text: str = ""
    current_view: str = "list"


class MailSimulator(BaseApplication):
    """轻量邮箱仿真应用"""

    def __init__(
        self,
        window_title: str = "Mail (Simulation)",
        window_size: Tuple[int, int] = (1200, 800),
        debug_mode: bool = False,
        **kwargs,
    ):
        super().__init__(window_title=window_title, window_size=window_size, debug_mode=debug_mode, **kwargs)

    def _on_initialize(self) -> bool:
        return True

    def _seed_mails(self) -> Dict[str, List[MailItem]]:
        return {
            "INBOX": [
                MailItem("m_001", "财务小助手", "月度报销审批提醒", "请在今天17:00前提交月度报销"),
                MailItem("m_002", "产品组", "周会纪要", "本周计划如下"),
                MailItem("m_003", "IT 部", "VPN 账号到期提醒", "请尽快更换密码"),
            ],
            "工作": [
                MailItem("w_001", "主管", "项目排期更新", "明天开评审会"),
                MailItem("w_002", "设计部", "素材提交确认", "图文素材已确认"),
            ],
            "通知": [
                MailItem("n_001", "系统", "安全公告", "新增登录策略，明日生效"),
            ],
            "垃圾箱": [
                MailItem("d_001", "垃圾", "测试邮件", "无效内容"),
            ],
        }

    def _on_reset(
        self, task_config: TaskConfig, options: Dict[str, Any]
    ) -> MailState:
        state = MailState()
        state.window = WindowState(
            width=self.window_size[0], height=self.window_size[1], x=self._rng.randint(0, 30), y=self._rng.randint(0, 30)
        )

        mail_data = self._seed_mails()
        state.current_folder = options.get("initial_folder", task_config.target.get("folder", "INBOX"))
        if state.current_folder not in mail_data:
            state.current_folder = "INBOX"

        mailbox = mail_data[state.current_folder]
        state.mail_ids = [item.mail_id for item in mailbox]
        state.mail_dict = {item.mail_id: item for item in mailbox}
        state.current_view = task_config.initial_state_config.get("view", "list")
        state.reply_mode = False
        state.reply_sent = False
        state.reply_text = ""
        state.current_mail_read = None
        return state

    def _on_mouse_action(self, mouse_action: MouseAction) -> Dict[str, Any]:
        state = self._state
        if not isinstance(state, MailState):
            return {"success": False, "message": "Invalid state", "effects": []}

        x, y = mouse_action.coordinate.x, mouse_action.coordinate.y
        if mouse_action.subtype != MouseActionType.CLICK:
            return {"success": False, "message": "Unsupported mouse action", "effects": []}

        # 左侧文件夹
        if x < 0.24 and y >= 0.06:
            idx = min(max(int((y - 0.06) / 0.12), 0), len(state.folders) - 1)
            state.current_folder = state.folders[idx]
            state.current_mail_id = None
            state.current_mail_content = None
            state.selected_mail_index = None
            state.current_mail_read = None
            state.current_view = "list"
            folder_items = self._seed_mails()[state.current_folder]
            state.mail_dict = {item.mail_id: item for item in folder_items}
            state.mail_ids = [item.mail_id for item in folder_items]
            return {"success": True, "message": "", "effects": ["folder_opened"]}

        # 列表项
        if x >= 0.24 and y >= 0.12 and y <= 0.9 and state.mail_ids:
            idx = min(max(int((y - 0.12) / 0.1), 0), len(state.mail_ids) - 1)
            mail_id = state.mail_ids[idx]
            state.current_mail_id = mail_id
            mail = state.mail_dict[mail_id]
            previous_read = bool(mail.is_read)
            state.current_mail_content = mail.content
            state.selected_mail_index = idx
            state.reply_mode = False
            state.reply_sent = False
            state.reply_text = ""
            state.current_view = "detail"

            mail.is_read = True
            state.current_mail_read = True
            effects = ["mail_opened"]
            if not previous_read:
                effects.append("mail_marked_read")

            return {"success": True, "message": "", "effects": effects}

        # 回复按钮
        if state.current_view == "detail" and x > 0.88 and y > 0.9:
            state.reply_mode = True
            state.reply_sent = False
            state.reply_text = ""
            return {"success": True, "message": "", "effects": ["reply_started"]}

        return {"success": False, "message": "No target", "effects": []}

    def _on_keyboard_action(self, keyboard_action: KeyboardAction) -> Dict[str, Any]:
        state = self._state
        if not isinstance(state, MailState):
            return {"success": False, "message": "Invalid state", "effects": []}

        if keyboard_action.subtype == KeyboardActionType.TYPE_TEXT and state.reply_mode:
            state.reply_text += keyboard_action.text or ""
            return {"success": True, "message": "", "effects": ["reply_typing"]}

        if keyboard_action.subtype == KeyboardActionType.KEY_PRESS:
            key = (keyboard_action.key or "").lower()
            if key in ("return", "enter") and state.reply_mode:
                if state.reply_text:
                    state.reply_mode = False
                    state.reply_sent = True
                    return {"success": True, "message": "reply sent", "effects": ["reply_sent"]}
            if key == "escape" and state.reply_mode:
                state.reply_mode = False
                state.reply_sent = False
                state.reply_text = ""
                return {"success": True, "message": "", "effects": ["reply_cancel"]}

        return {"success": False, "message": "Unsupported key", "effects": []}

    def _on_step(self, action: Action, action_result: Dict[str, Any]) -> MailState:
        state = self._state
        if not isinstance(state, MailState):
            return MailState()
        copied = state.copy()
        if hasattr(action, "timestamp"):
            copied.timestamp = action.timestamp
        copied.step_count = self._step_count
        return copied

    def _compute_progress_reward(self, prev_state: ApplicationState, new_state: ApplicationState) -> float:
        return 0.0

    def _check_termination(self, state: ApplicationState) -> Tuple[bool, bool]:
        if not isinstance(state, MailState) or self._current_task is None:
            return False, False

        task_type = (
            self._current_task.task_type.value
            if hasattr(self._current_task.task_type, "value")
            else str(self._current_task.task_type)
        )

        if task_type == "open_folder":
            target_folder = self._current_task.target.get("folder")
            return bool(target_folder and state.current_folder == target_folder), True
        if task_type == "open_mail":
            target_mail = self._current_task.target.get("mail_id")
            if target_mail:
                return state.current_mail_id == target_mail and state.current_mail_content is not None, True
            target_subject = self._current_task.target.get("subject")
            if target_subject and state.current_mail_id:
                item = state.mail_dict.get(state.current_mail_id)
                return item is not None and item.subject == target_subject, True
            return state.current_mail_id is not None, True
        if task_type == "mark_as_read":
            if state.current_mail_id:
                item = state.mail_dict.get(state.current_mail_id)
                return (
                    item is not None
                    and bool(item.is_read)
                    and state.current_mail_read is True
                ), True
        if task_type == "reply_mail":
            return bool(state.current_mail_id and state.reply_sent), True

        return bool(self._current_task.success_conditions), False

    def _on_randomization(self, config: Dict[str, Any]) -> None:
        # 目前不做随机化
        pass

    def _on_get_legal_actions(self) -> List[Action]:
        if not isinstance(self._state, MailState):
            return []
        return [
            Action(
                type=ActionType.MOUSE,
                mouse_action=MouseAction(
                    subtype=MouseActionType.CLICK,
                    coordinate=Coordinate(0.15, 0.2),
                ),
            )
        ]

    def render(self, mode: str = "human"):
        if mode == "rgb_array":
            return np.zeros((self.window_size[1], self.window_size[0], 3), dtype=np.uint8)
        return None

    def _on_close(self) -> None:
        pass

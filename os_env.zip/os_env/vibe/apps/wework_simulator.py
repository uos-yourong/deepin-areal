"""WeWork Simulator

企业微信仿真器。
当前阶段复用 IM 行为框架（联系人列表、会话、消息）即可支持训练任务闭环。
后续可按需要进一步补齐企业特有控件与状态。
"""

from vibe.apps.wechat_simulator import WeChatSimulator


class WeWorkSimulator(WeChatSimulator):
    """企业微信仿真器"""

    def __init__(self, **kwargs):
        kwargs.setdefault("window_title", "企业微信 (Simulation)")
        super().__init__(**kwargs)


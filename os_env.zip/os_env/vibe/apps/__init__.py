"""Application package for Vibe desktop simulators."""

from vibe.apps.mail_simulator import MailSimulator
from vibe.apps.qq_simulator import QQSimulator
from vibe.apps.qqmusic_simulator import QQMusicSimulator
from vibe.apps.wechat_simulator import WeChatSimulator
from vibe.apps.wework_simulator import WeWorkSimulator
from vibe.apps.chat_alias_simulators import (
    DingTalkSimulator,
    DiscordSimulator,
    FeishuSimulator,
    TencentMeetingSimulator,
    SlackSimulator,
    TelegramSimulator,
    NetEaseMusicSimulator,
)

__all__ = [
    "MailSimulator",
    "QQSimulator",
    "QQMusicSimulator",
    "WeChatSimulator",
    "WeWorkSimulator",
    "DingTalkSimulator",
    "DiscordSimulator",
    "FeishuSimulator",
    "TencentMeetingSimulator",
    "SlackSimulator",
    "TelegramSimulator",
    "NetEaseMusicSimulator",
]

"""QQMusic Simulator

面向规则化任务的轻量化 QQMusic PC 端仿真器。
核心目标不是播放真实音乐，而是提供可核验的结构化状态与可控动作。
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from vibe.core.base_application import BaseApplication
from vibe.core.shared_types import (
    Action,
    ActionType,
    ApplicationState,
    Coordinate,
    KeyboardAction,
    KeyboardActionType,
    MouseAction,
    MouseActionType,
    TaskConfig,
    WindowState,
)


@dataclass
class Song:
    song_id: str
    title: str
    artist: str


@dataclass
class QQMusicState(ApplicationState):
    library: List[Song] = field(default_factory=list)
    playlists: Dict[str, List[str]] = field(default_factory=dict)
    current_view: str = "home"
    search_query: str = ""
    search_results: List[str] = field(default_factory=list)
    current_song: Optional[Song] = None
    current_playlist: str = "recommend"
    selected_track_index: Optional[int] = None
    is_playing: bool = False
    playback_progress: int = 0
    last_played_song_id: Optional[str] = None
    active_song_id: Optional[str] = None
    playback_state: str = "stopped"
    search_completed: bool = False


class QQMusicSimulator(BaseApplication):
    """QQMusic 状态机仿真器（简化版）"""

    def __init__(
        self,
        window_title: str = "QQMusic (Simulation)",
        window_size: Tuple[int, int] = (1200, 800),
        debug_mode: bool = False,
        **kwargs,
    ):
        self._volume = kwargs.pop("volume", 60)
        super().__init__(window_title=window_title, window_size=window_size, debug_mode=debug_mode, **kwargs)

    def _on_initialize(self) -> bool:
        return True

    def _default_library(self) -> List[Song]:
        return [
            Song("song_yequ", "夜曲", "周杰伦"),
            Song("song_daoxiang", "稻香", "周杰伦"),
            Song("song_sun", "小幸运", "田馥甄"),
            Song("song_blue", "蓝莲花", "许巍"),
            Song("song_city", "平凡之路", "朴树"),
        ]

    def _on_reset(
        self, task_config: TaskConfig, options: Dict[str, Any]
    ) -> QQMusicState:
        state = QQMusicState()
        state.window = WindowState(
            width=self.window_size[0], height=self.window_size[1], x=self._rng.randint(0, 30), y=self._rng.randint(0, 30)
        )
        state.library = self._default_library()
        state.playlists = {
            "recommend": [song.song_id for song in state.library],
            "favorites": ["song_daoxiang", "song_sun"],
        }

        if options:
            state.current_playlist = options.get(
                "initial_playlist", state.current_playlist
            )
            if "initial_song_id" in options:
                state.current_song = self._get_song_by_id(state.library, options["initial_song_id"])

        state.search_query = options.get("search_query", "")
        state.current_view = options.get("initial_view", "home")
        if task_config.initial_state_config:
            state.current_view = task_config.initial_state_config.get(
                "view", state.current_view
            )
            if "playlist" in task_config.initial_state_config:
                state.current_playlist = task_config.initial_state_config["playlist"]
            if "search_query" in task_config.initial_state_config:
                state.search_query = task_config.initial_state_config["search_query"]

        if state.current_song is None:
            # 随机化场景下也保持首首可控
            state.current_song = state.library[0]

        # 重置播放与搜索动作上下文，避免跨任务状态污染
        state.is_playing = False
        state.last_played_song_id = None
        state.active_song_id = None
        state.playback_state = "stopped"
        state.search_completed = False
        return state

    def _set_playback(self, play: bool) -> Dict[str, Any]:
        """统一更新播放状态，保证 hook 状态单字段可判定。"""
        state = self._state
        if not isinstance(state, QQMusicState):
            return {"success": False, "message": "Invalid state", "effects": []}

        if state.current_song is None:
            return {"success": False, "message": "No song selected", "effects": []}

        if play:
            state.is_playing = True
            state.last_played_song_id = state.current_song.song_id
            state.active_song_id = state.current_song.song_id
            state.playback_state = "playing"
            return {
                "success": True,
                "message": "",
                "effects": ["playback_toggled", "playback_started"],
            }

        # 暂停或停止
        state.is_playing = False
        if state.playback_state == "playing":
            state.playback_state = "paused"
        return {
            "success": True,
            "message": "",
            "effects": ["playback_toggled", "playback_stopped"],
        }

    def _get_song_by_id(self, library: List[Song], song_id: str) -> Optional[Song]:
        for song in library:
            if song.song_id == song_id:
                return song
        return None

    def _on_mouse_action(self, mouse_action: MouseAction) -> Dict[str, Any]:
        state = self._state
        if not isinstance(state, QQMusicState):
            return {"success": False, "message": "Invalid state", "effects": []}

        x, y = mouse_action.coordinate.x, mouse_action.coordinate.y
        if mouse_action.subtype == MouseActionType.CLICK:
            # 顶栏：切换歌曲列表（两个示例歌单）
            if y < 0.14:
                if x < 0.2:
                    state.current_playlist = "recommend"
                    state.current_view = "playlist"
                    return {"success": True, "message": "", "effects": ["playlist_changed"]}
                if x < 0.4:
                    state.current_playlist = "favorites"
                    state.current_view = "playlist"
                    return {"success": True, "message": "", "effects": ["playlist_changed"]}

            # 搜索框
            if y < 0.14 and x >= 0.2:
                state.current_view = "search"
                state.search_completed = False
                return {"success": True, "message": "", "effects": ["view_changed", "focus_search"]}

            # 播放/暂停
            if x > 0.86 and y > 0.9:
                next_state = not state.is_playing
                return self._set_playback(next_state)

            # 点击列表/搜索结果
            if y >= 0.14 and y <= 0.88:
                source = state.library
                if state.current_view == "search":
                    source = [self._get_song_by_id(state.library, sid) for sid in state.search_results]
                    source = [s for s in source if s is not None]

                if not source:
                    return {"success": False, "message": "Empty list", "effects": []}

                # Add small epsilon to avoid float precision rounding down near boundary values.
                idx = min(max(int((y - 0.14) / 0.08 + 1e-6), 0), len(source) - 1)
                state.selected_track_index = idx
                state.current_song = source[idx]
                state.current_view = "playlist"
                state.active_song_id = None
                return {"success": True, "message": "", "effects": ["song_selected"]}

        return {"success": False, "message": "No target", "effects": []}

    def _on_keyboard_action(self, keyboard_action: KeyboardAction) -> Dict[str, Any]:
        state = self._state
        if not isinstance(state, QQMusicState):
            return {"success": False, "message": "Invalid state", "effects": []}

        if keyboard_action.subtype == KeyboardActionType.TYPE_TEXT:
            if state.current_view == "search":
                value = keyboard_action.text or ""
                state.search_query = (state.search_query or "") + value
                state.search_completed = False
                return {"success": True, "message": "", "effects": ["input_changed"]}
            return {"success": False, "message": "Input not in search view", "effects": []}

        if keyboard_action.subtype == KeyboardActionType.KEY_PRESS:
            key = (keyboard_action.key or "").lower()
            if key in ("return", "enter"):
                if state.current_view == "search" and state.search_query:
                    state.search_results = [
                        song.song_id
                        for song in state.library
                        if state.search_query in song.title
                        or state.search_query in song.artist
                    ]
                    if state.search_results:
                        state.current_view = "search_result"
                        state.current_song = self._get_song_by_id(
                            state.library, state.search_results[0]
                        )
                        state.selected_track_index = 0
                        state.search_completed = True
                        return {"success": True, "message": "", "effects": ["search_complete"]}
                    return {"success": False, "message": "No match", "effects": []}

                if state.current_song:
                    next_state = not state.is_playing
                    return self._set_playback(next_state)

            elif key == "backspace":
                if state.current_view == "search":
                    state.search_query = state.search_query[:-1]
                    return {"success": True, "message": "", "effects": ["input_changed"]}

        return {"success": False, "message": "Unsupported key", "effects": []}

    def _on_step(self, action: Action, action_result: Dict[str, Any]) -> QQMusicState:
        state = self._state
        if not isinstance(state, QQMusicState):
            return QQMusicState()

        if state.is_playing and state.current_song is not None:
            state.playback_progress = (state.playback_progress + 1) % 1000

        state_copy = state.copy()
        if isinstance(action, Action):
            state_copy.step_count = self._step_count
            state_copy.timestamp = action.timestamp
        return state_copy

    def _compute_progress_reward(self, prev_state: ApplicationState, new_state: ApplicationState) -> float:
        return 0.0

    def _check_termination(self, state: ApplicationState) -> Tuple[bool, bool]:
        if not isinstance(state, QQMusicState) or self._current_task is None:
            return False, False

        task_type = (
            self._current_task.task_type.value
            if hasattr(self._current_task.task_type, "value")
            else str(self._current_task.task_type)
        )

        if task_type == "search_music":
            query = self._current_task.target.get("query")
            return bool(query and query == state.search_query and state.search_completed), True
        if task_type == "play_song":
            target_id = self._current_task.target.get("song_id")
            return bool(
                target_id and state.active_song_id == target_id and state.playback_state == "playing"
            ), True
        if task_type == "pause_playback":
            return bool(
                state.playback_state == "paused" and state.last_played_song_id is not None
            ), True
        if task_type == "open_playlist":
            target_playlist = self._current_task.target.get("playlist")
            return bool(target_playlist and state.current_playlist == target_playlist), True

        return bool(self._current_task.success_conditions), False

    def _on_randomization(self, config: Dict[str, Any]) -> None:
        # 简化版无额外随机化
        pass

    def _on_get_legal_actions(self) -> List[Action]:
        if not isinstance(self._state, QQMusicState):
            return []
        return [
            Action(
                type=ActionType.MOUSE,
                mouse_action=MouseAction(
                    subtype=MouseActionType.CLICK,
                    coordinate=Coordinate(0.3, 0.1),
                ),
            )
        ]

    def render(self, mode: str = "human") -> Optional[np.ndarray]:
        if mode == "rgb_array":
            return np.zeros((self.window_size[1], self.window_size[0], 3), dtype=np.uint8)
        return None

    def _on_close(self) -> None:
        # 无额外资源释放
        pass

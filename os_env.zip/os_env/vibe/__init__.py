"""Vibe - 仿真桌面应用训练环境

提供用于强化学习训练的GUI仿真环境，支持IM类应用的视觉和交互仿真。
"""

__version__ = "0.1.0"
__author__ = "Vibe Team"

from vibe.core.shared_types import (
    Action,
    ActionType,
    MouseAction,
    MouseActionType,
    KeyboardAction,
    KeyboardActionType,
    Coordinate,
    Observation,
    RewardComponents,
    TaskConfig,
    TaskType,
    ApplicationState,
    WindowState,
)

from vibe.core.base_application import BaseApplication
from vibe.core.chat_application import ChatApplication

__all__ = [
    # 数据类型
    "Action",
    "ActionType",
    "MouseAction",
    "MouseActionType",
    "KeyboardAction",
    "KeyboardActionType",
    "Coordinate",
    "Observation",
    "RewardComponents",
    "TaskConfig",
    "TaskType",
    "ApplicationState",
    "WindowState",
    # 核心类
    "BaseApplication",
    "ChatApplication",
]

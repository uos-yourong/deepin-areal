"""External VLM reward judge for Deepin GRPO rollouts.

Sends the final screenshot of a trajectory plus the task instruction to an
OpenAI-compatible chat API and converts the two predicted metrics into a
weighted scalar reward.

Two modes:

- Real API: pass ``api_base``/``model`` explicitly or via env vars
  (``VLM_API_BASE`` / ``VLM_API_KEY`` / ``VLM_API_MODEL``). One chat call per
  trajectory, JSON-in-text parsing, ``None`` on any failure (the workflow
  drops that trajectory via its existing failure semantics).
- Mock (current default while the real reward logic is pending): when no
  api_base/model is configured — or ``VLM_API_BASE=mock`` — ``score()``
  returns a deterministic pseudo-random scalar derived from the
  (instruction, screenshot) pair, without any network call. The value varies
  per trajectory so GRPO advantages are non-degenerate during smoke runs.

Configuration priority: explicit constructor args > environment variables.

    VLM_API_BASE    e.g. "https://101.89.57.42:5911", or "mock"
    VLM_API_KEY     bearer token for the API
    VLM_MODEL       chat model name, e.g. "kimi"

Standalone smoke test (from AReaL repo root, myenv_areal):

    python -m examples.osworld.vlm_judge <image.png> "点击select按钮"
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import os
import re
import time
from typing import Any

import httpx
from openai import AsyncOpenAI

from areal.utils import logging

logger = logging.getLogger("VLMJudge")

ENV_API_BASE = "VLM_API_BASE"
ENV_API_KEY = "VLM_API_KEY"
ENV_MODEL = "VLM_MODEL"

# The judge prompt asks for two 0-1 metrics. Keep the definitions loose for
# now ("先简单写个，以后再完善") — refine the wording once the real metric
# semantics are pinned down.
JUDGE_SYSTEM_PROMPT = (
    "你是一个桌面操作系统任务的自动评估器。用户会给你一张任务结束时的"
    "桌面截图和任务指令。请根据截图判断任务完成情况，并只输出一个 JSON 对象，"
    "不要输出其他内容。JSON 格式："
    '{"metric1": <0到1之间的小数>, "metric2": <0到1之间的小数>}。'
    "metric1 表示任务指令目标的完成程度（0=完全未完成，1=完全完成）；"
    "metric2 表示最终桌面状态与任务目标的匹配程度（0=完全不符，1=完全相符）。"
)


def _default_api_base() -> str:
    return os.environ.get(ENV_API_BASE, "").strip()


def _default_api_key() -> str:
    return os.environ.get(ENV_API_KEY, "").strip()


def _default_model() -> str:
    return os.environ.get(ENV_MODEL, "").strip()


class VLMJudge:
    """Scores (final screenshot, instruction) pairs via an external VLM API."""

    def __init__(
        self,
        api_base: str | None = None,
        api_key: str | None = None,
        model: str | None = None,
        weight1: float = 1.0,
        weight2: float = 0.0,
        timeout_secs: float = 120.0,
        max_retries: int = 1,
    ):
        self.api_base = (api_base or _default_api_base()).rstrip("/")
        self.api_key = api_key or _default_api_key()
        self.model = model or _default_model()
        self.weight1 = float(weight1)
        self.weight2 = float(weight2)
        self.timeout_secs = float(timeout_secs)
        self.max_retries = int(max_retries)
        # Mock mode: no real reward endpoint configured yet (or explicitly
        # requested via "mock"). Placeholder until the real VLM reward
        # logic lands.
        self.mock = self.api_base.lower() in ("", "mock") or self.model.lower() in (
            "",
            "mock",
        )
        if self.mock:
            logger.warning(
                "VLMJudge in MOCK mode: returning deterministic pseudo-random "
                "scalars, no API calls. Set VLM_API_BASE/VLM_MODEL to a real "
                "endpoint to enable the actual judge."
            )
        else:
            self._client = self._build_client()
    def _build_client(self) -> AsyncOpenAI:
        # https against a bare IP: the certificate will not match, so the
        # per-call client must skip verification.
        return AsyncOpenAI(
            base_url=f"{self.api_base}/v1",
            api_key=self.api_key or "EMPTY",
            http_client=httpx.AsyncClient(verify=False, timeout=self.timeout_secs),
            max_retries=0,  # retries handled here so failures map to None
        )

    def _mock_score(
        self, screenshot_b64: str, instruction: str
    ) -> tuple[float, dict[str, Any]]:
        """Deterministic placeholder reward, no network involved.

        Derives metric1/metric2 from a hash of (instruction, screenshot), so
        the same trajectory always scores the same while different
        trajectories differ — keeps GRPO advantages non-degenerate during
        smoke runs. Replace with the real VLM call later.
        """
        digest = hashlib.sha256(
            f"{instruction}::{len(screenshot_b64)}".encode("utf-8")
        ).digest()
        m1 = int.from_bytes(digest[:8], "big") / 2**64
        m2 = int.from_bytes(digest[8:16], "big") / 2**64
        metrics = {"metric1": round(m1, 4), "metric2": round(m2, 4)}
        reward = self.weight1 * metrics["metric1"] + self.weight2 * metrics["metric2"]
        logger.info(f"mock judge: {metrics} -> reward={reward:.3f}")
        return reward, metrics

    async def score(
        self, screenshot_b64: str, instruction: str
    ) -> tuple[float, dict[str, Any]] | None:
        """Return (weighted scalar, raw metrics) or None on failure."""
        if self.mock:
            return self._mock_score(screenshot_b64, instruction)
        last_err: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                t0 = time.monotonic()
                resp = await self._client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": JUDGE_SYSTEM_PROMPT},
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type": "image_url",
                                    "image_url": {
                                        "url": f"data:image/png;base64,{screenshot_b64}"
                                    },
                                },
                                {"type": "text", "text": f"任务指令：{instruction}"},
                            ],
                        },
                    ],
                    temperature=0.0,
                    max_tokens=256,
                )
                content = resp.choices[0].message.content or ""
                metrics = _parse_metrics(content)
                if metrics is None:
                    raise ValueError(f"no metric JSON in judge reply: {content!r}")
                reward = self.weight1 * metrics["metric1"] + self.weight2 * metrics[
                    "metric2"
                ]
                elapsed = time.monotonic() - t0
                logger.info(
                    f"judge ok in {elapsed:.1f}s: {metrics} -> reward={reward:.3f}"
                )
                return reward, metrics
            except Exception as e:  # noqa: BLE001 — any failure drops the traj
                last_err = e
                logger.warning(
                    f"judge attempt {attempt + 1}/{self.max_retries + 1} failed: {e!r}"
                )
        logger.error(f"judge failed permanently: {last_err!r}")
        return None


_METRIC_RE = re.compile(r"\{[^{}]*\}")


def _parse_metrics(content: str) -> dict[str, float] | None:
    """Extract {"metric1": x, "metric2": y} from the model reply."""
    for match in _METRIC_RE.finditer(content):
        try:
            data = json.loads(match.group(0))
        except json.JSONDecodeError:
            continue
        m1, m2 = data.get("metric1"), data.get("metric2")
        if isinstance(m1, (int, float)) and isinstance(m2, (int, float)):
            return {
                "metric1": min(max(float(m1), 0.0), 1.0),
                "metric2": min(max(float(m2), 0.0), 1.0),
            }
    return None


async def _cli() -> int:
    import sys

    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    image_path, instruction = sys.argv[1], sys.argv[2]
    with open(image_path, "rb") as f:
        screenshot_b64 = base64.b64encode(f.read()).decode()
    judge = VLMJudge()
    print(f"api_base={judge.api_base} model={judge.model} weights=({judge.weight1}, {judge.weight2})")
    t0 = time.monotonic()
    result = await judge.score(screenshot_b64, instruction)
    if result is None:
        print("FAILED")
        return 1
    reward, metrics = result
    print(f"metrics={metrics} reward={reward:.3f} total={time.monotonic() - t0:.1f}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(_cli()))

"""GRPO integration tests."""

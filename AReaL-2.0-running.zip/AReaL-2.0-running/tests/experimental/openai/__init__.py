"""OpenAI client tests."""

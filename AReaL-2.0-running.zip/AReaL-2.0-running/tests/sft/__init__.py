"""SFT integration tests."""

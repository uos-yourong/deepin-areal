"""AReaL test suite."""

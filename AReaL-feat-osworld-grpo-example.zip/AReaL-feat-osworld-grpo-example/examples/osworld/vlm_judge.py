"""External VLM reward judge for Deepin GRPO rollouts.

Sends the final screenshot of a trajectory plus the task instruction to an
OpenAI-compatible chat API and converts the two predicted metrics into a
weighted scalar reward.

Two modes:

- Real API: pass ``api_base``/``model`` explicitly or via env vars
  (``VLM_API_BASE`` / ``VLM_API_KEY`` / ``VLM_API_MODEL``). One chat call per
  trajectory, JSON-in-text parsing, ``None`` on any failure (the workflow
  drops that trajectory via its existing failure semantics).
- Mock (current default while the real reward logic is pending): when no
  api_base/model is configured — or ``VLM_API_BASE=mock`` — ``score()``
  returns a deterministic pseudo-random scalar derived from the
  (instruction, screenshot) pair, without any network call. The value varies
  per trajectory so GRPO advantages are non-degenerate during smoke runs.

Configuration priority: explicit constructor args > environment variables.

    VLM_API_BASE    e.g. "https://101.89.57.42:5911", or "mock"
    VLM_API_KEY     bearer token for the API
    VLM_MODEL       chat model name, e.g. "kimi"

Standalone smoke test (from AReaL repo root, myenv_areal):

    python -m examples.osworld.vlm_judge <image.png> "点击select按钮"
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import os
import re
import time
from typing import Any

import httpx
from openai import AsyncOpenAI

from areal.utils import logging

logger = logging.getLogger("VLMJudge")

ENV_API_BASE = "VLM_API_BASE"
ENV_API_KEY = "VLM_API_KEY"
ENV_MODEL = "VLM_MODEL"

# Tooltip-judging prompt. The agent's strategy is to hover over unlabeled
# icons and read the tooltip; the judge scores the FINAL screenshot of a
# trajectory on two 0/1 dimensions:
#   tooltip_present       — a hover tooltip is visible in the screenshot
#   tooltip_matches_task  — the tooltip confirms the element is the task target
# ``{task}`` (two occurrences) is substituted with the task instruction.
JUDGE_PROMPT_TEMPLATE = """你是一个严格的判断助手。下面是某个自动化 Agent 在执行 GUI 任务时产生的【最后一步】observation。该 Agent 的策略是：对界面上功能不确定、无文字标注的图标进行"悬浮试探"（把鼠标悬停上去观察 tooltip 反馈），以确认该图标是否就是目标任务要找的按钮。现在需要你结合当时Agent看到的屏幕截图，评估这一步的悬浮反馈情况。

目标任务（task）: {task}

Agent 在这一步声称已经通过悬浮确认了目标元素，并观察到了相应的悬浮文字信息（tooltip），但 agent 可能是错误的，需要你判断。附图正是 Agent 做出该判断时所看到的屏幕截图。

请以图片证据为依据，从以下两个维度进行判断：

维度 1 — tooltip 可见性：图片中是否存在鼠标悬浮产生的文字信息（tooltip / 提示文字）？
- 若图片中确实出现了任何 tooltip 文字提示，得 1 分；
- 若图片中完全没有 tooltip 文字提示，得 0 分。

维度 2 — tooltip 与任务一致性：图片中出现的 tooltip 文字信息是否能够确认该元素就是目标元素「{task}」？
- 若 tooltip 明确指向/确认该元素为目标元素，得 1 分；
- 若 tooltip 不存在、与目标元素无关、或无法确认该元素是目标元素，得 0 分。

判断要点：
- 必须以图片中实际可见的证据为准，不要轻信 Agent 的文字描述。
- 仅当图片中确实出现 tooltip 且其文字内容明确对应目标元素时，维度 2 才能得 1 分。

请严格只输出如下 JSON（不要输出任何其他内容、不要加 markdown 代码块）：
{"thinking": "逐步分析图片证据的思考过程", "evidence": "图片中支撑判断的具体证据", "tooltip_present": 0 或 1, "tooltip_matches_task": 0 或 1}"""


def _default_api_base() -> str:
    return os.environ.get(ENV_API_BASE, "").strip()


def _default_api_key() -> str:
    return os.environ.get(ENV_API_KEY, "").strip()


def _default_model() -> str:
    return os.environ.get(ENV_MODEL, "").strip()


class VLMJudge:
    """Scores (final screenshot, instruction) pairs via an external VLM API."""

    def __init__(
        self,
        api_base: str | None = None,
        api_key: str | None = None,
        model: str | None = None,
        weight1: float = 1.0,
        weight2: float = 0.0,
        timeout_secs: float = 120.0,
        max_retries: int = 1,
    ):
        self.api_base = (api_base or _default_api_base()).rstrip("/")
        self.api_key = api_key or _default_api_key()
        self.model = model or _default_model()
        self.weight1 = float(weight1)
        self.weight2 = float(weight2)
        self.timeout_secs = float(timeout_secs)
        self.max_retries = int(max_retries)
        # Mock mode: no real reward endpoint configured yet (or explicitly
        # requested via "mock"). Placeholder until the real VLM reward
        # logic lands.
        self.mock = self.api_base.lower() in ("", "mock") or self.model.lower() in (
            "",
            "mock",
        )
        if self.mock:
            logger.warning(
                "VLMJudge in MOCK mode: returning deterministic pseudo-random "
                "scalars, no API calls. Set VLM_API_BASE/VLM_MODEL to a real "
                "endpoint to enable the actual judge."
            )
        else:
            self._client = self._build_client()
    def _build_client(self) -> AsyncOpenAI:
        # https against a bare IP: the certificate will not match, so the
        # per-call client must skip verification.
        return AsyncOpenAI(
            base_url=f"{self.api_base}/v1",
            api_key=self.api_key or "EMPTY",
            http_client=httpx.AsyncClient(verify=False, timeout=self.timeout_secs),
            max_retries=0,  # retries handled here so failures map to None
        )

    def _mock_score(
        self, screenshot_b64: str, instruction: str
    ) -> tuple[float, dict[str, Any]]:
        """Deterministic placeholder reward, no network involved.

        Derives tooltip_present/tooltip_matches_task from a hash of
        (instruction, screenshot), so the same trajectory always scores the
        same while different trajectories differ — keeps GRPO advantages
        non-degenerate during smoke runs.
        """
        digest = hashlib.sha256(
            f"{instruction}::{len(screenshot_b64)}".encode("utf-8")
        ).digest()
        m1 = int.from_bytes(digest[:8], "big") / 2**64
        m2 = int.from_bytes(digest[8:16], "big") / 2**64
        metrics = {
            "tooltip_present": round(m1, 4),
            "tooltip_matches_task": round(m2, 4),
        }
        reward = self.weight1 * metrics["tooltip_present"] + self.weight2 * metrics[
            "tooltip_matches_task"
        ]
        logger.info(f"mock judge: {metrics} -> reward={reward:.3f}")
        return reward, metrics

    async def score(
        self, screenshot_b64: str, instruction: str
    ) -> tuple[float, dict[str, Any]] | None:
        """Return (weighted scalar, raw metrics) or None on failure."""
        if self.mock:
            return self._mock_score(screenshot_b64, instruction)
        last_err: Exception | None = None
        prompt_text = JUDGE_PROMPT_TEMPLATE.replace("{task}", instruction)
        for attempt in range(self.max_retries + 1):
            try:
                t0 = time.monotonic()
                resp = await self._client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type": "image_url",
                                    "image_url": {
                                        "url": f"data:image/png;base64,{screenshot_b64}"
                                    },
                                },
                                {"type": "text", "text": prompt_text},
                            ],
                        },
                    ],
                    temperature=0.0,
                    max_tokens=1024,
                )
                content = resp.choices[0].message.content or ""
                verdict = _parse_verdict(content)
                if verdict is None:
                    raise ValueError(f"no verdict JSON in judge reply: {content!r}")
                metrics = {
                    "tooltip_present": verdict["tooltip_present"],
                    "tooltip_matches_task": verdict["tooltip_matches_task"],
                }
                reward = self.weight1 * metrics["tooltip_present"] + self.weight2 * metrics[
                    "tooltip_matches_task"
                ]
                elapsed = time.monotonic() - t0
                logger.info(
                    f"judge ok in {elapsed:.1f}s: {metrics} -> reward={reward:.3f} "
                    f"evidence={verdict['evidence']!r}"
                )
                return reward, metrics
            except Exception as e:  # noqa: BLE001 — any failure drops the traj
                last_err = e
                logger.warning(
                    f"judge attempt {attempt + 1}/{self.max_retries + 1} failed: {e!r}"
                )
        logger.error(f"judge failed permanently: {last_err!r}")
        return None


_METRIC_RE = re.compile(r"\{[^{}]*\}")


def _extract_verdict_fields(data: Any) -> dict[str, Any] | None:
    """Validate the parsed dict has the two 0/1 tooltip dimensions."""
    if not isinstance(data, dict):
        return None
    present, matches = data.get("tooltip_present"), data.get("tooltip_matches_task")
    if isinstance(present, (int, float)) and isinstance(matches, (int, float)):
        return {
            "tooltip_present": min(max(float(present), 0.0), 1.0),
            "tooltip_matches_task": min(max(float(matches), 0.0), 1.0),
            "thinking": str(data.get("thinking", "")),
            "evidence": str(data.get("evidence", "")),
        }
    return None


def _parse_verdict(content: str) -> dict[str, Any] | None:
    """Extract the tooltip verdict JSON from the model reply.

    Expected keys: thinking / evidence (str) and tooltip_present /
    tooltip_matches_task (0 or 1). Tolerates markdown code fences and
    surrounding prose; falls back to scanning brace-delimited spans.
    """
    candidates: list[str] = [content]
    # Strip ```json fences if the model added them despite the instruction.
    fence = re.search(r"```(?:json)?\s*(.*?)```", content, re.DOTALL)
    if fence:
        candidates.insert(0, fence.group(1))
    for text in candidates:
        try:
            data = json.loads(text.strip())
        except json.JSONDecodeError:
            continue
        verdict = _extract_verdict_fields(data)
        if verdict is not None:
            return verdict
    # Last resort: scan brace-delimited spans (thinking may contain braces,
    # so the full-object match can fail — innermost spans still parse).
    for match in _METRIC_RE.finditer(content):
        try:
            data = json.loads(match.group(0))
        except json.JSONDecodeError:
            continue
        verdict = _extract_verdict_fields(data)
        if verdict is not None:
            return verdict
    return None


async def _cli() -> int:
    import sys

    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    image_path, instruction = sys.argv[1], sys.argv[2]
    with open(image_path, "rb") as f:
        screenshot_b64 = base64.b64encode(f.read()).decode()
    judge = VLMJudge()
    print(f"api_base={judge.api_base} model={judge.model} weights=({judge.weight1}, {judge.weight2})")
    t0 = time.monotonic()
    result = await judge.score(screenshot_b64, instruction)
    if result is None:
        print("FAILED")
        return 1
    reward, metrics = result
    print(f"metrics={metrics} reward={reward:.3f} total={time.monotonic() - t0:.1f}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(_cli()))

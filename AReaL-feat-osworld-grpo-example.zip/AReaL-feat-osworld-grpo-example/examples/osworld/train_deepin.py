"""GRPO training on deepin desktop-control tasks (libvirt rollout + external
VLM reward).

Run (from AReaL repo root, inside myenv_areal):

    python -m examples.osworld.train_deepin --config examples/osworld/config_deepin_sglang.yaml

Prerequisites (see examples/osworld/README.md for the OSWorld variant):
- os_env checked out at ``os_env_root`` with a working ``all_config.yaml``
  (libvirt template / vm_images_dir / state_dir paths for this machine).
- The external VLM judge API reachable (``vlm_api_base`` or ``VLM_API_BASE``).
- libvirt access via passwordless ``sudo virsh`` for the training user.
"""

from __future__ import annotations

import json
import os

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import sys
from pathlib import Path

from datasets import Dataset

from examples.osworld.deepin_config import DeepinAgentConfig

from areal import PPOTrainer
from areal.api.cli_args import load_expr_config
from areal.utils import seeding
from areal.utils.hf_utils import load_hf_tokenizer
from areal.utils.stats_logger import StatsLogger

WORKFLOW_PATH = "examples.osworld.workflow.deepin_workflow.DeepinWorkflow"


def _build_tasks_dataset(task_data_path: str) -> Dataset:
    """Load the task JSON array (instruction + initial-state config inline)."""
    with open(task_data_path, encoding="utf-8") as f:
        tasks = json.load(f)

    rows: list[dict] = []
    for task in tasks:
        rows.append(
            {
                "id": task.get("id", len(rows)),
                "instruction": task["instruction"],
                # Keep the full task dict as a JSON string to avoid the
                # schema explosion datasets infers from nested structures,
                # then inflate on the fly below (same pattern as the
                # OSWorld example's train.py).
                "task_config_json": json.dumps(task, ensure_ascii=False),
            }
        )
    if not rows:
        raise ValueError(f"No tasks found in {task_data_path}")
    return Dataset.from_list(rows)


def main(args):
    config, _ = load_expr_config(args, DeepinAgentConfig)

    rank = int(os.getenv("RANK", "0"))
    tokenizer = load_hf_tokenizer(config.tokenizer_path)

    seeding.set_random_seed(config.seed, key=f"trainer{rank}")

    dataset = _build_tasks_dataset(config.task_data_path)

    # The workflow only needs the task config dict; inflate on the fly.
    def _inflate(row):
        row.update(json.loads(row.pop("task_config_json")))
        return row

    dataset = dataset.map(_inflate)

    workflow_kwargs = dict(
        gconfig=config.gconfig,
        tokenizer=tokenizer,
        os_env_root=config.os_env_root,
        snapshot_name=config.snapshot_name,
        max_steps=config.max_steps,
        n_trajs=config.n_trajs,
        sleep_after_execution=config.sleep_after_execution,
        env_reset_wait_secs=config.env_reset_wait_secs,
        max_workers=config.max_workers,
        turn_discount=config.turn_discount,
        screen_size=(config.screen_width, config.screen_height),
        observation_type=config.observation_type,
        action_space=config.action_space,
        cache_dir=config.osworld_cache_dir,
        remote_env_url=config.remote_env_url,
        remote_env_urls=config.remote_env_urls,
        remote_env_close_mode=config.remote_env_close_mode,
        dump_dir=os.path.join(
            StatsLogger.get_log_path(config.stats_logger), "generated"
        ),
        vlm_api_base=config.vlm_api_base,
        vlm_api_key=config.vlm_api_key,
        vlm_model=config.vlm_model,
        vlm_weight1=config.vlm_weight1,
        vlm_weight2=config.vlm_weight2,
        vlm_timeout_secs=config.vlm_timeout_secs,
        # Default the VL processor to the actor checkpoint dir; AutoProcessor
        # picks up the matching preprocessor_config.json there.
        processor_path=config.actor.path,
    )

    eval_workflow_kwargs = workflow_kwargs.copy()

    with PPOTrainer(
        config,
        train_dataset=dataset,
        valid_dataset=dataset,
    ) as trainer:
        trainer.train(
            workflow=WORKFLOW_PATH,
            workflow_kwargs=workflow_kwargs,
            eval_workflow=WORKFLOW_PATH,
            eval_workflow_kwargs=eval_workflow_kwargs,
        )


if __name__ == "__main__":
    main(sys.argv[1:])

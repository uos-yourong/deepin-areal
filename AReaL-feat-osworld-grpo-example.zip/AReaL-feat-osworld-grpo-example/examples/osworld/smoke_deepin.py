"""Standalone deepin VM smoke test — verifies the full rollout environment
chain without touching the trainer:

    clone VM from template -> reset(toy task config) -> screenshot (bytes)
    -> one pyautogui step -> VLM judge score on the final screenshot -> close

Run from the AReaL repo root (myenv_areal):

    python -m examples.osworld.smoke_deepin [--skip-judge] [--task-json PATH]

Expected outcome: all five setup verbs from the toy task execute, the
screenshot is PNG bytes, one step returns normally, and ``virsh list`` shows
no leftover VM afterwards.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import json
import os
import sys
import time

OS_ENV_ROOT = "/mnt/data/yr/code/rl_osworld/os_env"
DEFAULT_TASK_JSON = (
    "/mnt/data/yr/code/rl_osworld/任务数据/tasks_blender_theme_resolution_toy.json"
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-json", default=DEFAULT_TASK_JSON)
    parser.add_argument("--skip-judge", action="store_true")
    parser.add_argument("--keep-vm", action="store_true", help="skip close() at the end")
    args = parser.parse_args()

    sys.path.insert(0, OS_ENV_ROOT)
    from desktop_env.desktop_env import DesktopEnv  # noqa: E402 — os_env path

    with open(args.task_json, encoding="utf-8") as f:
        tasks = json.load(f)
    task = tasks[0]
    print(f"task id={task.get('id')} instruction={task['instruction']!r}")
    print(f"setup verbs: {[c['type'] for c in task['config']]}")

    t0 = time.monotonic()
    env = DesktopEnv(
        provider_name="libvirt",
        path_to_vm=None,  # auto-allocate from pool / template
        os_type="deepin",
        snapshot_name="init_state",
        action_space="pyautogui",
        cache_dir="/mnt/data/yr/code/rl_osworld/tmp1/deepin_smoke_cache",
        screen_size=(1920, 1080),
        require_a11y_tree=False,
        headless=True,
    )
    print(f"[1] env built in {time.monotonic() - t0:.0f}s, vm={env.path_to_vm}")

    t1 = time.monotonic()
    env.reset(task_config=task)
    print(f"[2] reset + setup done in {time.monotonic() - t1:.0f}s")

    obs = env._get_obs()
    shot = obs["screenshot"]
    assert isinstance(shot, bytes), f"screenshot is {type(shot)}, expected bytes"
    shot_path = "/mnt/data/yr/code/rl_osworld/tmp1/deepin_smoke_screenshot.png"
    with open(shot_path, "wb") as f:
        f.write(shot)
    print(f"[3] screenshot ok: {len(shot)} bytes -> {shot_path}")

    t2 = time.monotonic()
    obs, _, done, info = env.step(
        "pyautogui.moveTo(960, 540); pyautogui.click()", pause=2.0
    )
    shot_final = obs["screenshot"]
    with open("/mnt/data/yr/code/rl_osworld/tmp1/deepin_smoke_screenshot_final.png", "wb") as f:
        f.write(shot_final)
    print(
        f"[4] step ok in {time.monotonic() - t2:.0f}s done={done} info={info}, "
        f"final shot {len(shot_final)} bytes"
    )

    if not args.skip_judge:
        from examples.osworld.vlm_judge import VLMJudge

        judge = VLMJudge()
        result = asyncio.run(
            judge.score(
                base64.b64encode(shot_final).decode(), task["instruction"]
            )
        )
        if result is None:
            print("[5] VLM judge FAILED (see logs above)")
        else:
            reward, metrics = result
            print(f"[5] VLM judge ok: metrics={metrics} reward={reward:.3f}")
    else:
        print("[5] judge skipped")

    if args.keep_vm:
        print(f"[6] keeping vm {env.path_to_vm} (--keep-vm)")
    else:
        t3 = time.monotonic()
        env.close()
        print(f"[6] closed in {time.monotonic() - t3:.0f}s")

    print("SMOKE PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

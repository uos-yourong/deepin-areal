#!/usr/bin/env bash
# Launch deepin GRPO training (libvirt rollout + external VLM reward).
#
# Usage:
#   bash examples/osworld/run_deepin.sh [smoke|full] [extra hydra-style overrides...]
#
# Examples:
#   bash examples/osworld/run_deepin.sh smoke
#   bash examples/osworld/run_deepin.sh full rollout.max_concurrent_rollouts=4 n_trajs=8
#
# Env vars (defaults below; override before invocation):
#   VLM_API_BASE / VLM_API_KEY / VLM_MODEL   — external VLM judge endpoint
#   AREAL_VENV     — python venv (default: /mnt/data/yr/code/rl_osworld/myenv_areal)
#   AREAL_REPO     — AReaL checkout root (default: parent of this script's grandparent)
#   DEEPIN_GPUS    — physical GPUs to use (default: 4,5)
#   STAGE          — alternative to first positional arg

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AREAL_REPO="${AREAL_REPO:-$(cd "${SCRIPT_DIR}/../.." && pwd)}"
AREAL_VENV="${AREAL_VENV:-/mnt/data/yr/code/rl_osworld/myenv_areal}"

if [[ ! -x "${AREAL_VENV}/bin/python" ]]; then
    echo "[run_deepin.sh] python venv not found at: ${AREAL_VENV}" >&2
    exit 1
fi

# AReaL spawns the SGLang server with a bare `python3` (areal/api/cli_args.py
# get_py_cmd), which must resolve to the venv python — otherwise the child
# mixes a foreign interpreter with this venv's packages and dies on import.
export PATH="${AREAL_VENV}/bin:${PATH}"

# -------- fixed resources: GPUs 4/5 only --------
export CUDA_VISIBLE_DEVICES="${DEEPIN_GPUS:-4,5}"

# -------- external VLM judge credentials --------
# Default to "mock": the judge returns deterministic pseudo-random scalars
# without any API call (real reward logic pending). Set VLM_API_BASE to a
# real endpoint (e.g. https://101.89.57.42:5911, VLM_MODEL=kimi,
# VLM_API_KEY=...) to enable the actual VLM judge.
export VLM_API_BASE="${VLM_API_BASE:-mock}"
export VLM_MODEL="${VLM_MODEL:-mock}"
export VLM_API_KEY="${VLM_API_KEY:-}"

# Unbuffered python so SGLang / rollout logs stream in real time.
export PYTHONUNBUFFERED=1

# Local-only addresses must bypass any corporate proxy (health probes to
# the local SGLang server and the deepin VMs).
_areal_no_proxy_extra="localhost,127.0.0.1,0.0.0.0,192.168.0.0/16,10.0.0.0/8"
if [[ -n "${NO_PROXY:-}" ]]; then
    export NO_PROXY="${NO_PROXY},${_areal_no_proxy_extra}"
else
    export NO_PROXY="${_areal_no_proxy_extra}"
fi
export no_proxy="${NO_PROXY}"

# -------- pick stage --------
STAGE="${1:-${STAGE:-smoke}}"
shift || true

if [[ "${STAGE}" != "smoke" && "${STAGE}" != "full" ]]; then
    echo "[run_deepin.sh] first arg must be 'smoke' or 'full', got '${STAGE}'" >&2
    exit 2
fi

TRIAL_NAME="${STAGE}-$(date +%Y%m%d-%H%M%S)"

case "${STAGE}" in
    smoke)
        # Short trajectories, small group, 1 epoch — enough to verify the
        # SGLang rollout -> libvirt VM -> VLM judge -> FSDP update loop.
        STAGE_ARGS=(
            "experiment_name=deepin-grpo-smoke"
            "rollout.max_concurrent_rollouts=1"
            "n_trajs=2"
            "max_steps=2"
            "train_dataset.batch_size=1"
            "total_train_epochs=1"
        )
        ;;
    full)
        STAGE_ARGS=(
            "experiment_name=deepin-grpo"
            "rollout.max_concurrent_rollouts=2"
            "n_trajs=4"
            "max_steps=15"
            "train_dataset.batch_size=4"
        )
        ;;
esac

# -------- launch --------
cd "${AREAL_REPO}"

CONFIG_PATH="examples/osworld/config_deepin_vllm.yaml"

echo "[run_deepin.sh] stage=${STAGE} trial_name=${TRIAL_NAME}"
echo "[run_deepin.sh] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"
echo "[run_deepin.sh] VLM_API_BASE=${VLM_API_BASE} VLM_MODEL=${VLM_MODEL}"
echo "[run_deepin.sh] python=${AREAL_VENV}/bin/python"
echo "[run_deepin.sh] config=${CONFIG_PATH}"
echo "[run_deepin.sh] overrides:" "${STAGE_ARGS[@]}" "$@"

exec "${AREAL_VENV}/bin/python" -m examples.osworld.train_deepin \
    --config "${CONFIG_PATH}" \
    "trial_name=${TRIAL_NAME}" \
    "${STAGE_ARGS[@]}" \
    "$@"

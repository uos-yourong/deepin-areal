"""Deepin OS rollout workflow for GRPO training (libvirt in-process).

Variant of ``OSWorldWorkflow`` with three changes (see
``deepin_areal讨论理解.txt`` — "模式 3" only):

1. ``_build_env`` boots os_env's libvirt-backed DesktopEnv in-process
   (deepin template clone per episode); the gateway / remote-server
   transports are removed entirely.
2. The trajectory reward is computed by an external VLM judge
   (``examples.osworld.vlm_judge``): final screenshot + instruction ->
   metric1 / metric2 -> weighted scalar. ``env.evaluate()`` is bypassed.
3. Everything else — the 15-step loop, ArealOpenAI token/logp caching,
   the VL tensor bridge, trajectory dumping — is reused verbatim.
"""

from __future__ import annotations

import asyncio
import base64
import itertools
import json
import os
import re
import sys
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from io import BytesIO
from pathlib import Path
from typing import Any

import torch
from PIL import Image
from transformers import AutoProcessor, PreTrainedTokenizerFast

from areal.api.cli_args import GenerationHyperparameters
from areal.api.workflow_api import RolloutWorkflow
from areal.experimental.openai import ArealOpenAI
from areal.utils import logging, stats_tracker

from examples.osworld.vlm_judge import VLMJudge

logger = logging.getLogger("DeepinWorkflow")

DEEPIN_SYSTEM_PROMPT = (
    "You are a computer-use agent operating a deepin Linux desktop through "
    "pyautogui. At each turn you will receive the user instruction and the "
    "current screenshot of the desktop. Produce a short plan and then a "
    "single ```python``` code block containing pyautogui code to execute. "
    "Use absolute pixel coordinates relative to the screenshot. When the "
    "task is fully completed, reply with the single token DONE on its own "
    "line (no code block). If the task is infeasible reply with FAIL."
)

_CODE_BLOCK_RE = re.compile(r"```(?:python)?\s*([\s\S]*?)```", re.IGNORECASE)


def _screenshot_to_data_uri(screenshot: bytes) -> str:
    return "data:image/png;base64," + base64.b64encode(screenshot).decode("utf-8")


def _parse_actions(text: str) -> list[str]:
    """Extract executable actions from the model reply.

    Returns a list with one pyautogui snippet, or a single control token
    ("DONE" / "FAIL" / "WAIT") to be forwarded to DesktopEnv.step.
    """
    text = text.strip()
    code = _CODE_BLOCK_RE.findall(text)
    if code:
        snippet = code[-1].strip()
        if snippet:
            return [snippet]
    for line in reversed(text.splitlines()):
        token = line.strip().upper()
        if token in {"DONE", "FAIL", "WAIT"}:
            return [token]
    return []


class DeepinWorkflow(RolloutWorkflow):
    """Multi-turn VLM rollout workflow backed by os_env's DesktopEnv.

    Each episode spins up a fresh deepin VM (libvirt clone from template),
    drives the agent<->env loop through ``ArealOpenAI`` so completions/tokens
    are cached for training, and scores the trajectory's final screenshot
    with an external VLM judge.
    """

    def __init__(
        self,
        gconfig: GenerationHyperparameters,
        tokenizer: PreTrainedTokenizerFast,
        os_env_root: str,
        snapshot_name: str = "init_state",
        max_steps: int = 15,
        n_trajs: int = 1,
        sleep_after_execution: float = 1.0,
        env_reset_wait_secs: float = 60.0,
        max_workers: int = 4,
        turn_discount: float = 0.9,
        dump_dir: str | None = None,
        rollout_stat_scope: str = "rollout",
        screen_size: tuple[int, int] = (1920, 1080),
        observation_type: str = "screenshot",
        action_space: str = "pyautogui",
        cache_dir: str = "cache",
        remote_env_url: str = "",
        remote_env_urls: list[str] | None = None,
        remote_env_close_mode: str = "reset",
        vlm_api_base: str = "",
        vlm_api_key: str = "",
        vlm_model: str = "",
        vlm_weight1: float = 1.0,
        vlm_weight2: float = 0.0,
        vlm_timeout_secs: float = 120.0,
        processor_path: str | None = None,
    ):
        if os_env_root and os_env_root not in sys.path:
            # os_env's desktop_env package is imported lazily inside
            # _build_env, but make the path visible up front for clarity.
            sys.path.insert(0, os_env_root)
        self.os_env_root = os_env_root
        self.snapshot_name = snapshot_name
        self.gconfig = gconfig.new(n_samples=1)
        self.tokenizer = tokenizer
        self.screen_size = tuple(screen_size)
        self.observation_type = observation_type
        self.action_space = action_space
        self.cache_dir = cache_dir
        self.remote_env_url = remote_env_url
        # Pool mode: prefer the URL list; fall back to the single URL.
        # Concurrent trajectories draw URLs round-robin (thread-safely) so
        # each gets its own env_worker/VM when #trajs <= #urls.
        urls = list(remote_env_urls or ([remote_env_url] if remote_env_url else []))
        self._env_url_cycle = itertools.cycle(urls) if urls else None
        self._env_url_lock = threading.Lock()
        self.remote_env_close_mode = remote_env_close_mode
        self.max_steps = max_steps
        self.n_trajs = n_trajs
        self.sleep_after_execution = sleep_after_execution
        self.env_reset_wait_secs = env_reset_wait_secs
        self.turn_discount = turn_discount
        self.rollout_stat_scope = rollout_stat_scope
        self.dump_dir = dump_dir
        if self.dump_dir and not os.path.exists(self.dump_dir):
            os.makedirs(self.dump_dir, exist_ok=True)
        # Lazy-loaded multimodal processor for VL training.
        self._processor_path = processor_path
        self._processor = None
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.judge = VLMJudge(
            api_base=vlm_api_base or None,
            api_key=vlm_api_key or None,
            model=vlm_model or None,
            weight1=vlm_weight1,
            weight2=vlm_weight2,
            timeout_secs=vlm_timeout_secs,
        )

    def _load_task_config(self, data: dict[str, Any]) -> dict[str, Any]:
        """Dataset rows carry the full task inline (instruction/config/evaluator)."""
        if "config" in data and "instruction" in data:
            return dict(data)
        raise ValueError(
            f"task row missing inline 'config'/'instruction' keys: {sorted(data)}"
        )

    def _build_env(self):
        if self._env_url_cycle is not None:
            # HTTP mode: talk to pre-launched os_env env_worker.py instances
            # (e.g. on the Docker host). One VM per worker; round-robin
            # across the pool so concurrent trajectories don't share a VM.
            from examples.osworld.workflow.remote_env_client import RemoteDesktopEnv

            with self._env_url_lock:
                url = next(self._env_url_cycle)
            return RemoteDesktopEnv(
                base_url=url,
                close_mode=self.remote_env_close_mode,
            )

        # In-process mode: boot os_env's libvirt-backed DesktopEnv directly.
        from desktop_env.desktop_env import DesktopEnv  # os_env on sys.path

        return DesktopEnv(
            provider_name="libvirt",
            path_to_vm=None,  # auto-allocate from the VM pool / template
            snapshot_name=self.snapshot_name,
            action_space=self.action_space,
            cache_dir=self.cache_dir,
            screen_size=self.screen_size,
            headless=True,
            os_type="deepin",
            require_a11y_tree=self.observation_type != "screenshot",
        )

    def _build_user_turn(self, text: str, screenshot: bytes) -> dict[str, Any]:
        return {
            "role": "user",
            "content": [
                {"type": "text", "text": text},
                {
                    "type": "image_url",
                    "image_url": {"url": _screenshot_to_data_uri(screenshot)},
                },
            ],
        }

    async def _vlm_reward(
        self, screenshot: bytes, instruction: str
    ) -> tuple[float, dict[str, Any]] | None:
        """Final screenshot + instruction -> external VLM -> weighted scalar."""
        return await self.judge.score(
            base64.b64encode(screenshot).decode("utf-8"), instruction
        )

    async def _run_single_trajectory(
        self,
        engine,
        task_config: dict[str, Any],
        traj_idx: int,
    ) -> tuple[dict[str, Any] | None, float | None]:
        instruction = task_config["instruction"]
        task_id = task_config.get("id", "unknown")
        loop = asyncio.get_running_loop()

        env = None
        try:
            env = await loop.run_in_executor(self.executor, self._build_env)
            await loop.run_in_executor(
                self.executor, partial(env.reset, task_config=task_config)
            )
            await asyncio.sleep(self.env_reset_wait_secs)
            obs = await loop.run_in_executor(self.executor, env._get_obs)

            client = ArealOpenAI(
                engine=engine,
                tokenizer=self.tokenizer,
                lora_name=self.gconfig.lora_name,
            )
            messages: list[dict[str, Any]] = [
                {"role": "system", "content": DEEPIN_SYSTEM_PROMPT},
                self._build_user_turn(
                    f"Task instruction: {instruction}\nHere is the current screenshot.",
                    obs["screenshot"],
                ),
            ]

            terminated = False
            step_idx = 0
            last_response_id: str | None = None
            for step_idx in range(self.max_steps):
                response = await client.chat.completions.create(
                    messages=messages,
                    **self.gconfig.to_openai_args_dict(),
                )
                last_response_id = response.id
                reply = response.choices[0].message
                reply_text = reply.content or ""
                messages.append(reply.model_dump(exclude_none=True))

                actions = _parse_actions(reply_text)
                if not actions:
                    logger.warning(
                        f"[task={task_id} traj={traj_idx}] step {step_idx + 1}: "
                        "no parseable action; feeding back a reminder."
                    )
                    messages.append(
                        self._build_user_turn(
                            "Your previous reply did not contain a valid pyautogui "
                            "code block or control token. Please issue an action.",
                            obs["screenshot"],
                        )
                    )
                    continue

                for action in actions:
                    obs, _, done, info = await loop.run_in_executor(
                        self.executor,
                        partial(env.step, action, self.sleep_after_execution),
                    )
                    if done:
                        terminated = True
                        break
                if terminated:
                    break
                messages.append(
                    self._build_user_turn(
                        f"Step {step_idx + 1} executed. Here is the new screenshot.",
                        obs["screenshot"],
                    )
                )

            # Reward: last screenshot + instruction -> external VLM judge.
            # obs is the final observation whether we exited early or used
            # all max_steps turns. env.evaluate() is bypassed entirely.
            judged = await self._vlm_reward(obs["screenshot"], instruction)
            if judged is None:
                logger.error(
                    f"[task={task_id} traj={traj_idx}] VLM judge failed; "
                    "dropping trajectory."
                )
                return None, None
            final_reward, metrics = judged
            logger.info(
                f"[task={task_id} traj={traj_idx}] finished after "
                f"{step_idx + 1} steps, reward={final_reward:.3f}, metrics={metrics}"
            )

            stats_tracker.get(self.rollout_stat_scope).scalar(
                reward=final_reward,
                tooltip_present=metrics["tooltip_present"],
                tooltip_matches_task=metrics["tooltip_matches_task"],
                num_steps=step_idx + 1,
            )

            if last_response_id is not None:
                client.set_reward(last_response_id, final_reward)
            client.apply_reward_discount(turn_discount=self.turn_discount)
            completions = client.export_interactions(style="individual")

            # Inject multimodal training tensors for the Qwen-VL base
            # (mm_token_type_ids / multi_modal_input for FSDPEngine).
            if completions:
                self._attach_vl_tensor_dicts(completions)

            if self.dump_dir is not None:
                self._dump_trajectory(task_id, traj_idx, messages, final_reward)

            return completions, final_reward
        except Exception as e:
            logger.error(f"[task={task_id} traj={traj_idx}] trajectory failed: {e!r}")
            return None, None
        finally:
            if env is not None:
                try:
                    await loop.run_in_executor(self.executor, env.close)
                except Exception as e:
                    logger.warning(f"Failed to close env: {e!r}")

    def _dump_trajectory(
        self,
        task_id: str,
        traj_idx: int,
        messages: list[dict[str, Any]],
        reward: float,
    ) -> None:
        # Strip base64 image bytes before dumping so the log stays readable.
        def _sanitize(msg: dict[str, Any]) -> dict[str, Any]:
            if isinstance(msg.get("content"), list):
                parts = []
                for part in msg["content"]:
                    if isinstance(part, dict) and part.get("type") == "image_url":
                        parts.append({"type": "image_url", "image_url": "<elided>"})
                    else:
                        parts.append(part)
                return {**msg, "content": parts}
            return msg

        path = os.path.join(
            self.dump_dir, f"{task_id}_traj{traj_idx}_{uuid.uuid4().hex[:6]}.json"
        )
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "task_id": task_id,
                    "traj_idx": traj_idx,
                    "reward": reward,
                    "messages": [_sanitize(m) for m in messages],
                },
                f,
                ensure_ascii=False,
                indent=2,
            )

    # ------------------------------------------------------------------
    # VL bridge: hand FSDPEngine the multimodal tensors it expects.
    # (verbatim from OSWorldWorkflow — Qwen3-VL needs mm_token_type_ids and
    # multi_modal_input in addition to the token streams ArealOpenAI caches)
    # ------------------------------------------------------------------

    def _get_processor(self):
        """Lazy-load HF processor for the VL base model."""
        if self._processor is None:
            path = self._processor_path
            if not path:
                raise RuntimeError(
                    "DeepinWorkflow needs `processor_path` set — point it at "
                    "the same HuggingFace dir as actor.path so we can recover "
                    "mm_token_type_ids etc."
                )
            self._processor = AutoProcessor.from_pretrained(path)
        return self._processor

    @staticmethod
    def _decode_data_uri_image(url: str) -> Image.Image | None:
        if not url.startswith("data:image"):
            return None
        try:
            _, b64 = url.split(",", 1)
        except ValueError:
            return None
        try:
            return Image.open(BytesIO(base64.b64decode(b64))).convert("RGB")
        except Exception as e:
            logger.warning(f"Failed to decode image data URI: {e!r}")
            return None

    def _split_messages_to_text_and_images(
        self, messages: list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], list[Image.Image]]:
        """Convert workflow messages → processor messages + PIL image list."""
        out_messages: list[dict[str, Any]] = []
        images: list[Image.Image] = []
        for msg in messages:
            content = msg.get("content")
            if not isinstance(content, list):
                out_messages.append(msg)
                continue
            new_parts: list[dict[str, Any]] = []
            for part in content:
                if not isinstance(part, dict):
                    continue
                if part.get("type") == "image_url":
                    img = self._decode_data_uri_image(
                        part.get("image_url", {}).get("url", "")
                    )
                    if img is None:
                        continue
                    images.append(img)
                    new_parts.append({"type": "image"})
                elif part.get("type") == "text":
                    new_parts.append({"type": "text", "text": part.get("text", "")})
            out_messages.append({"role": msg["role"], "content": new_parts})
        return out_messages, images

    def _build_vl_tensor_dict(
        self, interaction
    ) -> dict[str, torch.Tensor | list] | None:
        """Run processor on the interaction prefix; produce a VL tensor dict."""
        resp = getattr(interaction, "model_response", None)
        if resp is None:
            return None
        prefix_messages = list(interaction.messages or [])
        proc_messages, images = self._split_messages_to_text_and_images(prefix_messages)
        processor = self._get_processor()

        text = processor.apply_chat_template(
            proc_messages,
            tokenize=False,
            add_generation_prompt=True,
        )
        kwargs: dict[str, Any] = dict(text=[text], padding=False, return_tensors="pt")
        if images:
            kwargs["images"] = images
        proc_out = processor(**kwargs)

        input_ids = proc_out["input_ids"][0].tolist()
        if "mm_token_type_ids" in proc_out:
            mm_token_type_ids = proc_out["mm_token_type_ids"][0].tolist()
        else:
            mm_token_type_ids = [0] * len(input_ids)

        output_ids = list(resp.output_tokens or [])
        output_logprobs = list(resp.output_logprobs or [])
        output_versions = list(resp.output_versions or [])
        # Defensive: pad / truncate the per-token streams to match output_ids.
        if len(output_logprobs) < len(output_ids):
            output_logprobs += [0.0] * (len(output_ids) - len(output_logprobs))
        else:
            output_logprobs = output_logprobs[: len(output_ids)]
        if len(output_versions) < len(output_ids):
            output_versions += [-1] * (len(output_ids) - len(output_versions))
        else:
            output_versions = output_versions[: len(output_ids)]

        seq = input_ids + output_ids
        full_mm = mm_token_type_ids + [0] * len(output_ids)
        loss_mask = [0] * len(input_ids) + [1] * len(output_ids)
        logprobs = [0.0] * len(input_ids) + output_logprobs
        versions = [-1] * len(input_ids) + output_versions

        multi_modal_input: list[dict[str, torch.Tensor]] = []
        if images and "pixel_values" in proc_out:
            entry: dict[str, torch.Tensor] = {"pixel_values": proc_out["pixel_values"]}
            if "image_grid_thw" in proc_out:
                entry["image_grid_thw"] = proc_out["image_grid_thw"]
            multi_modal_input.append(entry)

        reward = float(interaction.reward) if interaction.reward is not None else 0.0
        return {
            "input_ids": torch.tensor(seq, dtype=torch.long).unsqueeze(0),
            "mm_token_type_ids": torch.tensor(full_mm, dtype=torch.long).unsqueeze(0),
            "loss_mask": torch.tensor(loss_mask, dtype=torch.int32).unsqueeze(0),
            "logprobs": torch.tensor(logprobs, dtype=torch.float32).unsqueeze(0),
            "versions": torch.tensor(versions, dtype=torch.int32).unsqueeze(0),
            "attention_mask": torch.ones(len(seq), dtype=torch.bool).unsqueeze(0),
            "rewards": torch.tensor([reward], dtype=torch.float32),
            "multi_modal_input": multi_modal_input,
        }

    def _attach_vl_tensor_dicts(self, completions: dict[str, Any]) -> None:
        """Pre-populate each interaction's `_cache` with VL-augmented tensors."""
        bad_ids: list[str] = []
        for iid, interaction in completions.items():
            try:
                tensor_dict = self._build_vl_tensor_dict(interaction)
            except Exception as e:
                logger.warning(f"VL tensor build failed for interaction {iid}: {e!r}")
                tensor_dict = None
            if tensor_dict is None:
                bad_ids.append(iid)
                continue
            interaction._cache = tensor_dict
        for iid in bad_ids:
            completions.pop(iid, None)

    async def arun_episode(self, engine, data: dict[str, Any]):
        task_config = self._load_task_config(data)

        results = await asyncio.gather(
            *[
                self._run_single_trajectory(engine, task_config, i)
                for i in range(self.n_trajs)
            ]
        )

        stats_tracker.get(self.rollout_stat_scope).scalar(
            num_trajectories_failed=sum(1 for r in results if r[0] is None),
        )

        merged: dict[str, Any] = {}
        for completions, _ in results:
            if completions:
                merged.update(completions)

        if not merged:
            logger.warning(f"All trajectories failed for task {task_config.get('id')}.")
            return None
        return merged

"""Thin HTTP client for os_env's env_worker.py (DesktopEnv over HTTP).

Duck-typed to match the subset of DesktopEnv used by DeepinWorkflow:

    env.reset(task_config=...)
    env._get_obs() -> {"screenshot": bytes, ...}
    env.step(action, pause) -> (obs, reward, done, info)
    env.close()

One worker process = one VM (env_worker architecture).
"""

from __future__ import annotations

import base64
import json
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util import Retry


class RemoteDesktopEnv:
    """HTTP client for a remote os_env env_worker (single VM per process).

    Args:
        base_url: env_worker HTTP endpoint.
        token: optional bearer token (ENV_WORKER_TOKEN).
        timeout: per-request timeout in seconds.
        path_to_vm: label for logging only.
        close_mode: ``"reset"`` — call /reset on close (VM stays alive, worker
            stays up, good for smoke / single-VM setups where env_worker is
            managed externally). ``"destroy"`` — call /close (env_worker exits
            and the VM is destroyed, used when each trajectory gets its own
            worker from a pool).
    """

    def __init__(
        self,
        base_url: str = "http://127.0.0.1:8300",
        token: str | None = None,
        timeout: float = 600.0,
        path_to_vm: str | None = None,
        close_mode: str = "reset",
    ):
        self.base_url = base_url.rstrip("/")
        self.path_to_vm = path_to_vm or base_url  # for logging
        self._close_mode = close_mode
        self._closed = False
        self._timeout = timeout
        self._session = requests.Session()
        if token:
            self._session.headers["Authorization"] = f"Bearer {token}"
        retry = Retry(
            total=3,
            backoff_factor=2,
            status_forcelist=[502, 503, 504],
            allowed_methods=frozenset({"GET", "POST", "DELETE"}),
        )
        self._session.mount("http://", HTTPAdapter(max_retries=retry))

    # ---- helpers ----

    def _get(self, path: str) -> dict[str, Any]:
        r = self._session.get(f"{self.base_url}{path}", timeout=self._timeout)
        r.raise_for_status()
        return r.json()

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        r = self._session.post(
            f"{self.base_url}{path}",
            json=payload,
            timeout=self._timeout,
        )
        r.raise_for_status()
        return r.json()

    def _decode_screenshot(self, obs: dict[str, Any]) -> dict[str, Any]:
        """env_worker returns screenshot_b64; convert back to raw bytes."""
        b64 = obs.get("screenshot_b64")
        screenshot = base64.b64decode(b64) if b64 else b""
        out = dict(obs)
        out["screenshot"] = screenshot
        out.pop("screenshot_b64", None)
        return out

    # ---- DesktopEnv subset used by DeepinWorkflow ----

    def reset(self, task_config: dict[str, Any], **kwargs) -> None:
        self._post("/reset", {"task_config": task_config})

    def _get_obs(self) -> dict[str, Any]:
        obs = self._get("/observe")
        return self._decode_screenshot(obs)

    def step(self, action: Any, pause: float = 2.0) -> tuple[dict[str, Any], float, bool, dict[str, Any]]:
        data = self._post("/step", {"action": action, "pause": int(pause)})
        obs = self._decode_screenshot(data["observation"])
        return obs, float(data.get("reward", 0.0)), bool(data.get("done", False)), data.get("info", {})

    def evaluate(self) -> float:
        return 0.0  # not used — DeepinWorkflow bypasses env.evaluate()

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._close_mode == "destroy":
            # env_worker exits after /close and destroys the VM.
            try:
                self._session.delete(f"{self.base_url}/close", timeout=30)
            except Exception:
                pass
        else:
            # "reset" mode: just reset the VM to its base snapshot so the
            # same worker can serve the next trajectory. The env_worker
            # process stays alive (managed externally).
            try:
                self._post("/reset", {})
            except Exception:
                pass

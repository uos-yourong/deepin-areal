from dataclasses import dataclass, field

from areal.api.cli_args import GRPOConfig


@dataclass
class DeepinAgentConfig(GRPOConfig):
    """GRPO config for the deepin/libvariant rollout workflow.

    Environment: os_env's DesktopEnv booted in-process via libvirt (deepin
    template clone per episode). Reward: external VLM judge scores the final
    screenshot + instruction (see ``workflow/deepin_workflow.py`` and
    ``vlm_judge.py``).
    """

    # --- rollout environment (os_env / libvirt) ---
    os_env_root: str = field(default="/mnt/data/yr/code/rl_osworld/os_env")
    snapshot_name: str = field(default="init_state")
    n_trajs: int = field(default=1)
    max_steps: int = field(default=15)
    max_workers: int = field(default=4)
    sleep_after_execution: float = field(default=1.0)
    env_reset_wait_secs: float = field(default=60.0)
    turn_discount: float = field(default=0.9)
    screen_width: int = field(default=1920)
    screen_height: int = field(default=1080)
    observation_type: str = field(default="screenshot")
    action_space: str = field(default="pyautogui")
    osworld_cache_dir: str = field(default="cache")
    # When set, DeepinWorkflow uses an HTTP client against a remote
    # os_env env_worker at this URL instead of booting DesktopEnv in-process.
    # e.g. "http://127.0.0.1:8300" for a local env_worker (or Docker host).
    remote_env_url: str = field(default="")
    # Pool mode: list of env_worker URLs, one per worker/VM. Concurrent
    # trajectories are assigned round-robin so each gets its own VM.
    # Takes precedence over remote_env_url; empty list falls back to it.
    remote_env_urls: list[str] = field(default_factory=list)
    # ``reset`` — keep the env_worker alive, just reset VM on close
    # (for single-VM smoke setups where the worker is managed externally).
    # ``destroy`` — call /close which kills the worker + VM (for pools).
    remote_env_close_mode: str = field(default="reset")

    # --- dataset ---
    task_data_path: str = field(
        default="/mnt/data/yr/code/rl_osworld/任务数据/tasks_blender_theme_resolution_toy.json"
    )

    # --- external VLM reward judge (falls back to VLM_* env vars) ---
    vlm_api_base: str = field(default="")
    vlm_api_key: str = field(default="")
    vlm_model: str = field(default="")
    vlm_weight1: float = field(default=1.0)
    vlm_weight2: float = field(default=0.0)
    vlm_timeout_secs: float = field(default=120.0)
